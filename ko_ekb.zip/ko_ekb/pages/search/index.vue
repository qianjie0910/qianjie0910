<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`280rpx`)">
		<HeaderSecond :title="$lang.SEARCH_TITLE" color="#FFFFFF"></HeaderSecond>

		<view style="margin:0 40rpx 20rpx 40rpx;">
			<u-search shape="" :placeholder="$lang.TIP_SEARCH" v-model="keyword" :showAction="false" height="40px"
				:searchIconColor="$theme.PRIMARY" searchIconSize="30" bgColor="#FFFFFF" @clear="keyword=''"
				:actionText="$lang.SEARCH_TITLE" @search="searchButton" @custom="searchButton"
				color="#121212"></u-search>
		</view>

		<CustomTitle :title="$lang.SEARCH_HISTORY">
			<!-- <image mode="aspectFit" src="/static/delete.png" :style="$theme.setImageSize(44)" style="margin-left: auto;"
				@click="clearKeywords()"></image> -->
			<view style="margin-left: auto;" :style="{color:$theme.PRIMARY}" @click="clearKeywords()">
				{{$lang.SEARCH_CLEAR}}</view>
		</CustomTitle>

		<view style="display: flex;align-items: center;margin:0 10px;flex-wrap: wrap;">
			<template v-if="keywords.length>0">
				<block v-for="(item,index) in keywords" :key="index">
					<view
						style="padding:4px 10px;margin:4px;border-radius: 4rpx;background-color:#2D54AB3A;color:#121212;"
						@click="selectedItem(item)">{{item}}</view>
				</block>
			</template>
		</view>

		<view style="padding-bottom: 80rpx;">
			<SearchList :list="list"></SearchList>
		</view>
	</view>
</template>
<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import SearchList from './components/SearchList.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			SearchList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				keyword: "", // 当前关键词
				keywords: [], // 搜索词条组
				list: [], // 搜索结果
				curPage: 1,
				limit: 20,
			};
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		// 下拉刷新
		onPullDownRefresh() {
			this.searchButton();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 点击查看股票详情
			handleStockInfo(code) {
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			// 清空搜索记录
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = []; // 手动清理缓存数据
				this.list = []; // 查询结果重置
			},

			// 选中一项搜索历史词条 
			selectedItem(item) {
				this.keyword = item;
				this.searchButton();
			},

			//搜索
			async searchButton() {
				if (this.keyword == '' || this.keyword.length < 3) {
					uni.showToast({
						title: this.$lang.TIP_SEARCH,
						icon: 'none'
					})
					return false;
				}
				uni.showToast({
					title: this.$lang.LOADING_SEATCH,
					icon: 'none',
				});
				const result = await this.$http.get(`api/product/list`, {
					key: this.keyword,
					page: this.curPage,
					limit: this.limit,
					gp_index: 0
				})
				console.log(result);
				this.list = result.length <= 0 ? [] : result.map(item => {
					if (item.gid && item.gid > 0) {
						return {
							id: item.gid,
							logo: item.logo || '',
							name: item.name || '',
							code: item.code || '',
							price: item.current_price || 0,
							rate: item.rate || 0,
							type_id: item.project_type_id || 0,
						}
					}
				});
				console.log('search result:', this.list)
				if (this.keywords.indexOf(this.keyword) < 0) {
					this.keywords.push(this.keyword);
					uni.setStorageSync("keywords", this.keywords)
				}
			},
		}
	}
</script>