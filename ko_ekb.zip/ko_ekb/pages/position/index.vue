<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`280rpx`)">
		<HeaderPrimary isSearch></HeaderPrimary>

		<TabsPrimary :tabs="curTabs" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab==0">
			<view style="padding:40rpx 30rpx 0 30rpx;">
				<AccountTradeInfo></AccountTradeInfo>
			</view>

			<view style="padding:30rpx 0;">
				<CustomTitle :title="$lang.TRADE_TITLE">
					<view style="font-size: 13px;" @click="changeTab(1)" :style="{color:$theme.PRIMARY}">
						{{$lang.MORE}}
						<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
					</view>
				</CustomTitle>
				<AccountTradeHoldList></AccountTradeHoldList>
			</view>
		</template>
		<template v-else-if="curTab==1">
			<AccountTradeHoldList></AccountTradeHoldList>
		</template>
		<template v-else>
			<AccountTradeSellList></AccountTradeSellList>
		</template>


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountTradeInfo from './components/AccountTradeInfo.vue';
	import AccountTradeHoldList from './components/AccountTradeHoldList.vue';
	import AccountTradeSellList from './components/AccountTradeSellList.vue';

	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			CustomTitle,
			AccountTradeInfo,
			AccountTradeHoldList,
			AccountTradeSellList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 

				// radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				// isHold: true, // 是否是持股状态，否则为销售历史
				// isSelf: true, // 国内，false:海外
				// list: [],
				// info: {},
				// isShow: false, // 买卖弹出
				// curPage: 1, // 当前页码	
				// maxPage: 1, // 最大页码
				// flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题
			}
		},
		computed: {
			curTabs() {
				return [
					this.$lang.TRADE_TITLE,
					this.$lang.TRADE_HOLD_LOG,
					this.$lang.TRADE_SELL_LOG,
				]
			},
		},

		onLoad() {},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			// this.getData();
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
			},
		},
	}
</script>