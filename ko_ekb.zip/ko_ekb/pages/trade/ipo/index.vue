<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`480rpx`)">
		<HeaderSecond :title="$lang.TRADE_IPO_TITLE" color="#FFFFFF"></HeaderSecond>

		<TabsPrimary :tabs="$lang.TRADE_IPO_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab ==0">
			<TradeIPOList @action="changeTab"></TradeIPOList>
		</template>

		<template v-else-if="curTab==1">
			<TradeIPOLog></TradeIPOLog>
		</template>
		<template v-else>
			<TradeIPOSuccessLog></TradeIPOSuccessLog>
		</template>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeIPOList from './components/TradeIPOList.vue';
	import TradeIPOLog from './components/TradeIPOLog.vue';
	import TradeIPOSuccessLog from './components/TradeIPOSuccessLog.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeIPOList,
			TradeIPOLog,
			TradeIPOSuccessLog,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
		}
	}
</script>