<template>
	<view style="height: 100vh;">
		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
					<TradeIPOItem :item="item" @action="handleDetail"></TradeIPOItem>
				</view>
			</block>
		</view>
		
		<u-modal :show="isShow" :cancelText="$lang.BTN_CANCEL" @confirm="purchase" :confirmText='$lang.BTN_CONFIRM' @cancel="isShow=false" :showCancelButton="true">
			<u--input
			   placeholder="신청 수량을 입력하세요"
			   border="surround"
			   v-model="num"
			   type="number"
			 ></u--input>
		</u-modal>
		
		<!-- <template v-if="isShow">
			
			<TradeIPOBuy :info="itemInfo" @action="handleClose"></TradeIPOBuy>
		</template> -->
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import TradeIPOItem from './TradeIPOItem.vue';
	import TradeIPOBuy from './TradeIPOBuy.vue';
	export default {
		name: 'TradeIPOList',
		components: {
			EmptyData,
			TradeIPOItem,
			TradeIPOBuy,
		},
		data() {
			return {
				list: [],
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
				num:""
			}
		},
		created() {
			this.getList();
		},
		methods: {
			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				this.isShow = true;
				this.itemInfo = val;
				// this.curId = val;
				// this.show = true;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},
			// 点击申购 一个账号只能申购一次。
			async purchase() {
				if(this.num<=0||!this.num){
					uni.$u.toast('신청 수량을 입력하세요');
					return
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					num: this.num,
					id: this.itemInfo.id,
					// price: this.price
				})
				if (!result) return false;
				this.isShow=false;
				this.$emit('action', 1);
			},
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: 1, // 传参 1或2
				})
				console.log(result);
				this.list = result.map(item => {
					return {
						id: item.id,
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						shengou_date: item.shengou_date,
						fa_amount: item.fa_amount,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				})
			},
		}

	}
</script>

<style>
</style>