<template>
	<view style="background-color: #fff;bottom: 0;position: fixed;width: 100%;">
		<view class="padding-10">
			<u--input
			   placeholder="신청 수량을 입력하세요"
			   border="surround"
			   v-model="num"
			 ></u--input>
		</view>
		
	</view>
</template>

<script>
	export default {
		name: 'TradeIPOBuy',
		props: {
			info: {
				type: Object,
				default: {},
				num:""
			},
		},
		data() {
			return {
				// isShow: false, // 购买前二次确认的弹层
			}
		},
		created() {
			this.handleShowModal();
		},
		methods: {
			// 平仓/卖出
			async handleShowModal() {
				// const result = await uni.showModal({
				// 	title: this.$lang.TRADE_IPO_MODAL_TITLE,
				// 	content: this.$lang.TRADE_IPO_MODAL_CONTENT,
				// 	cancelText: this.$lang.BTN_CANCEL,
				// 	confirmText: this.$lang.BTN_CONFIRM,
				// 	confirmColor: this.$theme.PRIMARY,
				// 	cancelColor: '#999999',
				// });
				// console.log('异步弹层:', result);
				// if (result[1].confirm) {
				// 	this.purchase();
				// }
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					// num: this.value,
					id: this.info.id,
					// price: this.price
				})
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
			},
		}
	}
</script>

<style>
</style>