<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
					<view :style="{color:$theme.PRIMARY}" style="font-size: 36rpx;">{{item.goods.name}}</view>
					<view style="display: flex;align-items: center;">
						<view :style="{color:$theme.TEXT}" style="font-size: 28rpx;">{{item.goods.number_code}}</view>
						<view
							style="margin-left: auto; background-color: #f852523A;color:#121212;padding:4rpx 8rpx;border-radius: 8rpx;font-size: 24rpx;">
							{{item.message}}</text>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_RECORD_PRICE}}</view>
						<view :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_RECORD_APPLY_AMOUNT}}</view>
						<view :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_RECORD_CREATETIME}}</view>
						<view :style="{color:$theme.TIP}">{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeIPOLog",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-order-log`);
				console.log(result);
				this.list = result || [];
			},
		},
	}
</script>