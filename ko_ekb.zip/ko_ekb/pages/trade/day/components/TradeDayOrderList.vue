<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
						<view :style="item.style"> {{item.zt}} </view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_DAY_BUY_AMOUNT}}</view>
						<view :style="{color:$theme.LOG_VALUE}">{{$util.formatNumber(item.money)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}</view>
						<view :style="{color:$theme.LOG_VALUE}">{{$util.formatNumber(item.success)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_DAY_ORDER_SN}}</view>
						<view>{{item.ordersn}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_DAY_CREATE_TIME}}</view>
						<view>{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDayOrderList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},
		methods: {
			// 申请列表
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/sq-list`);
				console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map((item, index) => {
					return {
						...item,
						// 状态值明文、icon
						...this.$theme.setStatusPrimary(item.status),
						// 状态值 样式:字号、字色、背景等
						style: this.$theme.setStatusPrimary(item.status),
					}
				});
			},
		}
	}
</script>