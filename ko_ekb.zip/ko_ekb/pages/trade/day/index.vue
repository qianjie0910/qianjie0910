<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`480rpx`)">
		<HeaderSecond :title="$lang.TRADE_DAY_TITLE" color="#FFFFFF"></HeaderSecond>

		<TabsPrimary :tabs="$lang.TRADE_DAY_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<view style="padding: 10px;margin-bottom: 20px;">
			<template v-if="curTab==0">
				<TradeDayBuy @action="changeTab"></TradeDayBuy>
			</template>

			<template v-else-if="curTab==1">
				<TradeDayOrderList></TradeDayOrderList>
			</template>
			<template v-else>
				<TradeDaySuccessList></TradeDaySuccessList>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeDayBuy from './components/TradeDayBuy.vue';
	import TradeDayOrderList from './components/TradeDayOrderList.vue';
	import TradeDaySuccessList from './components/TradeDaySuccessList.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeDayBuy,
			TradeDayOrderList,
			TradeDaySuccessList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>