<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`480rpx`)">
		<HeaderSecond :title="$lang.TRADE_LARGE_TITLE" color="#FFFFFF"></HeaderSecond>

		<TabsPrimary :tabs="$lang.TRADE_LARGE_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab==0">
			<TradeLargeList></TradeLargeList>
		</template>
		<template v-else>
			<TradeLargeLog></TradeLargeLog>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeLargeList from './components/TradeLargeList.vue';
	import TradeLargeLog from './components/TradeLargeLog.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeLargeList,
			TradeLargeLog,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},

		},
	}
</script>