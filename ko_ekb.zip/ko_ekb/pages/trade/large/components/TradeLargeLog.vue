<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding: 10px;">
				<block v-for="(item,index) in list" :key="index">
					<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_VALUE}" style="font-size: 32rpx;">{{item.goods.name}}</view>
							<text :style="{color:$theme.RISE}">{{$lang.TRADE_LARGE_LOG_FINISH}}</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_LOG_PRICE}}</view>
							<text :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
							</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_LOG_NUM}}</view>
							<text :style="{color:$theme.PRIMARY}">{{item.num}}</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_LOG_AMOUNT}}</view>
							<text :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.amount)+` ${$lang.CURRENCY_UNIT}`}}
							</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_LOG_LEVER}}</view>
							<text :style="{color:$theme.LOG_VALUE}">{{item.double}}</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;"
							:style="{color:$theme.LOG_LABEL}">
							<view>{{$lang.TRADE_LARGE_LOG_CREATE_TIME}}</view>
							<text>{{item.created_at}}</text>
						</view>
					</view>
				</block>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeLargeLog",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				console.log(result);
				this.list = result || [];
				console.log(this.list);
			},
		},
	}
</script>