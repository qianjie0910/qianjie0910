<template>
	<view @click="detail(info)">
		<view style="display: flex;align-items: center;">
			<view style="flex:6%">
				<CustomLogo :logo="info.logo" :name="info.name"></CustomLogo>
			</view>
			<view style="flex:94%;">
				<view style="display: flex;align-items: center;">
					<text style="font-size: 28rpx;padding-left: 10px;flex:70%"
						:style="{color:$theme.LOG_LABEL}">{{info.code}}</text>
					<view :style="{color:$theme.PRIMARY}">
						{{$lang.BTN_BUY}}
					</view>
				</view>
				<view style="padding-left: 10px;font-size: 30rpx;font-weight: 700;color:#121212;margin-top: 8rpx;">
					{{info.name}}
				</view>
			</view>
		</view>
		<template v-if="info.price">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_PRICE}}</text>
				<text style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.price)+` ${$lang.CURRENCY_UNIT}`}}</text>
			</view>
		</template>

		<template v-if="info.rate">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_RATE}}</text>
				<text style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.rate,2)}}% </text>
			</view>
		</template>
		<template v-if="info.min_num">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_MIN_QTY}}</text>
				<text style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
					{{info.min_num+` ${$lang.QUANTITY_UNIT}`}}</text>
			</view>
		</template>
		<template v-if="info.max_num">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_LARGE_MAX_QTY}}</text>
				<text style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
					{{info.max_num+` ${$lang.QUANTITY_UNIT}`}}</text>
			</view>
		</template>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeLargeItem',
		components: {
			CustomLogo,
		},
		props: {
			// 交易类型页面产品列表中的单个产品
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {};
		},
		computed: {},
		methods: {
			detail(val) {
				console.log('stock info:', val);
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>