<template>
	<view>
		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
					<TradeLargeItem :info="item" @action="handleDetail"></TradeLargeItem>
				</view>
			</block>
		</view>
		<template v-if="isShow">
			<TradeLargeBuy :info="itemInfo" @action="handleClose"></TradeLargeBuy>
		</template>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeLargeItem from './TradeLargeItem.vue';
	import TradeLargeBuy from './TradeLargeBuy.vue';
	export default {
		name: 'TradeLargeList',
		components: {
			CustomTitle,
			EmptyData,
			TradeLargeItem,
			TradeLargeBuy,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		computed: {},
		created() {
			this.getList();
		},
		methods: {
			handleDetail(val) {
				this.isShow = true;
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/list`);
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = !result || result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						id: item.id,
						price: item.price,
						rate_num: item.goods.rate_num,
						rate: item.goods.rate,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				});
			},
		},
	}
</script>