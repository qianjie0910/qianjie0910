<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`480rpx`)">
		<HeaderPrimary isSearch :isLang="isActLang"> </HeaderPrimary>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view class="common_block">
			<ButtonGroup @action="linkLarge"></ButtonGroup>
		</view>

		<view style="margin:0 40rpx;">
			<TitlePrimary :title="$lang.STOCK_ALL">
				<view style="font-size: 13px;margin-left: auto;" @click="linkAllList()" :style="{color:$theme.PRIMARY}">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
				</view>
			</TitlePrimary>
		</view>

		<view style="padding-bottom:20px;">
			<MarketHot></MarketHot>
		</view>

		<!-- IPO申购成功弹层 -->
		<IPOSuccessAlert></IPOSuccessAlert>

		<!-- <template v-if="isShow">
			<view class="common_mask"></view>
			<view class="common_block common_popup" style="min-height:35vh;margin:auto">
				<view class="popup_header" style="color:#FFFFFF">{{$lang.TRADE_LARGE_LOOK_PASSWORD}}</view>

				<view style="display: flex;align-items: center;justify-content: center;">
					<view class="common_input_wrapper" style="margin-bottom: 40rpx;width: 80%;">
						<input v-model="password" :placeholder="$lang.TRADE_LARGE_LOOK_PASSWORD" type="password"
							:placeholder-style="$theme.setPlaceholder()"
							style="width: 80%;padding-left: 40rpx;"></input>
					</view>
				</view>

				<view style="text-align: right;padding-right: 60rpx;font-size: 24rpx;"
					:style="{color:$theme.LOG_LABEL}">
					{{$lang.TRADE_LARGE_GET_PASSWORD}}
				</view>

				<view style="display: flex;justify-content: space-between;margin:30rpx 60rpx;">
					<view class="common_btn" style="width: 40%;" @tap="handleConfirm()">
						{{$lang.BTN_CONFIRM}}
					</view>
					<view class="common_btn" style="width: 40%;" @tap.stop="handleCancel()">
						{{$lang.BTN_CANCEL}}
					</view>
				</view>
			</view>
		</template> -->
	</view>
</template>

<script>
	import Translate from '@/components/Translate.vue';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import MarketNewsTop from '@/components/market/MarketNewsTop.vue';
	import MarketHot from '@/components/market/MarketHot.vue';
	import IPOSuccessAlert from '@/components/dialog/IPOSuccessAlert.vue';
	export default {
		components: {
			Translate,
			HeaderPrimary,
			ButtonGroup,
			TitlePrimary,
			CardItemPrimary,
			MarketNewsTop,
			MarketHot,
			IPOSuccessAlert,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isActLang: true, // 当前登入用户是否开启多语言权限	
				cardInfo: {}, // 资产卡
				// isShow: false, // 大宗需弹层输入密码查看 /by 2024.06.27
				// largePath: '', // 大宗的路由
				// password: '', // 大宗的页面进入前 弹层输入密码
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					// this.$lang.CARD_ASSETS_FREEZE
				]
			}
		},

		onLoad() {},
		onShow() {
			this.getAccountInfo();
			this.isAnimat = true;
			console.log(this.cardLabels);
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			// 按钮组，点击大宗交易
			// linkLarge(val) {
			// 	console.log('linkLarge:', val);
			// 	this.largePath = val;
			// 	uni.hideTabBar(); // 隐藏tabBar
			// 	// this.isShow = true;
			// },
			// // 弹层取消按钮事件
			// handleCancel() {
			// 	// this.isShow = false;
			// 	uni.showTabBar(); // 显示tabBar
			// },
			// 弹层确认按钮事件
			// async handleConfirm() {
				// 判断输入密码不为空。
				// if (this.password == '') {
				// 	uni.showToast({
				// 		title: this.$lang.TRADE_LARGE_LOOK_PASSWORD,
				// 		icon: 'none'
				// 	});
				// 	return false;
				// }

				// 获取后台设置的大宗查看密码
				// const result = await this.$http.get(`api/app/config`);
				// console.log(`result111:`, result);
				// const temp = result.reduce((map, item) => {
				// 	map.set(item.key, item.value);
				// 	return map;
				// }, new Map());

				// console.log(temp.get('big_pwd'));
				// 根据返回结果，处理是否跳转到大宗交易
				// if (this.password == temp.get('big_pwd')) {
					// this.isShow = false;
					// uni.showTabBar(); // 显示tabBar
					// uni.navigateTo({
					// 	url: this.largePath
			// 		});
			// 	} else {
			// 		uni.showToast({
			// 			title: this.$lang.TRADE_LARGE_LOOK_PASSWORD_ERROR,
			// 			icon: 'none'
			// 		});
			// 	}
			// },
			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=3`,
				})
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.cardInfo = {
					value1: result.totalZichan || 0,
					value2: result.money || 0,
					value3: result.freeze || 0,
				};
			}
		},
	}
</script>