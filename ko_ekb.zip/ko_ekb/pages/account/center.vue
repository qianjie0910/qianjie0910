<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`480rpx`)">
		<HeaderPrimary isSearch isNotify isLang :title="$lang.ACCOUNT_CENTER_TITLE" color="#FFFFFF"></HeaderPrimary>

		<Profile :info="userInfo"></Profile>

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 30rpx;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>


		<view style="display: flex;align-items: center;justify-content: space-between;padding:20rpx 40rpx;">
			<view style="padding:30rpx 36rpx;" @click="linkDeposit()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/centet_deposit.png" mode="aspectFit" :style="$theme.setImageSize(140)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>

			<view style="padding:30rpx 36rpx;" @click="linkWithdraw()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/centet_withdraw.png" mode="aspectFit" :style="$theme.setImageSize(140)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>

			<view style="padding:30rpx 36rpx;" @click="linkService()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/centet_service.png" mode="aspectFit" :style="$theme.setImageSize(140)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.BTN_SERVICE}}
				</view>
			</view>
		</view>

		<view style="padding:0 10px;">
			<CustomTitle :title="$lang.ACCOUNT_MORE_FEATURES"></CustomTitle>
		</view>

		<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

		<SignOut></SignOut>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			FeatureListPrimary,
			CustomTitle,
			AccountAssets,
			SignOut,
			CardItemPrimary
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardInfo: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			}
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			// 客服
			linkService() {
				this.$util.linkCustomerService();
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardInfo = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.freeze || 0,
				};
			},
		},
	}
</script>