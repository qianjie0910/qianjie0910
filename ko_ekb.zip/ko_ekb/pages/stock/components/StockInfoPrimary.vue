<template>
	<view>
		<view class="common_block"
			style="padding-bottom: 10px;background-color: #FFFFFF;border-radius: 8rpx;box-shadow: none;">
			<view style="display: flex;align-items: center;padding: 20px;padding-bottom: 0;">
				<view style="flex:18%">
					<CustomLogo :logo="info.logo" :name="info.name"></CustomLogo>
				</view>
				<view style="flex:72%">
					<view style="margin-bottom: 2px;font-size: 40rpx;" :style="{color:$theme.PRIMARY}">
						{{info.name}}
						<image :src="`/static/arrow_${info.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$theme.setImageSize(32)" style="margin-left: 10px;"></image>
					</view>
					<view :style="{color:$theme.LOG_LABEL}"> {{info.number_code}} {{info.ct_name}}</view>
				</view>
				<view style="flex:10%;text-align: right;" @click="handleUnFollow(info.gid)">
					<image :src="`/static/${info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
						:style="$theme.setImageSize(40)"></image>
				</view>
			</view>
			<view
				style="display: flex;align-items: center;padding: 10px 20px;padding-bottom: 0;justify-content:space-between;"
				:style="$theme.setStockRiseFall(info.rate>0)">
				<view style="font-size: 32rpx;">
					{{$util.formatNumber(info.current_price)}} {{$lang.CURRENCY_UNIT}}
				</view>
				<view style="text-align: right;font-size: 32rpx;">
					{{$util.formatNumber(info.rate_num)}}
				</view>
				<view style="text-align: right;font-size: 32rpx;">
					{{$util.formatNumber(info.rate)}}%
				</view>
			</view>
		</view>
		<view class="common_block"
			style="padding-bottom: 10px;background-color: #FFFFFF;border-radius: 8rpx;box-shadow: none;">
			<block v-for="(item,index) in $lang.STOCK_INFO_TITLES" :key="index">
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 30px;padding:0 10px;">
					<view :style="{color:$theme.LOG_LABEL}">{{item}}</view>
					<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
						{{setInfo[index]}}
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'StockInfoPrimary',
		components: {
			CustomLogo
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},

		computed: {
			setInfo() {
				return [
					this.$util.formatMoney(this.info.info.open) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatMoney(this.info.info.prev_close) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatMoney(this.info.info.high) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatMoney(this.info.info.low) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.volume / 10000),
					// this.$util.formatMoney(this.info.info.volume_valued / 10000) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatMoney(this.info.info.volume_valued),
				]
			}
		},

		methods: {
			// 取关
			async handleUnFollow(id) {
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				})
				console.log(`result:`, result);
				// uni.showToast({
				// 	title: result.message,
				// 	icon: 'none'
				// });
				this.info.is_collected = this.info.is_collected == 1 ? 0 : 1;
			},
		}
	}
</script>

<style>
</style>