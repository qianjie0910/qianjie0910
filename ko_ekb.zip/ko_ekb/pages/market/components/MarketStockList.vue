<template>
	<view>
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block"
					style="padding:10px;background-color: #FFFFFF;margin:20rpx;display: flex;align-items: center;justify-content: space-between;"
					@click="linkInfo(item.code)">
					<view style="display: flex;align-items: center;">
						<template v-if="item.logo">
							<view style="width: 90rpx;text-align: center;">
								<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
							</view>
						</template>
						<view :style="{color:$theme.PRIMARY}"
							style="font-size: 32rpx;line-height: 1.6;padding-left: 20rpx;">
							{{item.name}}
							<view :style="{color:$theme.LOG_LABEL}">{{item.code}}</view>
						</view>
					</view>
					<view style="padding-top: 10rpx;text-align: right;">
						<view :style="$theme.setStockRiseFall(item.rate*1>0)">
							{{$util.formatMoney(item.price)}}
						</view>
						<view :style="$theme.setStockRiseFall(item.rate*1>0)">
							{{$util.formatNumber(item.rate)}}%
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketStockList',
		components: {
			EmptyData,
			CustomLogo
		},
		data() {
			return {
				list: [],
				socket: null, // websocket
			}
		},
		computed: {

		},
		created() {
			this.getList();
		},
		methods: {
			// 跳转到详情
			linkInfo(val) {
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?code=${val}`
				})
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				// api未替换
				const result = await this.$http.get(`api/goods/list`);
				console.log('result:', result);
				const temp = !result || result.length <= 0 ? [] : result.filter(item => item.stock_id && item
					.stock_id > 0);
				this.list = !temp || temp.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo || '',
						name: item.ko_name || '',
						code: item.code || '',
						price: item.close || 0,
						rate: item.returns || 0,
						type_id: item.project_type_id || 0,
					}
				});
				console.log(this.list);
			}
		}
	}
</script>

<style>
</style>