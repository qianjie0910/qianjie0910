<template>
	<view> news</view>
</template>

<script>
</script>

<style>
</style>