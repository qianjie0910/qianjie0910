<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`360rpx`)">
		<HeaderPrimary isSearch></HeaderPrimary>

		<TabsPrimary :tabs="tabs" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<view :class="setClass" style="padding-bottom: 20px;">
			<template v-if="curTab==0">
				<MarketTrack ref="track"></MarketTrack>
			</template>
			<template v-else>
				<MarketStockList ref="all"></MarketStockList>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import MarketTrack from './components/MarketTrack.vue';
	import MarketStockList from './components/MarketStockList.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			MarketTrack,
			MarketStockList
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前默认放在Coin
			}
		},

		computed: {
			// tabs设置。
			tabs() {
				return [
					this.$lang.MARKET_INDEX_TAB_TRACK,
					this.$lang.MARKET_INDEX_TAB_MARKET,
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onReady() {
			console.log('onReady', this.$refs.follow);
		},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>