<template>
	<view class="launch">

		<view style="display: flex;align-items: center;justify-content: center;padding: 25vh 0;padding-bottom: 5vh;">
			<image src='/static/logo.svg' mode="aspectFit" :style="$theme.setImageSize(400,300)">
			</image>
		</view>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/launch_img.png" mode="aspectFit" :style="$theme.setImageSize(512)"></image>
		</view> -->
		<view style="display: flex;align-items: center;justify-content: center;">
			<view style="margin-top: 20px;text-align: center;font-size: 36rpx;font-family: 700;color:#333333;">
				{{$lang.LAUNCH_TITLE}}
			</view>
		</view>

		<ProgressSecond></ProgressSecond>
	</view>
</template>

<script>
	import ProgressSecond from './components/ProgressSecond.vue';
	export default {
		components: {
			ProgressSecond,
		},
	}
</script>

<style lang="scss" scoped>
	.launch {
		width: 100%;
		height: 100vh;
		padding-top: 0;
		// background-image: url('/static/launch_bg.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		background-image: linear-gradient(180deg, #FFFFFF, #FFFFFF);
		position: relative;
	}
</style>