<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header style="padding-top: 60rpx;border-bottom: 1px solid #E7E8ED;">
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;" @touchmove.stop>
				<view style="display: flex;margin:0 10rpx;">
					<block v-for="(item,index) in tabs" :key='index'>
						<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
							{{item}}
						</view>
					</block>
				</view>
			</scroll-view>
		</header>

		<template v-if="curTab==0">
			<AccountTradeInfo></AccountTradeInfo>
			<view style="padding:30rpx 40rpx 0 40rpx;">
				<view style="display: flex;flex-wrap: nowrap;align-items: center;line-height: 2;">
					<view style="font-size: 36rpx;font-weight: 700;" :style="{color:$theme.SECOND}">
						{{$lang.TRADE_TITLE}}
					</view>
					<view style="margin-left: auto;">
						<view style="font-size: 13px;" @click="changeTab(1)" :style="{color:$theme.SECOND}">
							{{$lang.MORE}}
							<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
						</view>
					</view>
				</view>
				
			</view>
			
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block" style="padding:30rpx;" @tap="handleShowModal(item)">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="bold" :style="{color:$theme.LOG_VALUE}"
								style="font-size: 36rpx;line-height: 1.6;">
								{{item.name}}
							</view>
							<view class="flex-1 bold" style="padding: 0px 10px;">{{item.code}}</view>
						</view>
			
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-top: 10rpx;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_PROFIT_RATE}}</view>
							<view :style="{color:$theme.setStockRiseFall(item.profitRate*1>0)}">
								{{$util.formatNumber(item.profitRate,2)}}%
							</view>
						</view>
			
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_PROFIT_AMOUNT}}</view>
							<view :style="{color:$theme.setStockRiseFall(item.profitRate*1>0)}">
								{{$util.formatMoney(item.profit*1)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
			
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_BUY_AMOUNT}}</view>
							<text :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.buyNum)+` ${$lang.QUANTITY_UNIT}`}}
							</text>
						</view>
			
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_TOTAL_PRICE}}</view>
							<text :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.totalPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
						</view>
			
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_BUY_PRICE}}</view>
							<text :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
						</view>
			
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_CUR_PRICE}}</view>
							<text :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.currentPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
						</view>
					</view>
				</block>
			
			
			<!-- <AccountTradeHoldList></AccountTradeHoldList> -->
		</template>
		
		<template v-else-if="curTab==1">
			<AccountTradeHoldList></AccountTradeHoldList>
		</template>
		<template v-else>
			<AccountTradeSellList></AccountTradeSellList>
		</template>


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import AccountTradeInfo from './components/AccountTradeInfo.vue';
	import AccountTradeHoldList from './components/AccountTradeHoldList.vue';
	import AccountTradeSellList from './components/AccountTradeSellList.vue';

	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			TitlePrimary,
			AccountTradeInfo,
			AccountTradeHoldList,
			AccountTradeSellList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 
				list: [],
			}
		},
		computed: {
			tabs() {
				return [
					this.$lang.TRADE_TITLE,
					this.$lang.TRADE_HOLD_LOG,
					this.$lang.TRADE_SELL_LOG,
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad() {},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		created() {
			this.getList();
		},
		//下拉刷新
		onPullDownRefresh() {
			// this.getData();
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
			},
			handleShowModal(val) {
				this.isShow = true;
				uni.hideTabBar(); // 隐藏tabBar
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/order`, {
					status: 1, // 1持仓，2历史
					gp_index: 0,
				});
				console.log(result);
				if (!result) return false;
				// 过滤保留合法数据
				const temp = !result.data || result.data.length <= 0 ? [] :
					result.data.filter(item => item.order_buy && item.order_buy.id > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						name: item.goods_info.name,
						// 持仓盈利率 =（最终价 - 买入价） / 买入价 *100%
						profitRate: (item.goods_info.current_price * 1 - item.order_buy.price * 1) /
							item.order_buy.price * 100,
						profit: item.order_buy.yingkui, // 盈利额							
						buyNum: item.order_buy.num, // 购买数量							
						totalPrice: item.goods_info.current_price * 1 * item.order_buy.num, // 购买总价
						buyPrice: item.order_buy.price, // 买入单价
						currentPrice: item.goods_info.current_price, // 最新价格
						// 弹层所需数据
						buyCreateTime: item.order_buy.created_at,
						lever: item.order_buy.double,
						buyFee: item.order_buy.buy_fee,
						amount: item.order_buy.amount,
						code: item.goods_info.number_code,
						id: item.id,
						typeId: item.goods_info.project_type_id,
						floatProfit: item.order_buy.float_yingkui * 1, // 浮动盈亏
					}
				})
				console.log(this.list);
			},
			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `${w}rpx`,
					padding: `12rpx 32rpx`,
					color: val ? this.$theme.SECOND : '#CBCBCB',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `4rpx solid ${val? this.$theme.SECOND :this.$theme.TRANSPARENT }`
				}
			},
		},
	}
</script>