<template>
	<view style="margin-top: 30rpx;">
		<CustomTitle :title="$lang.STOCK_TRADE_TREND_TITLE">
			<view style="margin-left: auto;" :style="{color:$theme.LOG_LABEL}">
				{{info['net_volume'].dt}}
			</view>
		</CustomTitle>

		<view style="padding:10px 0;">
			<block v-for="(item,index) in $lang.STOCK_TRADE_TREND_BUY_AMOUNT" :key="index">
				<view style="padding-left: 30rpx;font-size: 28rpx;" :style="{color:$theme.LOG_LABEL}">
					{{item}}
				</view>
				<view style="display: flex;align-items: center;margin-bottom: 30rpx;">
					<block v-for="(subItem,subIndex) in $lang.STOCK_TRADE_TREND_INFO_TITLE" :key="subIndex">
						<view style="flex:33%;padding: 4px;text-align: center;line-height: 1.6;">
							<view :style="{color:$theme.LOG_VALUE}">{{subItem}}</view>
							<view :style="$theme.setStockRiseFall(formatData[index][subIndex] >0)">
								{{$util.formatNumber(formatData[index][subIndex])}}
							</view>
						</view>
					</block>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		name: 'StockTrend',
		components: {
			CustomTitle,
		},
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		computed: {
			formatData() {
				return [
					[this.info['net_volume'].net_vol_individual,
						this.info['net_volume'].net_vol_institutional,
						this.info['net_volume'].net_vol_foreigner,
					],
					[
						this.info['cum_volume'].cum_vol_individual,
						this.info['cum_volume'].cum_vol_institutional,
						this.info['cum_volume'].cum_vol_foreigner,
					]
				]
			}
		}
	}
</script>