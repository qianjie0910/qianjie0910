<template>
	<view>
		<view style="background-color: #FFFFFF;">
			<HeaderSecond :title="$lang.WITHDRAW_RECORD_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding-top: 20rpx;padding-bottom: 40rpx;">
				<block v-for="(item,index) in list" :key="index">
					<view
						style="background-color: #FFFFFF; padding:10px 16px;border-radius: 8rpx;line-height: 1.8;margin:0 20px 20px 20px;">
						<view style="text-align: right;" :style="{color:$theme.RISE}">
							{{item.desc_type}}
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.WITHDRAW_RECORD_AMOUNT}}
							</view>
							<view :style="{color:$theme.PRIMARY}" style="font-size:32rpx;">
								{{item.money}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.WITHDRAW_RECORD_FEE}}
							</view>
							<view :style="{color:$theme.LOG_VALUE}" style="font-size:28rpx;">
								{{item.withfee}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.WITHDRAW_RECORD_COIN}}
							</view>
							<view :style="{color:$theme.LOG_VALUE}">
								{{item.pay_channle}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.WITHDRAW_RECORD_ADDRESS}}
							</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.bankno}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.WITHDRAW_RECORD_SN}}</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.order_sn}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.WITHDRAW_RECORD_CT}}</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.created_at}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.WITHDRAW_RECORD_DESC}}</view>
							<view :style="{color:$theme.LOG_VALUE}">
								{{item.reason}}
							</view>
						</view>

						<template v-if="item.status==0">
							<view style="display: flex;align-items: center;justify-content: space-between; ">
								<!-- <view :style="item.style"> {{item.text}} </view> -->
								<view
									style="color:#FC4C76;margin-left: auto;padding:4rpx 8rpx;background-color: #FC4C7611;font-size: 24rpx;"
									@click="handleCancel(item.id)">
									{{$lang.COMMON_CANCEL}}
									<!-- <view class="arrow rotate_45" style="border-color: #FC4C76;"
								:style="$theme.setImageSize(12)"></view> -->
								</view>
							</view>
						</template>
						<template v-else-if="item.status==2">
							<view style="display: flex;align-items: center;justify-content: space-between; ">
								<!-- <view :style="item.style"> {{item.text}} </view> -->
								<view
									style="color:#2D54AB;margin-left: auto;padding:4rpx 8rpx;background-color: #2D54AB11;font-size: 24rpx;"
									@click="handleService()">
									{{$lang.BTN_SEND_SERVICE}}
									<!-- <view class="arrow rotate_45" style="border-color: #FC4C76;"
								:style="$theme.setImageSize(12)"></view> -->
								</view>
							</view>
						</template>
						<template v-else>
							<template v-if="item.text">
								<view :style="item.style"> {{item.text}} </view>
							</template>
						</template>
					</view>
				</block>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		onShow() {
			this.getList();
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 联系客服
			handleService() {
				this.$util.linkCustomerService();
			},

			// 取消提现
			async handleCancel(id) {
				const result = await uni.showModal({
					title: this.$lang.WITHDRAW_MODAL_TITLE,
					cancelText: this.$lang.COMMON_CANCEL,
					confirmText: this.$lang.COMMON_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.cancelWithdraw(id);
				}
			},

			async cancelWithdraw(id) {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'none',
				});
				const result = await this.$http.post(`api/app/qx`, {
					id
				});
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/withdraw`);
				console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						...item,
						// ...this.$theme.setStatusPrimary(item.status),
						// style: this.$theme.setStatusPrimary(item.status),
					}
				})
				console.log(this.list);
			},
		}
	}
</script>

<style>

</style>