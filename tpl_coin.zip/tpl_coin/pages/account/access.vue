<template>
	<view class="access_bg" :class="isAnimat?'fade_in':'fade_out'">
		<view style="display: flex;flex-direction: column;justify-content: space-between;">
			<image src='/static/logo_name.png' :style="$theme.setImageSize(320,70)" style="margin:8vh 0 3vh 64rpx">
			</image>
			<view :class="isSignIn?'left_in':'right_in'">
				<view class="common_block" style="padding:40rpx 52rpx;margin:32rpx;">
					<view
						style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 60rpx;">
						<view style="font-size: 32rpx;font-weight: 900;">
							{{$lang.WELCOME+` ${isSignIn?$lang.SIGN_IN_TITLE:$lang.SIGN_UP_TITLE}`}}
						</view>
						<!-- <view>
							<view style="display: flex;align-items: center;" @click="showLang=true">
								<view style="padding-right: 20rpx;">{{setLang}}</view>
								<image src="/static/arrow_down_solid.png" :style="$theme.setImageSize(16,12)">
								</image>
							</view>
						</view> -->
					</view>

					<!-- 手机号登录及注册 -->
					<TitleSecond :title="$lang.ACCOUNT_NAME"></TitleSecond>
					<view class="input_wrapper" style="margin-bottom: 40rpx;">
						<!-- <image src="/static/account_name.png" mode="aspectFit"></image> -->
						<input v-model="user" type="number" :placeholder="$lang.TIP_ENTER_ACCOUNT_NAME"
							:placeholder-style="$theme.setPlaceholder()"></input>
					</view>

					<!-- 通用的输入密码 -->
					<TitleSecond :title="$lang.ACCOUNT_PASSWORD"></TitleSecond>
					<view class="input_wrapper" style="margin-bottom: 40rpx;">
						<!-- <image src="/static/account_password.png" mode="aspectFit"> </image> -->
						<template v-if="isShow">
							<input v-model="password" type="text" :placeholder="$lang.TIP_ENTER_ACCOUNT_PASSWORD"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</template>
						<template v-else>
							<input v-model="password" type="password" :placeholder="$lang.TIP_ENTER_ACCOUNT_PASSWORD"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</template>
						<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
							style="margin-left: auto;padding-right: 0;" :style="$theme.setImageSize(32)"
							@click="toggleShow">
						</image>
					</view>

					<!-- 注册所需 -->
					<template v-if="!isSignIn">
						<TitleSecond :title="$lang.VERIFY_ACCOUNT_PASSWORD"></TitleSecond>
						<view class="input_wrapper" style="margin-bottom: 40rpx;">
							<!-- <image src="/static/account_password.png" mode="aspectFit"> </image> -->
							<template v-if="isShow">
								<input v-model="verifyPassword" type="text"
									:placeholder="$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD"
									:placeholder-style="$theme.setPlaceholder()"></input>
							</template>
							<template v-else>
								<input v-model="verifyPassword" type="password"
									:placeholder="$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD"
									:placeholder-style="$theme.setPlaceholder()"></input>
							</template>

							<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
								style="margin-left: auto;padding-right: 0;" :style="$theme.setImageSize(32)"
								@click="toggleShow">
							</image>
						</view>

						<TitleSecond :title="$lang.INVITATION_CODE"></TitleSecond>
						<view class="input_wrapper" style="margin-bottom: 40rpx;">
							<!-- <image src="/static/account_code.png" mode="aspectFit"> </image> -->
							<input v-model="code" type="text" :placeholder="$lang.TIP_ENTER_INVITATION_CODE"
								maxlength="11" :placeholder-style="$theme.setPlaceholder()"></input>
						</view>
					</template>

					<!-- 通用按钮 已包含相关逻辑判断 -->
					<view class="common_btn" @click="handleConfirm()" style="margin:80rpx auto 20rpx auto;">
						{{isSignIn?$lang.BTN_SIGN_IN:$lang.BTN_SIGN_UP}}
					</view>
				</view>

				<!-- 记住密码，以及登入注册的切换 -->
				<view style="display: flex;align-items: center;justify-content: space-between;margin: 40rpx 60rpx;">
					<template v-if="isSignIn">
						<u-checkbox-group>
							<!-- circle -->
							<u-checkbox shape="" :activeColor="$theme.SECOND" :label="$lang.TIP_REMEMBER_PWD"
								v-model="isRemember" labelColor="#666666" labelSize="24rpx" @change="changeRemember"
								:checked="isRemember" :iconColor="$theme.SECOND"></u-checkbox>
						</u-checkbox-group>
					</template>
					<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}" @click="handleChange()">
						{{isSignIn?$lang.SIGN_UP_TITLE:$lang.GO_TO_SIGN_IN}}
					</view>
				</view>
			</view>

			<view style="position: fixed;left:0;right: 0;bottom: 60rpx;">
				<!-- 隐私协议 -->
				<view style="display: flex;align-items: center;justify-content: center;">
					<view>
						<u-checkbox-group>
							<u-checkbox shape="" :activeColor="$theme.SECOND" :label="$lang.TIP_AGREE" v-model="isAgree"
								labelColor="#333333" labelSize="24rpx" @change="changeAgree" :checked="isAgree"
								:iconColor="$theme.SECOND"></u-checkbox>
						</u-checkbox-group>
					</view>
					<view style="font-size:24rpx;margin-left: 8px;" :style="{color:$theme.PRIMARY}" @click="linkPact()">
						{{$lang.TIP_PRVITE_PACT}}
					</view>
				</view>
			</view>
		</view>

		<template v-if="showLang">
			<view class="common_mask" @click="showLang=false"></view>
			<view class="common_popup">
				<view class="popup_header" style="color:#FFFFFF;" :style="{backgroundColor:$theme.PRIMARY}">
					{{$lang.TRANSLATE_TITLE}}

					<image src="/static/close_light.png" mode="aspectFit" :style="$theme.setImageSize(40)"
						style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
						@click="handleClose()"></image>
				</view>

				<view style="display: flex;align-items: center;flex-wrap: wrap;padding-top: 20px;">
					<block v-for="(item,index) in $util.LANGUAGE_LIST" :key="index">
						<view style="flex:33%;text-align: center;" @click="handleSelected(item,index)">
							<image :src="`/static/lang/${item.icon}.png`" :style="$theme.setImageSize(160)">
							</image>
							<view style="text-align: center;">{{item.name}}</view>
						</view>
					</block>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import TitleSecond from "@/components/title/TitleSecond.vue";
	export default {
		components: {
			TitleSecond
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showLang: false, // lang modal
				isShow: uni.getStorageSync('show') || false, // 密码显隐
				user: "", // 账户
				password: '', // 密码
				verifyPassword: '', // 确认密码
				emailCode: '', // 邮箱验证码（印度）
				code: '', // 邀请码
				isSignIn: true,
				isRemember: true, // 记住密码
				isAgree: false, // 同意隐私协议
			};
		},
		computed: {
			setLang() {
				const temp = uni.getStorageSync('lang') || this.$LANGCODE;
				const tempName = this.$util.LANGUAGE_LIST.filter(item => item.lang == temp)[0].name;
				return tempName;
			}
		},
		onLoad(opt) {
			console.log(`opt`, opt);
			// 处理邀请链接，及附带邀请码
			if (opt.code && opt.code.length > 0) {
				this.code = opt.code;
				console.log(this.isSignIn);
				console.log(this.code);
			}
			// 读取缓存中的页面信息
			if (this.isSignIn) {
				this.user = uni.getStorageSync('user') || '';
				this.password = uni.getStorageSync('pwd') || '';
			}
		},
		onShow() {
			this.isAnimat = true;
			if (this.code.length > 0) this.isSignIn = false;
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			handleClose() {
				this.showLang = false;
			},

			handleSelected(val, index) {
				console.log(index, val);
				this.showLang = false;
				uni.setStorageSync('lang', val.lang);
				uni.reLaunch({
					url: this.$paths.LAUNCH,
				})
			},

			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			// 勾选记住密码
			changeRemember(e) {
				this.isRemember = e;
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
			},

			// 用户隐私协议
			linkPact() {
				if (this.isSignIn) {
					uni.setStorageSync('user', this.user);
					uni.setStorageSync('pwd', this.password);
				}
				uni.navigateTo({
					url: this.$paths.PRVITE_PACT,
				});
			},
			// 切换当前 登录或注册
			handleChange() {
				this.isSignIn = !this.isSignIn;
				// 只在切換在登入時，緩存張密
				if (!this.isSignIn) {
					this.user = '';
					this.password = '';
				}
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_NAME,
						icon: 'none',
					});
					return false;
				}
				if (this.user.length < 8) {
					uni.showToast({
						title: this.$lang.COMMON_MIN_LENGTH,
						icon: 'none',
					});
					return false;
				}
				if (this.password == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.showToast({
						title: this.$lang.TIP_PWD_NOEQUAL,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.showToast({
						title: this.$lang.TIP_ENTER_INVITATION_CODE,
						icon: 'none',
					});
					return false;
				}
				if (this.isAgree != true) {
					uni.showToast({
						title: this.$lang.TIP_CHECK_AGREE,
						icon: 'none',
					});
					return false;
				}
				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.API_SIGN_IN_NOW,
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				});
				console.log('result:', result);
				if (!result) return false;
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_SIGNIN,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.HOME,
					});
				}, 1000);
			},
			async register() {
				uni.showLoading({
					title: this.$lang.API_SIGN_UP_NOW,
				});
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: 123456,
				});
				console.log('result:', result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_REGISTER,
					icon: 'success',
				});
				this.signIn();
			},
		}
	}
</script>

<style lang="scss" scoped>
	/deep/.u-checkbox__icon-wrap {
		background-color: transparent !important;
	}

	.access_bg {
		width: 100%;
		min-height: 100vh;
		background-color: #F5F6FB;
	}

	.input_wrapper {
		display: flex;
		flex-wrap: nowrap;
		align-items: center;
		// margin: 20rpx 0;
		padding: 20rpx 0;
		/* border-radius: 16rpx; */
		height: 54rpx;
		line-height: 54rpx;
		border-bottom: 1px solid #EFEFEF;

		/* background-color: #F5F5F5; */
		input {
			color: #121212;
			width: 80%;
		}

		image {
			padding-right: 40rpx;
			width: 40rpx;
			height: 40rpx;
		}
	}
</style>