<template>
	<view>
		<view class="mask" @tap="handleClose()"></view>
		<view class="modal_wrapper">
			<view
				style="background-color: #FFFFFF;border-radius: 44rpx 44rpx 0 0;padding-top:40rpx;padding-bottom: 20rpx;">
				<view style="text-align: center;font-size: 32rpx;font-weight: 700;">
					{{info.name}}
				</view>
				<view style="padding: 40rpx;padding-bottom: 100rpx;">
					<view style="display: flex;align-items: center;justify-content:space-between;line-height: 2.4;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_LIST_PRICE}}</view>
						<view :style="{color:$theme.LOG_VALUE}">{{info.price}}</view>
					</view>

					<TitleSecond :title="$lang.CONTRACT_CLOSE_QTY"></TitleSecond>
					<view class="common_input_wrapper"
						style="background-color:#F5F6FB;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:20rpx 0;">
						<input v-model="quantity" type="digit" :placeholder="$lang.COIN_BUY_TIP_ENTER_QTY"
							:placeholder-style="$theme.setPlaceholder()"></input>
					</view>
					<view
						style="background-color: #F6F8FC;display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
						<block v-for="(item,index) in qtyList" :key="index">
							<view :style="setStyle(curQuantity == item)" @tap="changeQty(item)">{{item}}</view>
						</block>
					</view>

					<view style="display: flex;align-items: center;justify-content:space-between;line-height: 2.4;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_LIST_TOTAL}}</view>
						<view :style="{color:$theme.LOG_VALUE}">{{total}}</view>
					</view>

					<view class="common_btn" style="margin:40rpx auto;width: 80%;margin-top: 80rpx;"
						@click="handleBuy()">
						{{$lang.COMMON_BUY}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		name: 'BuyModal',
		components: {
			TitleSecond
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				isShow: false,
				quantity: 100, // 数量输入框
				curQuantity: 100, // 当前选中预设值
				// amount: '', // 限价模式 输入金额
				// userInfo: {}, // 合約資產
			}
		},
		computed: {
			qtyList() {
				return [100, 500, 1000, 5000]
			},
			total() {
				return this.quantity * 1 <= 0 ? 0 : this.$util.formatNumber(this.quantity * 1 * this.info.price * 1, 4)
			},
		},
		methods: {
			changeQty(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},
			handleClose() {
				console.log(111);
				this.isShow = false;
				this.$emit('action', 1);
			},

			async handleBuy() {
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					num: this.quantity,
					id: this.info.id,
					// price: this.price
				})
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result,
					icon: 'success'
				});
				this.$emit('action', 1);
			},

			setStyle(val) {
				return {
					width: `25%`,
					textAlign: `center`,
					backgroundColor: val ? this.$theme.RGBConvertToRGBA(this.$theme.RISE, 20) : this.$theme.TRANSPARENT,
					color: val ? this.$theme.RISE : this.$theme.LOG_VALUE
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 1111;
		background-color: rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}

	.modal_wrapper {
		position: fixed;
		bottom: 0;
		left: 50%;
		right: 0;
		z-index: 11113;
		width: 100%;
		background-color: transparent;
		animation: popopUp 300ms forwards;
		transform: translateX(-50%);
	}
</style>