<template>
	<view>
		<view style="display: flex;align-items: center;">
			<view style="line-height: 48rpx;height: 48rpx;">
				<view style="color:#FFFFFF;font-size: 32rpx;display: inline-block;padding-right: 20rpx;">
					{{labels[0]}}
				</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click.stop="toggleData()"
					:style="$theme.setImageSize(32)">
				</image>
			</view>
			<view style="padding-left: 60rpx;">
				<view
					style="background-color: #FFFFFF;color:#221E37;border-radius: 24rpx;padding:12rpx;font-size: 20rpx;"
					@click="linkTradeLog()">
					{{$lang.CARD_BTN_TREAD_LOG}}
				</view>
			</view>
		</view>
		<view style="color:#FFFFFF;font-size: 56rpx;font-weight:500;line-height: 2;">
			{{showAmount?$util.formatMoney(info.value1):hideAmount}}
		</view>
		<view style="color:#FFFFFF;">
			<text style="font-size: 30rpx;padding-right: 20rpx;">USDT</text>
			<text
				style="font-size: 36rpx;font-weight:100;">{{showAmount?$util.formatMoney(info.value2):hideAmount}}</text>
		</view>
	</view>
</template>

<script>
	export default {
		// 
		name: 'CardItemSecond',
		props: {
			info: {
				type: Object,
				default: {}
			},
			// label。单独分开，否则会因数据请求慢，导致label未加载
			labels: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				showAmount: uni.getStorageSync('show') || false, // 显示金额
				hideAmount: '******', // 隐藏金额
			}
		},
		computed: {
			setLabelStyle() {
				return {
					padding: '0 20rpx 0 0',
				}
			},
		},
		methods: {
			// 机密数据显隐控制
			toggleData() {
				this.showAmount = !this.showAmount;
				this.$util.setShowData(this.showAmount);
			},
			// 跳转到交易记录
			linkTradeLog() {
				uni.navigateTo({
					url: this.$paths.CAPITAL_FLOW
				})
			},
		}
	}
</script>

<style>
</style>