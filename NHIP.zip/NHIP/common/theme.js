/* change theme */

// light dark
const THEMES =(mode)=>{
	BG_PAGE:''
}