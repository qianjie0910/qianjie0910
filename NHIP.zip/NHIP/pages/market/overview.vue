<template>
	<view :style="$util.setPageBG('bg_common')">
		<Header></Header>
				
		<view class="common_block" style="margin-top: 1vh;text-align: center;">
			<block v-for="(item,index) in $util.MARKET_TAB" :key="index">
				<view @click="handleChange(index)"
					style="display: inline-block; width:max-content;height: 20px;padding:16px 12px;text-align: center;font-size: 16px;"
					:style="$util.calcStyleTabActive(current === index)">
					{{item}}
				</view>
			</block>
		</view>
		<view>
			<TabOne v-if="current==0"></TabOne>
			<TabTwo v-if="current==1"></TabTwo>
			<TabThree v-if="current==2"></TabThree>
			<TabFour v-if="current==3"></TabFour>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import Tbas from '@/components/Tbas.vue';
	import TabOne from '@/components/market/TabOne.vue'
	import TabTwo from '@/components/market/TabTwo.vue'
	import TabThree from '@/components/market/TabThree.vue'
	import TabFour from '@/components/market/TabFour.vue'
	export default {
		components: {
			Header,
			Tbas,
			TabOne,
			TabTwo,
			TabThree,
			TabFour
		},
		data() {
			return {
				current: 0
			}
		},
		onShow() {},
		onLoad(op) {
			if (op.type) {
				this.current = Number(op.type);
			}
		},
		methods: {
			handleChange(val) {
				this.current = val;
			},
		},
	}
</script>