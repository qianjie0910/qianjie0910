<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.STOCK_DETAIL" @action="$u.route({type:'navigateBack'});"></CustomHeader>

		<view class="common_block">

			<Tbas :btns="$util.tabsMarketIndex()" @action="handleChangeTab"></Tbas>

			<view style="padding:6px 10px;display: flex;align-items: center;" :style="{color:$util.THEME.LABEL}">
				<view style="flex:50%;">종목명</view>
				<view v-if="current==0" style="flex:30%;text-align: right;padding-right: 16px;">현재 지수</view>
				<view v-else style="flex:30%;text-align: right;padding-right: 16px;">현재가</view>
				<view style="flex:20%;text-align: right;padding-right: 16px;">등락률</view>
			</view>

			<view style="overflow-y: scroll;height: 85vh;">
				<block v-for="(item,index) in list" :key="index">
					<view class="line" style="display: flex;align-items: center;padding: 4px 10px;">
						<view style="flex:50%;">
							<image mode="aspectFit" :src="item.logo" :style="$util.calcImageSize(24)"
								style="border-radius: 100%;"></image>
							<text style="font-size: 14px;font-weight: 500;padding-left: 10px;"
								:style="{color:$util.THEME.TEXT}">
								{{item.ko_name}}
							</text>
						</view>
						<view style="flex:30%;text-align: right;padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.returns>0)">
							{{$util.formatNumber(item.close)}}
						</view>
						<view style="flex:20%;text-align: right;padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.returns>0)">
							{{(item.returns*1).toFixed(2)}}%
						</view>
					</view>
				</block>
				<view style="text-align: center;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_GOOD_GOODS}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import Tbas from '@/components/Tbas.vue';
	export default {
		components: {
			CustomHeader,
			Tbas
		},
		data() {
			return {
				list: [],
				current: 0,
			}
		},
		mounted() {
			this.getList()
		},
		methods: {
			handleChangeTab(val) {
				this.current = val;
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.GOODS_ZHIBIAO, {
					current: this.current
				});
				this.list = result.data.data;
				uni.hideLoading();
			},
		},
	}
</script>