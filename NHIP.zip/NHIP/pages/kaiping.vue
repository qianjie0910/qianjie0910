<template>
	<view>
		<view style="padding-left:10%;padding-top: 70%;">
			<image src="../static/logo.png" mode="widthFix" style="width: 180px;margin-bottom: 10px;"></image>
			<view>로드 중({{progress}}%)</view>
		</view>
		<view class="progress-bar">
			<view class="progress" :style="{ height: progress + '%' }" style="width: 10px;"></view>
		</view>
	</view>
</template>

<script>
	export default {

		data() {
			return {
				progress: 0,
			};
		},
		onLoad() {
			let kaiping=uni.getStorageSync("kaiping")
			if(kaiping){
				uni.reLaunch({
					url:'/pages/home'
				})
			}
		},
		onShow() {
			this.updateProgress();
		},
		methods: {
			updateProgress() {
				const interval = setInterval(() => {
					if (this.progress < 100) {
						this.progress += 5; // 每次增加5%
					} else {
						clearInterval(interval);
						setTimeout(function(){
							uni.reLaunch({
								url:'/pages/home'
							})
						},1000)
						uni.setStorageSync("kaiping",1)
					}
				}, 100); // 每隔1秒增加一次进度
			}
		},
	}
</script>

<style>
	page {
		background-image: url('/static/bg_signin.png');
		background-size: cover;
		background-repeat: no-repeat;
	}

	progress-bar {
		width: 20px;
		/* 进度条的宽度 */
		height: 200px;
		/* 进度条的高度 */
		background-color: #f0f0f0;
		/* 进度条的背景颜色 */
		border: 1px solid #ccc;
		/* 进度条的边框 */
		position: relative;
	}

	.progress {
		background-color: #537ef7;
		/* 进度条的颜色 */
		position: absolute;
		right: 0;
		bottom: 0;
		width: 100%;
		transition: height 0.5s;
		/* 进度条高度变化的过渡效果 */
	}
</style>