<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader title="실명 인증" @action="$u.route({type:'navigateBack'});"></CustomHeader>
		<view class="common_block" style="padding-top: 20px;min-height: 80vh;">
			<view class="bg_auth"></view>
			<view
				style="display: flex;flex-direction: column;justify-content: center;align-items: center;margin-top:1vh;">
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;width: 86%;">
					<!-- <image mode="aspectFit" src="/static/user.png" :style="$util.calcImageSize(20)">
					</image> -->
					<view style="width: 60px;padding-left: 10px;">성명：</view>
					<input v-model="realName" type="text" placeholder="성함 입력"></input>
					<view style="margin-left: 10px;color:#707070;">{{calcSex}}</view>
				</view>
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;width: 86%;">
					<view style="width: 70px;padding-left: 10px;">생년월일：</view>
					<input v-model="cardNo" type="text" placeholder="주민등록번호 13자리를 입력해 주세요" maxlength=14
						placeholder-style="font-size:11px" @input="inputChange"></input>
					<image mode="aspectFit" :src="`/static/${showPwd?'show':'hide'}.png`" @click="handleShowPwd"
						:style="$util.calcImageSize(40)">
					</image>
				</view>
			</view>

			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
				<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">
					유효한 신분증 업로드
				</view>
			</view>

			<!-- <template v-if="userinfo.is_check!=0"> -->
			<view style="display: flex;align-items: center;justify-content: center;margin: 20px 0;">
				<view>
					<image :src="!formData.obverseUrl?`/static/fz.png`:formData.obverseUrl" @click="obverse_btn"
						style="margin-bottom: 20px;margin-top: 10px;width: 220px;height: 120px;"></image>
					<view style="text-align: center;" :style="{color:$util.THEME.PRIMARY}">주민등록증 앞면</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: center;margin: 20px 0;">
				<view>
					<image style="margin-bottom: 20px;margin-top: 10px;width: 220px;height: 120px;"
						:src="formData.reverseUrl?formData.reverseUrl:`/static/card_b.png`" @click="reverse_btn">
					</image>
					<view style="text-align: center;" :style="{color:$util.THEME.PRIMARY}">주민등록증 뒷면</view>
				</view>
			</view>
			<view class="common_btn btn_primary" style="width: 80%;margin:auto;margin-top: 20px;"
				@click="gain_aouonym()">실명 인증확인</view>

			<view style="margin: auto;margin-top: 20px;text-align: center;color:#707070;">※본인이 아닐경우, 이용에 불이익을 받으실 수
				있습니다.</view>

			<!-- </template> -->
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import Blob from 'blob';
	import md5 from 'js-md5'
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				realName: '', // 姓名
				cardNo: '', // 证件号码
				showPwd: true, // 是否显示完整证件号
				fullCardNo: '', // 证件号码完整值

				obverseUrl: '',
				reverseUrl: '',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				userinfo: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
			};
		},
		onLoad() {},
		mounted() {
			this.userInfo()
		},
		computed: {
			// 计算性别
			calcSex() {
				return this.fullCardNo.length < 7 ? '' : this.fullCardNo[7] == '1' ? '남성' : this.fullCardNo[7] == '2' ?
					'여성' : '';
			},
		},

		methods: {
			// ID号显隐
			handleShowPwd() {
				this.showPwd = !this.showPwd;
				this.formatCardNo(this.fullCardNo);
			},

			// 证件号码格式化
			formatCardNo() {
				this.cardNo = this.showPwd ? this.fullCardNo : this.fullCardNo.substring(0, 8) + `******`;
			},

			// ID号输入值变动
			inputChange(val) {
				const temp = val.detail.value;
				if (/^[0-9\-\\*]*$/.test(temp)) {
					console.log('?', temp)
					this.fullCardNo = temp;

					if (temp.length >= 6 && temp.length <= 14) {
						this.cardNo = `${temp.slice(0,6)}-${temp.slice(7,temp.length-7)}`;

						console.log('??', this.cardNo);

						// if (temp.length > 8) {
						// 	// this.cardNo = temp.substring(0, 8) + `*`.repeat(temp.length - 8); // 逐字符替换为*
						// 	// this.cardNo = temp.substring(0, 8) + `******`; // 超出后，一次性替换为******
						// 	// console.log('1', this.cardNo)
						// 	 this.cardNo = this.formatCardNo(temp);
						// }
					}
				} else {
					uni.$u.toast('정확한 주민등록번호를 입력해 주세요');
					// 解决数据不更新问题，此处必须这样写。
					setTimeout(() => {
						this.cardNo = "";
						this.fullCardNo = "";
					}, 0);
				}
				console.log('full:', this.fullCardNo);
			},
			obverse_btn() {
				if (this.obverseUrl) {

					this.previewImage(this.obverseUrl);
				} else {
					this.select_change('obverse');
				}
				uni.$u.toast('전면을 클릭하여 추가');
			},
			reverse_btn() {
				if (this.reverseUrl) {
					this.previewImage(this.reverseUrl);
				} else {
					this.select_change('reverse');
				}
				uni.$u.toast('뒷면을 클릭해서 추가했어요');
			},
			// 上传
			select_change(name) {
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
					success: res => {
						const imageFile = res.tempFiles[0];
						const maxSizeInBytes = 200 * 1024; // 200KB

						this.sfz_chagne({
							msg: `${name}Image:ok`,
							name,
							tempFilePath: imageFile.path,
							tempFile: imageFile
						})
					}
				});
			},

			// 预览
			previewImage(current = 0) {
				uni.previewImage({
					current,
					urls: [this.obverseUrl, this.reverseUrl],
				});
			},
			// 删除
			del_btn(name) {
				this.$emit('del', {
					name
				});
			},

			// 认证
			async gain_aouonym() {
				uni.showLoading({
					title: "제출 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth1', {
					real_name: this.realName,
					sex: this.calcSex,
					idno: this.fullCardNo, // 提交时，提交完整证件号码
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.HOME
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);
				}
			},

			async userInfo() {
				let list = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				this.realName = list.data.data.real_name
				this.fullCardNo = list.data.data.idno;
				this.formatCardNo(this.fullCardNo);
				this.userinfo = list.data.data
				this.formData.obverseUrl = list.data.data.front_image
				this.formData.reverseUrl = list.data.data.back_image
				// console.log(list.data.data, '1111111111111');
				uni.hideLoading();
			},

			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: "업로드 중"
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()
				var that = this;

				let mdd = md5("XPFXMedS" + Request + str_url + time)

				uni.uploadFile({
					url: this.$BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd, // 仅为示例，非真实的接口地址
					filePath: tempFilePath,
					name: 'file',

					success: (res) => {
						uni.hideLoading()
						var data = JSON.parse(res.data);
						// this.is_url = res.data
						console.log(1111, data, type, data[0].url)
						if (type == 1) {

							that.formData.obverseUrl = data[0].url;
						} else {
							that.formData.reverseUrl = data[0].url;

						}

					},
					error: (res) => {
						uni.hideLoading()
						console.log(3333, res)
					},
				});
			},
			// 插件上传身份证
			// 上传

			sfz_chagne(e) {
				console.log(222, e)
				var that = this;
				if (e.name == "obverse") {
					this.upimg(1, e.tempFilePath)

				} else if (e.name == "reverse") {
					this.upimg(2, e.tempFilePath)

				}
			},
			// 删除
			del_btn(e) {
				if (e.name == 'obverse') {
					this.formData.obverseUrl = '';
				} else if (e.name == 'reverse') {
					this.formData.reverseUrl = '';
				}
			},
		},
	};
</script>