<!-- 登入 注册 -->
<template>
	<view class="signin">
		<view style="background-image: url('/static/bg_signin.png');
	background-repeat: no-repeat;
	background-position: center center;
	background-size: cover;padding: 60px;opacity: 0.8;">
			<image mode="aspectFit" src="/static/app_logo.png" :style="$util.setImageSize(900,180)" ></image>
			
			<!-- <view class="text-center color-white font-size-30" style="padding-top: -100px;">KBSEC</view> -->
		</view>
		
		<view class="signin_wrapper" style="width: 80%;margin: 20px;">


			<view class="common_input_wrapper" style="width: 100%;">
				<image mode="aspectFit" src="/static/user.png" :style="$util.setImageSize(28)">
				</image>
				<input v-model="user" type="number" :placeholder="$lang.USER_NAME" maxlength="11"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<view class="common_input_wrapper" style="width: 100%;">
				<image mode="aspectFit" src="/static/password.png" :style="$util.setImageSize(28)">
				</image>
				<input v-model="password" type="password" :placeholder="$lang.PASSWORD"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<view v-if="!isSignIn" class="common_input_wrapper" style="width: 100%;">
				<image mode="aspectFit" src="/static/password.png" :style="$util.setImageSize(28)">
				</image>
				<input v-model="password2" type="password" :placeholder="$lang.PASSWORD_CONFIRM"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<view v-if="!isSignIn" class="common_input_wrapper" style="width: 100%;">
				<image mode="aspectFit" src="/static/code.png" :style="$util.setImageSize(28)">
				</image>
				<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<view style="width: 86%;position: relative;height: 24px;line-height: 24px;">
				<u-checkbox-group v-if="isSignIn" :checked="checked">
					<u-checkbox shape="square" :activeColor="$util.THEME.PRIMARY" :label="$lang.TIP_REMEMBER_PWD" 
						:labelColor="$util.THEME.TITLE" labelSize="24rpx"></u-checkbox>
				</u-checkbox-group>
				
				<view style="display: flex;align-items: center;position: absolute;right: 0;top: 0;"
					@click="handleChange()">
					<text style="font-size: 24rpx;margin-right: 4px;"
						:style="{color:$util.THEME.TITLE}">{{isSignIn?$lang.SIGN_UP:'로그인페이지'}}</text>
						<view class="arrow rotate_45" :style="$util.setImageSize(16)"></view>
				</view>
			</view>
			
			
			<view class="common_btn " :style="ys_checked&&user&&password?'background-color:#3d4f96;color:#fff':'background-color:#a9caff;color:#fff'"   style="margin-top: 20px;width: 95%;" v-if="isSignIn"
				@click="handleConfirm()">
				{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
			</view>
			
			<view class="common_btn btn_primary"  v-else style="margin-top: 20px;width: 95%;"
				@click="handleConfirm()">
				{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
			</view>
			<view class="margin-top-20" v-if="isSignIn">
				<u-checkbox-group  @change="ys_change">
					<u-checkbox shape="square" :activeColor="$util.THEME.PRIMARY" label="읽고 동의하세요"  name="yinsi"
						:labelColor="$util.THEME.TITLE" labelSize="24rpx"></u-checkbox>
					<view class="font-size-12 margin-left-5" style="color: #3d4f96;" @click="yinsi"> 개인정보처리방</view>
				</u-checkbox-group>
			</view>
		</view>
		<view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				user: "",
				password: '',
				password2: '',
				code: '',
				isSignIn: true,
				checked: false,
				ys_checked: false,

			};
		},
		onShow() {
			let userinput = uni.getStorageSync('userinput');
			let passinput = uni.getStorageSync('passinput');
			console.log(userinput);

			if (userinput) {
				this.user = userinput
			}
			if (passinput) {
				this.password = passinput
			}
		},
		methods: {
			ys_change(item){
				console.log(item,!item);
				if(item.length==0){
					this.ys_checked=false
				}else{
					this.ys_checked=true
				}
			},
			yinsi(){
				uni.navigateTo({
					url:"/pages/my/components/other/privacyAgreement"
				})
			},
			handleChange() {
				this.isSignIn = !this.isSignIn;
				// this.user = "";
				// this.password = "";
				// this.password2 = "";
				// this.code = "";
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast("로그인 전화번호를 입력해 주세요");
					return false;
				}
				if (this.password == '') {
					uni.$u.toast("로그인 비밀번호를 입력해 주세요");
					return false;
				}
				if (!this.isSignIn && this.password2 == '') {
					uni.$u.toast(this.$lang.PASSWORD_CONFIRM);
					return false;
				}
				if (!this.isSignIn && this.password2 != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.$u.toast(this.$lang.INVITATION_CODE);
					return false;
				}
				return true;
			},

			async signIn() {
				console.log(this.ys_checked);

				if(!this.ys_checked&&this.isSignIn){
					uni.$u.toast("개인정보보호정책을 읽고 동의해 주세요");
					return
				}
				uni.showLoading({
					title: this.$lang.TIP_SIGNIN_ING,
				})
				const result = await this.$http.post(this.$http.API_URL.SIGN_IN, {
					username: this.user,
					password: this.password,
				})
				if (result.data.code == 0) {
					uni.hideLoading();
					const token = result.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.HOME,
						});
						this.$router.go(0)
					}, 500)
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
			async register() {
				uni.showLoading({
					title: this.$lang.TIP_SIGNUP_ING,
				})
				const result = await this.$http.post(this.$http.API_URL.SIGN_UP, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.password,
					invite: this.code,
					code: 123456,
				})
				if (result.data.code == 0) {
					uni.hideLoading();
					uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
					this.signIn();
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>