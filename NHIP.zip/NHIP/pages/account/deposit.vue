<!-- 银转证  存款 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.DEPOSIT" @action="handleBack()"></CustomHeader>

		<view style="display: flex;align-items: center;padding:4px 20px;">
			<image src="/static/kr.png" mode="aspectFit" :style="$util.calcImageSize(60)"
				style="border-radius: 100px;background-color:#bdd8ffa1;padding:6px;"></image>
			<view style="padding-left: 10px;" :style="{color:$util.THEME.TITLE}">KRW</view>
		</view>
		<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;">
			<view style="font-size: 28px;font-weight: 900;" :style="{color:$util.THEME.PRIMARY}">
				<text style="margin-right: 20px;">{{showAmount?$util.formatNumber(userInfo.money)+'원':hideAmount}}</text>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.calcImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="padding:20px;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
			<view class="common_btn btn_primary" style="width: 60%;margin:auto;" @click="handleCustomer()">
				고객센터에 문의하세요
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				userInfo: {},
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
			};
		},
		onLoad(option) {
			this.getInfo()
		},
		methods: {
			// 资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			async handleCustomer() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>