<!-- 绑定银行卡 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader title="출금계좌 등록" @action="handleBack()"></CustomHeader>

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
			<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">
				출금계좌 등록
			</view>
		</view>

		<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
			<view class="common_block" style="width: 80%;padding:20px;">
				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;"
					:style="{color:$util.THEME.TEXT}">
					<view style="width: 60px;display: inline-block;padding-left: 10px;">성명:</view>
					<template v-if="isRenewal">
						<input v-model="realname" type="text" :placeholder="$lang.REAL_NAME"
							:placeholder-style="$util.setPlaceholder()"></input>
					</template>
					<template v-else>
						<view style="display: inline-block;"> {{info.realname}}
						</view>
					</template>
				</view>

				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;"
					:style="{color:$util.THEME.TEXT}">
					<view style="width: 60px;display: inline-block;padding-left: 10px;">은행명:</view>
					<template v-if="isRenewal">
						<input v-model="bank_name" type="text" :placeholder="$lang.BANK_NAME"
							:placeholder-style="$util.setPlaceholder()"></input>
						<view @click="handleShowBankList()"
							style="width:80px;height: 23px;line-height: 23px; background-color:#c7ddff;text-align: center;margin-right: 3px;border-radius: 6px;">
							은행 선택</view>
						<!-- <template v-if="showBankList">
							<input v-model="value1" type="text" :placeholder="$lang.BANK_NAME"
								:placeholder-style="$util.setPlaceholder()" ></input>
						</template>
						<template v-else>
							<view @click="handleShowBankList()" style="width:80px;height: 23px;">은행 선택</view>
						</template> -->
						<u-picker :show="showBankList" :columns="bankList" @cancel="showBankList = false"
							@confirm="handleConfirmBank" cancelText="취소" confirmText="확신하는"></u-picker>
					</template>
					<template v-else>
						<view style="display: inline-block;"> {{info.bank_name}}
						</view>
					</template>
				</view>

				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;"
					:style="{color:$util.THEME.TEXT}">
					<view style="width: 60px;display: inline-block;padding-left: 10px;">계좌번호:</view>
					<template v-if="isRenewal">
						<input v-model="card_sn" type="text" :placeholder="$lang.BANK_CARD"
							:placeholder-style="$util.setPlaceholder()"></input>
					</template>
					<template v-else>
						<view style="display: inline-block;"> {{info.card_sn}}
						</view>
					</template>
				</view>
			</view>
			<template v-if="isRenewal">
				<view style="margin-top: 20px;">
					<view class="common_btn btn_primary"
						style="border:1px solid transparent;width: 120px;display: inline-block;margin:10px 20px;"
						@click="replaceBank()">
						{{$lang.CONFIRM}}
					</view>
					<view class="common_btn btn_secondary" style="width: 120px;display: inline-block;margin:10px 20px;"
						@click="handleCancel()">
						{{$lang.CANCEL}}
					</view>
				</view>
			</template>
			<template v-else>
				<view class="common_btn btn_primary" style="width:80%;margin-top: 20px;" @click="renewal()">등록하기</view>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				showBankList: false, // 是否显示银行备选列表
				info: {},
				isRenewal: false,
				realname: '', // 开户人
				bank_name: '', // 银行名称
				card_sn: '', // 卡号
			};
		},
		computed: {
			// 银行备选列表， u-picker中需要套一层数组
			bankList() {
				return [this.$util.LIST_BANK];
			}
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleShowBankList() {
				this.showBankList = true;
			},
			handleConfirmBank(e) {
				console.log('e:', e);
				this.bank_name = e.value[0];
				this.showBankList=false;
			},
			renewal() {
				this.isRenewal = true;
			},
			handleCancel() {
				this.isRenewal = false;
				this.replaceBank();
			},
			// 换绑银行卡
			async replaceBank() {
				const result = await this.$http.post(this.$http.API_URL.USER_BIND_CARD, {
					realname: this.realname,
					bank_name: this.bank_name,
					card_sn: this.card_sn,
				})
				if (result.data.code == 0) {
					uni.$u.toast('은행 카드 정보가 성공적으로 제출되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},

			//用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {})
				console.log(result);
				if (result.data.code == 0) {
					// 未有真实姓名，跳转到实名认证
					if (!result.data.data.real_name) {
						uni.navigateTo({
							url: this.$util.PAGE_URL.ACCOUNT_AUTH,
						})
					}
					// 未有银行卡信息，自动切换到绑卡状态
					if (!result.data.data.bank_card_info) {
						this.isRenewal = true;
					} else {
						this.info = result.data.data.bank_card_info;
					}
				}
			},
		},
	}
</script>