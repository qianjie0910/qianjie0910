<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="$lang.SEARCH" @action="$u.route({type:'navigateBack'});"></CustomHeader>

		<view style="background-color: #FFFFFF;min-height: 100vh;padding-top:20rpx;">
			<view style="margin:40rpx;border:1px solid #F1F1F1">
				<u-search shape="square" placeholder="종목명∙종목코드 입력" v-model="keyword" :showAction="false" height="40px"
					:searchIconColor="$util.THEME.PRIMARY" searchIconSize="30" bgColor="#FFFFFF" @clear="keyword=''"
					:actionText="$lang.SEARCH" @search="searchButton" @custom="searchButton"></u-search>
			</view>

			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
				<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
				<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">
					검색기록
				</view>
				<image mode="aspectFit" src="/static/delete.png" :style="$util.setImageSize(44)"
					style="margin-left: auto;" @click="clearKeywords()"></image>
			</view>

			<view style="display: flex;align-items: center;margin:0 10px;padding:10px;flex-wrap: wrap;">
				<template v-if="keywords.length>0">
					<block v-for="(item,index) in keywords" :key="index">
						<view style="padding:4px 10px;margin:4px;border-radius: 4px;" @click="selectedItem(item)"
							:style="{backgroundColor:'#F1F1F1'}">{{item}}</view>
					</block>
				</template>
			</view>


			<view class="common_block" style="padding:0 10px 10px 10px;">
				<template v-if="!list || list.length<=0">
					<view
						style="display: flex;align-items: center;flex-direction: column;justify-content: center;padding:30%;">
						<image mode="aspectFit" src="/static/search_result.png" :style="$util.setImageSize(160)">
						</image>
						<view class="font-size-20 text-center" :style="{color:$util.THEME.TITLE}">기록 없음
						</view>
					</view>
				</template>

				<template v-else>
					<view style="">
						<view class="box" style="border-radius: 10px; " v-if="list">
							<view class="top flex flex-b padding-10" style="padding-bottom: 0;">
								<view class="flex-2  font-size-16">주식/코드</view>
								<view class="flex-1 t-c  font-size-16">등락률</view>
								<view class="t-r font-size-16" style="margin-left: 10px;">최신</view>
							</view>

							<u-gap height="2" bgColor="#bbb" marginTop="10px" marginBottom="10px"></u-gap>

							<EmptyData v-if="list && list.length<=0"></EmptyData>

							<block v-for="(item,index) in list">
								<view class=" box-item flex"
									style="padding: 4px 0;border-bottom:1px solid #F1F1F1;line-height: 2.4;"
									@click="$u.route($util.PAGE_URL.STOCK_OVERVIEW,{code:item.number_code,id:item.id});">
									<view style="flex:1 0 6%;">
										<template v-if="!item.logo || item.logo==''">
											<view :style="$util.setImageSize(80)"
												style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;font-size: 18px;">
												{{item.name.slice(0,1)}}
											</view>
										</template>
										<template v-else>
											<image mode="aspectFit" :src="setLogo(item.logo)"
												:style="$util.setImageSize(80)" style="border-radius: 100%;"></image>
										</template>
									</view>
									<view style="flex:1 0 54%;">
										<view style="color: #555555;line-height: 1.6;padding:0 10rpx;">
											{{item.name}}
										</view>
										<view :style="{color:$util.THEME.PRIMARY}" style="padding-left: 10rpx;">
											{{item.number_code}}
										</view>
									</view>

									<view style="flex:1 0 20%;" :class="item.rate>0?'red':'green'">
										{{$util.formatNumber(item.current_price)}}
									</view>
									<view style="flex:1 0 20%;padding-right: 6rpx;"
										:style="$util.calcStyleRiseFall(item.rate>0)">
										{{item.rate>0?'+':''}}{{item.rate}}%
									</view>
								</view>
							</block>
						</view>
					</view>
				</template>
			</view>
		</view>
	</view>
</template>
<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				pager: {
					page: 1,
					limit: 20
				},
				keyword: "",
				keywords: [],
				gp_select: [{
					name: "국내",
				}, {
					name: "해외",
				}],
				gp_index: 0,
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
			console.log(this.keywords)
		},
		methods: {
			setLogo(url) {
				console.log(url);
				return this.$BaseUrl + url;
			},

			// 清空搜索记录
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = []; // 手动清理缓存数据
				this.list = []; // 查询结果重置
			},

			// 选中一项搜索历史词条 
			selectedItem(item) {
				this.keyword = item;
				this.searchButton()
			},

			gp_select_click(e) {
				this.storehouse = ""
				this.gp_index = e.index
			},
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.HOME
				});
			},

			//搜索
			async searchButton() {
				if (this.keyword == '') {
					uni.$u.toast('검색어는 비워둘 수 없습니다. 다시 검색해 주세요');

				} else {
					uni.showLoading({
						title: "검색...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					const result = await this.$http.post('api/product/list', {
						key: this.keyword,
						page: 1,
						limit: 9999999,
						gp_index: this.gp_index
					})
					uni.hideLoading();
					if (result.data.data.length > 0) {
						this.list = result.data.data
						console.log(8888, result.data.data)
						if (this.keywords.indexOf(this.keyword) < 0) {
							this.keywords.push(this.keyword);
							uni.setStorageSync("keywords", this.keywords)
						}
					}
				}
			},

		}
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		min-height: 100vh;
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;
	}
</style>