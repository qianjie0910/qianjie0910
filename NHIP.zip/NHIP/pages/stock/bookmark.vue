<template>
	<view :style="$util.setPageBG('bg_bookmark')">
		<Header></Header>

		<view style="margin-top: 14vh;">
			

			
			<view class="common_block">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view @click="productDetails(item.goods.code,item.id)"
						style="padding-top: 24rpx;margin-left:10px;display: flex;align-items: center;margin:6px 10px;padding-bottom: 6px;">
						<view style="display: inline-block;flex:6%;">
							<template v-if="!item.goods.logo || item.goods.logo==''">
								<view :style="$util.calcImageSize(80)" style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;font-size: 18px;">{{item.goods.name.slice(0,1)}}</view>
							</template>
							<template v-else>
								<image mode="aspectFit" :src="$BaseUrl+item.goods.logo" :style="$util.calcImageSize(80)" style="border-radius: 100%;"></image>
							</template>	
							
							<!-- <image mode="aspectFit" :src="$BaseUrl+item.goods.logo" :style="$util.setImageSize(80)"
								style="border-radius: 100%;"></image> -->
						</view>

						<view style="flex:44%;padding-left: 6px;font-size: 30rpx;"
							:style="{color:$util.THEME.STOCK_NAME}">
							{{item.goods.name}}
						</view>
						<view style="flex:45%;text-align: right;margin-right: 10px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							<view style="padding-right:4px;padding-right: 10px;font-size: 30rpx;font-weight: 700;"
								:style="{paddingBottom:item.goods.rate>0?'12rpx':''}">
								{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
							</view>
							<view style="text-align: right;padding-right: 10px;font-size: 25rpx;"
								:style="{color:$util.THEME.STOCK_NAME}">{{$util.formatNumber(item.goods.current_price)}}<text style="padding:0 4px">원</text>
							</view>
						</view>

						<view style="flex:5%;">
							<image mode="aspectFit" src="/static/star.png" :style="$util.setImageSize(24)"
								@click.stop="handleClickDelProduct(item.goods.gid)"></image>
						</view>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			EmptyData,
		},
		data() {
			return {
				list: [],
				timer: null,
			}
		},
		onShow() {
			this.getList()
			this.startTimer()
		},
		onHide() {
			clearInterval(this.timer);
		},
		computed: {
			best() {
				return this.list.sort((a, b) => b.goods.rate - a.goods.rate).slice(0, 3);
			}
		},
		methods: {
			productDetails(code, id) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&id=${id}`
				});
			},
			//定时器
			startTimer() {
				this.timer = setInterval(() => {
					this.getList();
				}, 5000);
			},

			async getList() {
				if (this.list.length <= 0) {
					uni.showLoading({
						title: this.$lang.LOADING,
					})
				}
				const result = await this.$http.get(this.$http.API_URL.COLLECT_LIST, {});
				if (this.list.length <= 0 || result.data.code == 0) {
					uni.hideLoading();
				}
				this.list = result.data.data.list;
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				const result = await this.$http.post(this.$http.API_URL.COLLECT_EDIT, {
					gid: gid,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>