<!-- 우승기록 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader title="청약 배정 내역" @action="handleBack()"></CustomHeader>

		<view class="common_block" style="padding:20px 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px solid #ccc;margin: 4px;background-color: #FFF;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>{{item.goods.name}}</view>
						<view style="font-size: 16px;color:seagreen;">
							<view v-if="item.status==2" class="" @click="subscription(item)">구독하다</view>
						</view>
					</view>
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>종목코드</view>
						
						<view>{{item.goods.code}}</view>
					</view> -->
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$util.THEME.TIP}">기관 공모 수량</view>
						<view :style="{color:$util.THEME.PRIMARY}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.apply_amount)}}주
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$util.THEME.TIP}">공모 가격</view>
						<view :style="{color:$util.THEME.PRIMARY}" style="text-align: right;">
							{{$util.formatNumber(item.price)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$util.THEME.TIP}">배정 수량</view>
						<view :style="{color:$util.THEME.PRIMARY}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.success)}}주
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$util.THEME.TIP}">공모 금액</view>
						<view :style="{color:$util.THEME.PRIMARY}" style="text-align: right;">
							{{$util.formatNumber(item.success_num_amount)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					

					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$util.THEME.TIP}">
						<view>거래 일자</view>
						<view>{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$util.THEME.TIP}">
						<view>거래 코드</view>
						<view>{{item.order_sn}}</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		onLoad(option) {
			this.shengou()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			// 우승기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-success-log', {
					// status: 2,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

			async subscription(item) {
				let list = await this.$http.get('api/goods-shengou/pay', {
					id: item.id
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.data.message);
					if (list.data.data.success == 0) {
						setTimeout(() => {
							uni.navigateTo({
								url: this.$util.PAGE_URL.SERVICE
							});
						}, 500)
					} else {
						uni.redirectTo({
							url: this.$util.PAGE_URL.TRADE_IPO_SUCCESS,
						});
						this.$router.go(0)
					}
				} else {
					uni.$u.toast(list.data.data.message);
				}
			},
		},
	}
</script>