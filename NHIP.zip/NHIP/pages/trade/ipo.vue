<!-- 新股申购 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader title="공모주 청약" @action="handleBack()"></CustomHeader>

		<view class="common_block"
			style="display: flex;flex-direction: column; align-items: center;justify-content:space-around;padding: 20px;">
			<image src="/static/trade_left.png" mode="widthFix" @click="handleTradeLog()"></image>
			<view style="height: 20px;"></view>
			<image src="/static/trade_right.png" mode="widthFix" @click="handleBuySuccess()"></image>
		</view>

		<view class="common_block"
			style="min-height: 50vh;border-top-left-radius: 15px;border-top-right-radius: 15px;margin-top: 20px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<template v-if="current == 0">
				<block v-for="(item,index) in list" :key="index">
					<view class="line" style="padding: 10px;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view>
								<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
								<view :style="{color:$util.THEME.TEXT}" style="font-size: 18px;display: inline-block;margin-left: 10px;">{{item.goods.code}} {{item.goods.name}}</view>
							</view>
							<view @click="handleDetail(item.id)" class="btn_small"
								style="padding: 4px 8px;border-radius: 100px;" :style="{backgroundColor:$util.THEME.PRIMARY,color:'#FFFFFF'}">청약 신청</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
							<view :style="{color:$util.THEME.TIP}">청약 금액</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.price)}}<text style="padding:0 4px">원</text></view>
						</view>
						<!-- <view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
							<view :style="{color:$util.THEME.TIP}">수익률</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.shiying)}}</view>
						</view> -->
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
							<view :style="{color:$util.THEME.TIP}">청약 날짜</view>
							<view :style="{color:$util.THEME.TIP}">{{item.shengou_date}}</view>
						</view>
					</view>
				</block>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 2rpx solid #e0e0e0;padding-bottom:20rpx;">
						<view class="display approve">
							<view>
								<view class="corporation">{{item.goods.name}}</view>
								<view class="area" v-if="item.goods.locate=='깊은'">
									<view class="deep">{{item.goods.locate}}</view>
									<view class="deep-number">{{item.goods.code}}</view>
								</view>
								<view class="area" v-if="item.goods.locate=='북쪽'">
									<view class="north">{{item.goods.locate}}</view>
									<view class="north-number">{{item.goods.code}}</view>
								</view>
								<view class="area" v-if="item.goods.locate=='상하이'">
									<view class="shanghai">{{item.goods.locate}}</view>
									<view class="shanghai-number">{{item.goods.code}}</view>
								</view>
							</view>
							<view class="subscription-times">구독 시간<text>{{item.shengou_date}}</text> </view>
						</view>

						<view class="display" style="margin-top: 10rpx;">
							<view class="display price">구독
								가격<text>{{$util.formatNumber(item.price)}}</text>
							</view>
							<view class="display price">
								주가수익비율<text>{{$util.formatNumber(item.shiying)}}</text>
							</view>
						</view>
						<view class="display price">
							순환<text>{{$util.formatNumber(item.fa_amount)}}</text>
						</view>
					</view>
				</block>
			</template>

			<u-modal :show="show" title="공모주 청약 신청" @cancel="cancel" @confirm="confirm()" :showCancelButton='true'
				content='청약신청을 원하시면 확인을 클릭하세요' :cancelText="$lang.CANCEL" :confirmText="$lang.CONFIRM">
			</u-modal>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				current: 0,
				list: [],
				curId: '', // 当前选中数据的ID值
				show: false, // 购买前二次确认的弹层
			};
		},
		onLoad(item) {},
		onShow() {
			this.getList();
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},

			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				this.curId = val;
				this.show=true;
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm() {
				this.purchase()
				this.show = false;
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				const result = await this.$http.post('api/goods-shengou/doOrder', {
					num: this.value,
					id: this.curId,
					// price: this.price
				})
				if (result.data.code == 0) {
					uni.showLoading({
						title: "청약신청이 진행중입니다. 잠시만 기다려 주세요",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						this.handleTradeLog();
						uni.hideLoading();
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(this.$http.API_URL.TRADE_IPO_LIST, {
					type: this.current + 1, // 传参 1或2
				})
				this.list = result.data.data;
				uni.hideLoading();
			},

			//구독기록 订阅记录
			handleTradeLog() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO_LOG
				});
			},
			//우승기록 获胜记录
			handleBuySuccess() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO_SUCCESS
				});
			},
		}
	}
</script>