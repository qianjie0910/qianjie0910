<!-- 申购 记录 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader title="전체내역" @action="handleBack()"></CustomHeader>
		<view class="common_block" style="padding:20px 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px solid #ccc;margin: 4px 20px;background-color: #FFF;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>{{item.goods.name}}</view>
						
						<view style="font-size: 16px;color:#ea3544;">{{item.message}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>종목코드</view>
						
						<view>{{item.goods.code}}</view>
					</view>
					
					
					
					
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>시장구분</view>
						
						<view>코스닥</view>
					</view>
					
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>확정공모가</view>
						
						<view>{{$util.formatNumber(item.price)}}원</view>
					</view>
					
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>상장공모</view>
						
						<view>{{item.goodsshengou.fa_amount}}</view>
					</view>
					 
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>공모금액</view>
						
						<view>{{item.goodsshengou.fa_muji_zijin}}</view>
					</view>
					
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view>배정공고일 </view>
						
						<view>{{item.goodsshengou.gb_date}}</view>
					</view>
					
					
					
					<view style="display: flex;align-items: center;padding-bottom: 6px;">
						<!-- <view style="flex:20%;" :style="{color:$util.THEME.TITLE}">청약 수량</view>
						<view :style="{color:$util.THEME.PRIMARY}"
							style="flex:30%;text-align: right;">
							1,477,500<text style="padding:0 4px">주</text>
						</view> -->
						<view style="flex:20%;" :style="{color:$util.THEME.TITLE}">청약 수량</view>
						<view :style="{color:$util.THEME.PRIMARY}" style="flex:30%;text-align: right;">
							{{$util.formatNumber(item.apply_amount)}}<text style="padding:0 4px">주</text>
						</view>
					</view>
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view :style="{color:$util.THEME.TITLE}">청약 총금액</view>
						<view style="font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.apply_num_amount)}}<text style="padding:0 4px">원</text>
						</view>
					</view> -->
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$util.THEME.TITLE}">
						<view>매입 시간</view>
						<view>{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$util.THEME.TITLE}">
						<view>거래 코드</view>
						<view>{{item.order_sn}}</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		onLoad(option) {
			this.shengou();
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			// 新股申购记录
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-apply-log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
		},
	}
</script>