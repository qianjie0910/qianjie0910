<!-- 折价交易 -->
<template>
	<view :style="$util.setPageBG('bg_common')">
		<CustomHeader :title="`공모주청약`" @action="handleBack()"></CustomHeader>
		<view class="common_block"
			style="display: flex;flex-direction: column; align-items: center;justify-content:space-around;padding: 20px;">
			<image src="/static/trade_left.png" mode="widthFix" @click="handleTradeLog()"></image>
			<view style="height: 20px;"></view>
			<image src="/static/trade_right.png" mode="widthFix" @click="handleTradeLog1()"></image>
		</view>

		<view class="common_block"
			style="min-height: 50vh;border-top-left-radius: 15px;border-top-right-radius: 15px;margin-top: 20px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view class="line" style="margin:10px;padding:16px 12px;">


					<view class="flex flex-b ">
						<view class="font-size-16 flex">
							<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)">
							</image>
							<view style="margin-left: 10px;">
								종목명
							</view>
						</view>
						<view class="bold font-size-16">{{item.goods.name}}</view>
					</view>
					<view class="flex flex-b font-size-16 margin-top-10">
						<view class="font-size-16">종목코드</view>
						<view style="color: blue;">{{item.goods.code}}</view>
					</view>
					<view class="flex flex-b font-size-16 margin-top-10">
						<view class="font-size-16">할인율</view>
						<view class=" font-size-16">{{item.zhekou}}%</view>
					</view>
					<view class="flex flex-b font-size-16 margin-top-10">
						<view class="font-size-16">총 배정 주식 수</view>
						<view style="color: red;" class="bold font-size-16">{{item.fa_amount}}</view>
					</view>




					<!-- <view class="flex flex-b font-size-16 margin-top-10">
						<view class="font-size-16">현재가</view>
						<view  class="bold font-size-16">{{item.goods.current_price}}</view>
					</view>
					 -->

					<view class="common_btn btn_primary margin-top-10"
						style="background-color:#F0F1F3;line-height: 32px;" :style="{color:$util.THEME.TITLE}"
						@click="handleDetail(item)">{{$lang.DETAIL}}</view>
				</view>
			</block>
		</view>

		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_block common_popup" style="min-height:30vh;margin:auto">
					<view class="popup_header" style="color:#FFFFFF">청약</view>

					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
						<text :style="{color:$util.THEME.TITLE}">현재가</text>
						<text :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(detail.goods.current_price)}}</text><text
							style="padding:0 4px">원</text>
					</view>
					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
						<text :style="{color:$util.THEME.TITLE}">할인율</text>
						<text :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(detail.zhekou)}}</text><text
							style="padding:0 4px">%</text>
					</view>
					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
						<text :style="{color:$util.THEME.TITLE}">청약가</text>
						<text :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(detail.goods.current_price*0.01*detail.zhekou)}}</text><text
							style="padding:0 4px">원</text>
					</view>
					<!-- <view class="common_input_wrapper"
						style="margin:20px;background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
						<view style="width: 20px;"></view>
						<input v-model="amount" :placeholder="$lang.TIP_BUY_COUNT" type="number"
							style="width: 80%;"></input>
						<view style="padding:0 4px">주</view>
					</view>


					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<view :style="{color:$util.THEME.TITLE}">매입금액</view>
						<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(buyAmount)}}</view><text
							style="padding:0 4px">원</text>
					</view>



					<view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<text :style="{color:$util.THEME.TITLE}">사용 가능 잔액 </text>
						<text :style="{color:$util.THEME.PRIMARY}">{{availBal}}</text><text
							style="padding:0 4px">원</text>
					</view> -->


					<view style="display: flex;justify-content: space-evenly;margin:20px 0;transform: scaleY(0.75);">
						<view class="common_btn btn_primary" style="width: 30%;" @click="handleConfirm"> {{$lang.BUY}}
						</view>
						<view class="common_btn btn_secondary" style="width: 30%;" @click="handleCancel">
							{{$lang.CANCEL}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				detail: {},
				isShow: false, // 显示弹层
				amount: "", // 金额
				password: '',
				leverList: [], // 杠杆值数组
				current: 0,
				availBal: 0,
			}
		},
		onShow() {
			this.getList()
			this.available()
		},
		computed: {
			// 当前选择杠杆值
			curLever() {
				return this.leverList[this.current];
			},
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.amount / Number(this.curLever.index);
			}
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			//구독기록 订阅记录
			handleTradeLog() {
				uni.navigateTo({
					url: "/pages/trade/peishouLog"
				});
			},
			handleTradeLog1() {
				uni.navigateTo({
					url: "/pages/trade/peishouSuccess"
				});
			},
			handleChgangeLever(val) {
				this.current = val;
			},
			async handleDetail(item) {
				this.isShow = true;
				this.detail = item;
			},
			handleCancel() {
				this.isShow = false;
				this.amount = "";
				this.password = "";
				this.current = 0;
			},
			async handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				// if (this.amount == '') {
				// 	uni.$u.toast(this.$lang.TIP_BUY_COUNT);
				// 	return false;
				// }

				return true;
			},
			async buy() {

				const result = await this.$http.post('api/goods-scramble/doOrder', {
					id: this.detail.id,
					num: this.amount,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					uni.navigateTo({
						url: "/pages/trade/peishouLog"
					});
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get('api/goods-scramble/calendar', {})
				this.list = result.data.data
				uni.hideLoading();
			},
			async available() {
				this.leverList = [];
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				this.availBal = this.$util.formatNumber(result.data.data.money);
				this.leverList = [{
					name: 1,
					index: 1
				}];
				if (result.data.data.ganggan) {
					this.leverList.push(...result.data.data.ganggan);
				}
			},
		},
	}
</script>