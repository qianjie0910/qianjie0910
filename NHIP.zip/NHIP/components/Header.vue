<template>
	<view class="padding-top-20" style="display: flex;align-items: center;">
		<view style="flex:30%;"></view>
		<view style="flex:50%;text-align: center;">
			<image src="/static/logo.png" mode="heightFix" :style="$util.setImageSize(40)"></image>
		</view>
		<view style="flex:20%;margin-right: 30rpx;text-align: right;" @click="linkSearch()">
			<image src="/static/search.png" mode="aspectFit" :style="$util.setImageSize(40)"></image>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Header",
		data() {
			return {};
		},
		methods: {
			// 跳转到搜索
			linkSearch() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SEARCH
				})
			},
		}
	}
</script>