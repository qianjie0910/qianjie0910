<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="line" style="margin-bottom:20px;padding:10px 0;">
				<view style="display: flex;align-items: center;">
					<view style="flex:20%;" :style="{color:$util.THEME.TIP}">입금</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="flex:65%;font-size: 18px;font-weight: 700;text-align: center;">
						{{$util.formatNumber(item.money)}}
						<text style="padding:0 4px">원</text>
					</view>
					<view style="flex:15%;text-align: center;" :style="{color:$util.THEME.RISE}">
						{{item.desc_type}}
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">주문 번호:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">날짜 시간:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">거부 이유:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:3%;">
						<image :src="item.icon" :style="$util.calcImageSize(12)"></image>
					</view>
					<text style="flex:97%;white-space:pre-wrap;"  :style="{color:item.color}" >{{item.text}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogDeposit",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_DEPOSIT, {})
				if (result.data.code == 0) {
					this.list = result.data.data
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>