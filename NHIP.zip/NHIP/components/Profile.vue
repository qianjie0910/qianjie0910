<!-- 用户基本信息 -->
<template>
	<view >
		<view style="display: flex;align-items: center;padding-bottom: 10px;">
			<view style="flex:20%;text-align: center;" @click="handleLink()">
				<image style="border-radius: 100px;" mode="aspectFit" :src="info.avatar?info.avatar:'/static/avatar.png'" :style="$util.calcImageSize(130)"></image>
			</view>
			<view style="flex:60%;padding-left: 10px;">
				<view style="font-size: 36rpx;text-align: left;" :style="{color:$util.THEME.TEXT}">
					{{info.nick_name}}
				</view>
				<view style="font-size:26rpx;text-align: left;color:#3C1E20;" >
					{{info.p_mobile}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true
			};
		},
		methods:{
			// 进入信息修改页面
			handleLink(){
				uni.navigateTo({
					url:this.$util.PAGE_URL.ACCOUNT_AVATAR,
				})
			},
			
			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_WITHDRAW
				})
			},
		}
	}
</script>

<style>

</style>