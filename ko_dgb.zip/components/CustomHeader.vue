<template>
	<view>
		<view class="flex flex-b  padding-20" style="background-color: #1f4082;">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 36rpx;height: 36rpx;"
				@click="actionEvent()"></image>

			<!-- <image src="/static/more.png" mode="widthFix" style="width:25px;" @click="showDrawer('showLeft')"></image> -->
			<view class="flex">
			<view class="bold" style="color: #fff;font-size: 20px;">상상인증권</view>
			<image src="/static/logo.png" mode="widthFix" style="width:25px;height: 25px; border-radius: 15px;margin-left: 10px;"></image>
			</view>

			<image src="/static/sousuo.png" mode="widthFix" style="width:25px;" @click="$u.route('/pages/search');">
			</image>
		</view>


		<!-- <uni-drawer ref="showLeft" mode="left" :width="320" @change="change($event,'showLeft')">
			<view style="background-color: #1f4082;padding: 10px" class="flex flex-b">
				<image src="../static/APPlogo.png" mode="widthFix" style="width: 150px;"></image>

				<image src="../static/close.png" mode="widthFix" style="width: 30px;" @click="closeDrawer('showLeft')">
				</image>
			</view>
			<view class="flex">
				<view class="flex-1 justify-center text-center"
					style="background-color: #f7f7f7;border-right: 1px solid #d7d7d7;height: 100vh">

					<view style="border-bottom: 1px solid #d7d7d7 ;padding: 10px;" v-for="(item,index) in list"
						:style="index==current?'background-color: #fff;':'background-color: #f7f7f7;'"
						@click="current=index">
						<image :src="item.logo" mode="widthFix" :style="item.style"></image>
						<view class="bold font-size-12">{{item.name}}</view>
					</view>
				</view>
				<view class="flex-2  margin-left-10 justify-start align-start" style="height: 100vh">
					<view style="margin: 20px 10px;">
						<view class="bold font-size-16"
							style="color: #004d79;border-bottom:  1px solid #d7d7d7;padding-bottom: 10px;">
							{{list[current].title}}
						</view>
						<view class="bold padding-15" style="border-bottom:  1px solid #d7d7d7;padding-bottom: 10px;"
							@click="tiaozhuan(item)" v-for="(item,index) in list[current].zi">{{item.name}}</view>
					</view>
				</view>
			</view>
		</uni-drawer> -->

	</view>

</template>

<script>
	export default {
		name: "CustomHeader",
		data() {
			return {
				showRight: false,
				// list: [{
				// 		name: "하이투자증권",
				// 		logo: "/static/app_logo.png",
				// 		title: "회사소개",
				// 		style: "width:30px;",
				// 		zi: [{
				// 			name: "회사소개",
				// 			url: "/pages/about",
				// 			type: 1
				// 		}]
				// 	},
				// 	{
				// 		name: " 홈 ",
				// 		logo: "/static/home_active.png",
				// 		title: "홈",
				// 		style: "width:20px;",
				// 		zi: [{
				// 			name: "홈",
				// 			url: "/pages/home",
				// 			type: 2
				// 		}]
				// 	},
				// 	{
				// 		name: "주식",
				// 		logo: "/static/ico_stock2_ov.png",
				// 		title: "주식",
				// 		style: "width:20px;",
				// 		zi: [{
				// 				name: "블록딜",
				// 				url: "/pages/trade/large",
				// 				type: 1
				// 			},
				// 			{
				// 				name: "신주청약",
				// 				url: "/pages/trade/peishou",
				// 				type: 1
				// 			},
				// 			{
				// 				name: "공모주 청약",
				// 				url: "/pages/trade/ipo",
				// 				type: 1
				// 			}
				// 		]
				// 	},
				// 	{
				// 		name: "금융상품",
				// 		logo: "/static/ico_finance2_ov.png",
				// 		title: "금융상품",
				// 		style: "width:20px;",
				// 		zi: [{
				// 			name: "AI 자동매매",
				// 			url: "/pages/trade/day",
				// 			type: 1
				// 		}]
				// 	},
				// 	{
				// 		name: "고객센터",
				// 		logo: "/static/ico_cs2.png",
				// 		title: "고객센터",
				// 		style: "width:20px;",
				// 		zi: [{
				// 				name: "예수금",
				// 				url: "/pages/account/deposit",
				// 				type: 1
				// 			},
				// 			{
				// 				name: "출금",
				// 				url: "/pages/account/withdraw",
				// 				type: 1
				// 			},
				// 			{
				// 				name: "실명인증",
				// 				url: "/pages/account/auth",
				// 				type: 1
				// 			},
				// 			{
				// 				name: "계좌 상세내역",
				// 				url: "/pages/account/tradeLog",
				// 				type: 1
				// 			}
				// 		]
				// 	},
				// ],

				// current: 0
			};
		},
		methods: {
			actionEvent() {
				// 默认回退一级
				uni.navigateBack({
					delta: 1,
				})
				// 特殊回退，外部使用该事件
				this.$emit('action', '');
			},

			// tiaozhuan(item) {
			// 	console.log(item);

			// 	if (item.type == 1) {
			// 		uni.navigateTo({
			// 			url: item.url
			// 		})
			// 	} else {
			// 		uni.switchTab({
			// 			url: item.url
			// 		})
			// 	}

			// },
			// // 关闭窗口
			// closeDrawer(e) {
			// 	this.$refs[e].close()
			// },
			// showDrawer(e) {
			// 	console.log(111);

			// 	this.$refs[e].open()
			// },
			// // 跳转到个人中心
			// handleLink() {
			// 	uni.switchTab({
			// 		url: this.$util.PAGE_URL.ACCOUNT_CENTER
			// 	})
			// },
		}
	}
</script>