<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="line" style="margin-bottom:20px;padding:10px;">
				
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">입금：</view>
					<view style="flex:70%;font-size: 18px;font-weight: 700;text-align: right;" :style="{color:$util.THEME.PRIMARY}">
					{{$util.formatNumber(item.money)}}원
					</view>
				</view>
				
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">현금 잔액</view>
					<view style="flex:70%;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(item.after)}}원
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">거래전 잔액:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(item.before)}}원
					</view>
				</view>
				
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">거래 시간:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$util.THEME.TIP}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">설명:</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;"></view>
					<text :style="{color:$util.THEME.TEXT}" style="white-space:pre-wrap;text-align: right;">{{item.desc}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FINANCE, {})
				if (result.data.code == 0) {
					this.list = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>