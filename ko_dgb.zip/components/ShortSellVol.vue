<template>
	<view
		style="display: flex;align-items: center;justify-content: space-around;margin:0 20px;padding: 10px 0; border-bottom: 1px solid #999;">
		<view v-for="(item,index) in info" :key="index"
			style="text-align: center;border: 1px solid #FF8C00;padding:10px;border-radius: 6px;">
			<view style="padding-bottom:10px;" :style="{color:$util.THEME.TEXT}">{{item.label}}</view>
			<view style="padding-bottom:10px;" :style="{color:$util.THEME.LABEL}">{{item.tip}}</view>
			<view style="padding-bottom:10px;font-size: 20px;font-weight: 900;" :style="{color:$util.THEME.TEXT}">
				{{item.vol}}
				{{item.volWeight}}
			</view>
			<view style="font-size: 14px;" :style="{color:$util.THEME.LABEL}">
				{{item.date}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "ShortSellVol",
		props: ['params'],
		data() {
			return {
				info: [],
			};
		},
		created() {
			this.getData();
		},
		methods: {
			async getData() {
				uni.showLoading({
					mask: true,
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(this.$http.API_URL.PRODUCT_INFO_TOW, {
					code: this.params.code,
					stock_id: this.params.id
				})
				if (result.data.code == 0) {
					const temp = result.data.data[0].top7;

					this.info = [{
						label: '공매도 거래량',
						tip: '전체 거래량 대비',
						vol: `${temp[0].short_volume} 주`,
						volWeight: `${temp[0].short_volume_weight} %`,
						date: `기준 ${temp[0].dt}`
					}, {
						label: '공매도 잔고',
						tip: '시가총액 대비',
						vol: `${temp[1].short_volume} 주`,
						volWeight: `${temp[1].short_volume_weight} %`,
						date: `기준 ${temp[1].dt}`,
					}]

					uni.hideLoading()
				}
			}
		}
	}
</script>

<style>

</style>