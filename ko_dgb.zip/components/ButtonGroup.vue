<template>
	<view class="btns common_block" style="">
		<block v-for="(item,index) in btns" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize(80)"></image>
				<text style="padding-top: 6px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		data() {
			return {};
		},
		computed: {
			btns() {
				return [{
					name: '공동매수',
					url: '/pages/trade/day',
					icon: 'top1',
				},  {
					name: '지분양도',
					url: '/pages/trade/large',
					icon: 'top2',
				}, {
					name: 'VIP 할당량 확보',
					url: '/pages/trade/vip',
					icon: 'top3',
				},  {
					name: 'IPO 청약',
					url: '/pages/trade/ipo',
					icon: 'top5',
				},{
					name: 'IPO 배정',
					url: '/pages/trade/peishou',
					icon: 'top4',
				},
				{
					name: '본인 인증',
					url: '/pages/account/auth',
					icon: 'top6',
				},
				{
					name: '입출금거래',
					url: '/pages/account/tradeLog',
					icon: 'top8',
				},
				// {
				// 	name: '출금',
				// 	url: '/pages/account/withdraw',
				// 	icon: 'top5',
				// }, 
				{
					name: '고객센터',
					url: '/pages/service',
					icon: 'top7',
				}]
			}
		},

		methods: {
			actionEvent(url, index) {
				if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>