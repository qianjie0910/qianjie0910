<!-- 主页 -->
<template>
	<view>
		<Header></Header>

		<view class="bg-white flex flex-c padding-10"
			style="box-shadow: 0 0 10px rgba(0, 0, 0, .2);position: relative;">
			<view class="flex gap5">
				<view class="bold" style="color: #787878;">KOSPI</view>
				<view style="color: red;font-weight: 700;">{{$util.formatNumber(home_top.kospi.close,2)}}</view>
			</view>
			<view style="width: 1px;height: 20px;background-color: #bfbfbf;margin: 0 10px;"></view>
			<view class="flex gap5">
				<view class="bold" style="color: #787878;">KOSDAQ</view>
				<view style="color: red;font-weight: 700;">{{$util.formatNumber(home_top.kosdaq.close,2)}}</view>
			</view>
		</view>

		<!-- <view class="color-white" style="background-image: url('/static/main-visual11.jpg');
	background-size: cover;	background-repeat: no-repeat;	background-position: center center;height: 300px;"> </view> -->
	<view>
		<image src="/static/main-visual11.jpg" mode="scaleToFill" style="width: 100%;height: 200px;"></image>
	</view>

		<view style="margin-top: -10rpx;">
			<ButtonGroup></ButtonGroup>
		</view>


		<!-- <view class="bg-white padding-10 flex" style="color: #000;">
			<view class="text-center flex-1" @click="$u.route('/pages/trade/peishou');">
				<image src="/static/top3.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view>
					공모주
				</view>
			</view>
			<view style="width: 2px;height: 60px;background-color: #f7f7f7;margin: 0 10px;"></view>
			<view class="text-center flex-1" @click="$u.route('/pages/trade/ipo');">
				<image src="/static/top4.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view>
					공모주
				</view>
			</view>
			<view style="width: 2px;height: 60px;background-color: #f7f7f7;margin: 0 10px;"></view>
			<view class="text-center flex-1" @click="$u.route('/pages/trade/large');">
				<image src="/static/top2.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view>
					블록딜
				</view>
			</view>
			<view style="width: 2px;height: 60px;background-color: #f7f7f7;margin: 0 10px;"></view>
			<view class="text-center flex-1" @click="$u.route('/pages/account/auth');">
				<image src="/static/top6.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				<view>
					본인 인증
				</view>
			</view>
		</view> -->

		<view>
			<image src="/static/main-banner.jpg" mode="widthFix" style="width: 100%;"></image>
		</view>

		<view class="padding-20">
			<view class="flex  margin-bottom-10 flex-b">
				<view class="flex gap10">
					<image src="../static/ico_speaker.png" mode="widthFix" style="width: 25px;height: 25px;"></image>
					<view class="bold font-size-18">뉴스</view>
				</view>

				<view style="position: relative;"
					@click="$u.route({'type':'switchTab','url':'/pages/stock/bookmark'});">
					<view class="btn_more hgbtn">
						<span class="hid"></span>
					</view>
				</view>


			</view>
			<scroll-view scroll-x="true" style="white-space:nowrap;width: 100%;">
				<view style="width: 300px;display: inline-block;" v-for="(item,index) in article"
					@click="open(item.url)" v-if="index<=2">
					<view class="bg-white flex  padding-20 radius30 gap10" style="width: 80%;height: 80px;">

						<u-avatar :src="item.pic" size="50"></u-avatar>

						<view>
							<view style="white-space: normal">{{item.title}}</view>
							<view class="margin-top-10">{{item.created_at}}</view>
						</view>
					</view>

				</view>
			</scroll-view>
		</view>

		<!-- <view class="padding-20">
			<view class="flex  margin-bottom-10 flex-b">
				<view class="flex gap10">
					<image src="../static/ico_speaker.png" mode="widthFix" style="width: 25px;height: 25px;"></image>
					<view class="bold font-size-18"> 뉴스</view>
				</view>
				<view style="position: relative;"
					@click="$u.route({'type':'switchTab','url':'/pages/stock/bookmark'});">
					<view class="btn_more hgbtn">
						<span class="hid"></span>
					</view>
				</view>


			</view> -->
			<!-- <view v-for="(item,index) in article" @click="open(item.url)" v-if="index>2">
				<view class="flex flex-b  radius30 gap10" style="padding: 10px 20px;">
					<view style="white-space:nowrap;overflow: hidden;text-overflow: ellipsis;" class="bold">
						{{item.title}}
					</view>
					<view>{{item.created_at}}</view>
				</view>

			</view>
		</view> -->


		<view class="padding-20">
			<view class="flex  margin-bottom-10 flex-b">
				<view class="flex gap10">
					<image src="../static/kucun.png" mode="widthFix" style="width: 28px;height: 25px;"></image>
					<view class="bold font-size-18"> 종목현황</view>
				</view>
				<!-- <view style="position: relative;">
					<view class="btn_more hgbtn">
						<span class="hid"></span>
					</view>
				</view> -->


			</view>
			<GoodsList ref="goods"></GoodsList>
		</view>

		<!-- 每次由登入跳转进入时，显示该弹层，关闭后，不再显示。 -->
		<template v-if="isShow">
			<view class="mask" @click="handleClose">
				<view style="position: fixed;top: 26vh;right: 12vw;z-index: 1000;" @click="handleClose">
					<image src="/static/close.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				
				
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;justify-content: center;border-radius: 20px;">
						
						
						<view
							style="width: 80%;background-color: #fbfdff;border-radius: 6px;text-align: center;margin-top: 20px;">
							<view>
								<image src="/static/logo.png" mode="widthFix" style="width: 80px;"></image>
							</view>
							<view style="text-align: center;font-size: 36rpx;color:#1ed1b1;padding-bottom: 16px;">
								{{userInfo.nick_name}}님 축하합니다
							</view>
							<view style="font-size: 20px;padding: 10px 0 10px 0;color:#000;">
								【{{ipoSuccessItem.goods.number_code}}】{{ipoSuccessItem.goods.name}}
							</view>
							
							
							<view style="font-size: 12px;color:#000;padding:2px 0px 20px 0;">
								공모주청약 당첨되었습니다.
							</view>
							
							<view
								style="display: flex;align-items: center;justify-content: space-around;">
								<view>배정 수량</view>
								<text style="font-weight: 700;color:#ff3636;font-size: 16px;">
									{{$util.formatNumber(ipoSuccessItem.success)}} 주</text>
							</view>
							
							<view
								style="display: flex;align-items: center;justify-content: space-around;padding: 15px;">
								<view>납입 금액</view>
								<text
									style="font-weight: 700;color:#ff3636;font-size: 16px;">{{$util.formatNumber(ipoSuccessItem.total)}} 원</text>
							</view>
							
							
							
							
							<view
								style="padding: 8px 0;line-height: 1;background-color:#1cd1b1;border-radius: 10px;color:#FFF;margin:20px 30px;"
								@click="$u.route('/pages/trade/ipoSuccess');">바로보기</view>
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				isShow: false, // 是否显示ad层,
				ipoSuccessItem: {},
				userInfo: {}, // 用户信息
				timer: null,
				page: 1,
				gp_index: 0,
				home_top: "",
				article: "",
				klineindex: 141
			}
		},
		onLoad() {
			this.ipoSuccess();
			this.gaint_info();
			this.top_one()
		},
		onShow() {
			this.startTimer();
			this.hometop()
			if (this.$refs.goods) {
				this.$refs.goods.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			open(url) {
				window.open(url)
			},
			async top_one() {

				let list = await this.$http.post(this.$http.API_URL.GOODS_TOP1, {
					current1: 1,
					stockid: this.klineindex
				})

				this.article = list.data.data.article
			},
			// 用户信息
			async gaint_info() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {
					// language: this.$i18n.locale
				})
				this.userInfo = result.data.data;
				// this.cardManagement = result.data.data.bank_card_info
			},
			async hometop() {
				const result = await this.$http.get('api/goods/home_top', {})
				console.log(result);
				this.home_top = result.data.data
			},
			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get('api/goods-shengou/user-success-log', {})
				if (result.data.data[0]) {
					this.isShow = true;
					this.ipoSuccessItem = result.data.data[0];
				}
				console.log('抢筹', result.data.data[0]);
			},
			// AD层关闭
			handleClose() {
				this.isShow = false;
			},
			handleIPO() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.$refs.goods.getList();
				}, 3000);
			},

			// 银转证
			async silver() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
		},
	}
</script>

<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		/* background-image: url(/static/bg_common.png); */
		background-color: #abf0ff;
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 50vh;
		width: 80vw;
	}

	.hgbtn {
		display: inline-block;
		vertical-align: middle;
		border: 0;
		border: none;
		outline: none;
		background: none;
		border-radius: 0px;
		-webkit-appearance: none;
	}

	.btn_more {
		position: absolute;
		top: 0;
		right: 5%;
		width: 20px;
		height: 20px;
	}

	.btn_more::before {
		content: "";
		display: block;
		position: absolute;
		top: 0%;
		left: 0;
		transform: translateY(-50%);
		width: 100%;
		height: 2px;
		background-color: #004d79;
	}

	.hid {
		font-size: 0;
		line-height: 0;
		width: 1px;
		height: 1px;
		overflow: hidden;
		position: absolute;
		border: 0;
		clip: rect(0 0 0 0);
		margin: -1px;
		padding: 0;
	}

	.btn_more::after {
		content: "";
		display: block;
		position: absolute;
		top: -50%;
		left: 50%;
		transform: translateX(-50%);
		width: 2px;
		height: 100%;
		background-color: #004d79;
	}
</style>