<!-- 关于我们 -->
<template>
	<view >
		<CustomHeader :title="about.title" ></CustomHeader>
		<view class="common_block" style="margin-top: 10px;min-height: 60vh;">
			<view v-html="about.content" style="font-size: 14px;white-space: break-spaces;line-height: 1.3;padding:10px;" :style="{color:$util.THEME.TEXT}"></view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				about: ''
			};
		},
		mounted() {
			this.getAbout()
		},
		methods: {
			//关于我们
			async getAbout() {
				const result = await this.$http.get(this.$http.API_URL.ABOUT_US, {})
				this.about = result.data.data
			},
		},
	}
</script>