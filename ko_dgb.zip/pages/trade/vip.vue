<template>
	<view>
		<CustomHeader title="VIP 혜택"></CustomHeader>

		<!-- <view class="common_block"
			style="display: flex;flex-direction: column; align-items: center;justify-content:space-around;padding: 20px;">
			<image src="/static/trade_left.png" mode="widthFix" @click="handleTradeLog()"></image>
			<view style="height: 20px;"></view>
			<image src="/static/trade_right.png" mode="widthFix"></image>
		</view> -->

		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view class="line" style="margin:10px;padding:16px 12px;">
					<view
						style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 20px;">
						<view>
							<!-- <image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)">
							</image> -->
							<view :style="{color:$util.THEME.TEXT}" style="display: inline-block;margin-left: 10px;">
								<text style="font-size: 16px;padding-right: 10px;">{{item.code}}</text>
								<text style="font-size: 18px;font-weight: 700;">{{item.name}}</text>
							</view>
						</view>
						<view style="font-size: 22px;font-weight: 700;" :style="{color:$util.THEME.PRIMARY}">
							{{$util.formatNumber(item.current_price)}}<text style="padding:0 4px">원</text>
						</view>
					</view>
					<view class="common_btn btn_primary" style="background-color:#F0F1F3;line-height: 32px;"
						:style="{color:$util.THEME.TITLE}" @click="handleDetail(item)">{{$lang.DETAIL}}</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				current: 0,
				list: [],
			};
		},
		onShow() {
			this.getList();
		},
		methods: {
			handleTradeLog() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_LARGE_LOG
				});
			},

			handleDetail(val) {
				// 原版点击购买：跳转到单股的购买页面
				uni.navigateTo({
					url: `/pages/stock/overview?code=${val.number_code}&type=${val.project_type_id}`
				});
			},

			async getList() {
				this.list = [];
				const result = await this.$http.get('api/goods/zhangdie');
				if (result.data.code == 0) {
					this.list = result.data.data
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>

<style>
</style>