<template>
	<view>
		<CustomHeader title="기관 거래 우선가"></CustomHeader>

		<view class="common_block" style="padding:20px 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin: 30rpx; word-wrap:break-word;">

				</view>
				<u-divider></u-divider>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},

		data() {
			return {
				list: [],
			};
		},

		onLoad(option) {
			this.getList()
		},
		methods: {
			async getList() {
				const result = await this.$http.post('api/goods-bigbill/user-order-log', {})
				this.list = result.data.data
			},
		},
	}
</script>

<style>
</style>