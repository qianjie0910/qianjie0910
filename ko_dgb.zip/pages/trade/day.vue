<!-- 日内交易 -->
<template>
	<view>
		<CustomHeader :title="$lang.TRADE_SHORT"></CustomHeader>

		<view class="common_block" style="padding: 10px;">
			<block v-for="(item,index) in btns" :key="index">
				<view @click="handleChangeTab(index)"
					style="display: inline-block; width:max-content;height: 20px;padding:8px 20px;text-align: center;font-size: 16px;"
					:style="$util.calcStyleTabActive(current === index)">
					{{item}}
				</view>
			</block>

			<view style="margin-top: 20px;">
				<template v-if="current==0">
					<view style="padding:20px;">
						<view class="common_input_wrapper"
							style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
							<view style="width: 20px;"></view>
							<!-- <input v-model="rawAmount" type="number" placeholder="금액을 입력하세요"
								:placeholder-style="$util.setPlaceholder()" maxlength="11" style="width: 80%;" @input="formatAmount" ></input> -->
							
								<input type="text" v-model="displayedAmount" @input="updateRawAmount"
								:placeholder-style="$util.setPlaceholder()"  style="width: 80%;"	placeholder="금액을 입력하세요" />
								<!-- 这里不再需要 formattedAmount，因为 displayedAmount 将直接显示格式化后的值 -->
							


							<view style="padding:0 4px">원</view>
						</view>
					</view>
					<view class="common_btn btn_primary" @click="handleBuy()"
						style="border-radius: 20rpx;text-align: center">
						신청하기
					</view>

					<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#959393;">
						<!-- <view style="padding-bottom: 6px;">당일 거래:</view> -->
						<view style="padding-bottom: 6px;">설명:</view>
						<view style="padding-bottom: 6px;">공동 매수는 당일 거래를 위해 일괄 매수로 진행됩니다. 매도 후 모든 보유 주식이 청산되며 개인 지분에 따라
							정산됩니다.</view>
						<view style="padding-bottom: 6px;">공동 매수 거래에서는 거래와 관련된 일부 정보가 상업 기밀을 유지하기 위해 안전하게 관리됩니다.</view>
						<!-- <view style="padding-bottom: 6px;">AI 자동매매는 업무상 기밀유지을 위해 매매 관련 일부 정보는 보안처리 되어 관리됩니다.</view> -->
					</view>
				</template>

				<template v-else-if="current==1">
					<view style="display: flex;align-items: center;padding:10px;" :style="{color:$util.THEME.TITLE}">
						<view style="flex: 40%;">신청금액</view>
						<view style="flex: 30%;">승인금액</view>
						<view style="flex: 30%;">현황</view>
					</view>
					<view>
						<EmptyData v-if="list && list.length<=0"></EmptyData>
						<block v-for="(item,index) in list" :key="index">
							<view
								style="display: flex;align-items: center;border-bottom:1px solid #e0e0e0;margin-top:10px;padding: 0 6px 10px 6px;">
								<view style="flex: 40%;">
									{{$util.formatNumber(item.money)}}
									<text style="padding:0 4px">원</text>
								</view>
								<view style="flex: 30%;font-size: 16px;text-align: right;padding-right: 6px;"
									:style="{color:$util.THEME.PRIMARY}">
									{{$util.formatNumber(item.success)}}
									<text style="padding:0 4px">원</text>
								</view>
								<view style="flex: 30%;font-size: 13px;">{{item.zt}}</view>
							</view>
						</block>
					</view>
				</template>
				<template v-else-if="current==2">
					<EmptyData v-if="list && list.length<=0"></EmptyData>
					<block v-for="(item,index) in list" :key="index">
						<view style="border-top:1px solid #e0e0e0;margin-top:10px;padding:10px 0;">
							<view style="display: flex;align-items: center;">
								<view style="flex:15%;" :style="{color:$util.THEME.TITLE}">금액</view>
								<view style="flex:35%;text-align: right;padding-right: 16px;">
									{{$util.formatNumber(item.money)}}
									<text style="padding:0 4px">원</text>
								</view>
								<view style="flex:15%;" :style="{color:$util.THEME.TITLE}">승인금액</view>
								<view style="flex:35%;font-size: 16px;text-align: right;"
									:style="{color:$util.THEME.PRIMARY}">
									{{$util.formatNumber(item.success)}}
									<text style="padding:0 4px">원</text>
								</view>
							</view>
							<view style="display: flex;align-items: center;" :style="{color:$util.THEME.TITLE}">
								<view style="flex:30%;">주문 번호</view>
								<view style="flex:70%;font-size: 12px;text-align: right;">{{item.ordersn}}
								</view>
							</view>
							<view style="display: flex;align-items: center;">
								<view style="flex:30%;">날짜 시간</view>
								<view style="flex:70%;font-size: 12px;text-align: right;">
									{{item.created_at}}
								</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>

		<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
			:showCancelButton='true' content='클릭하여 작업을 확인하세요.' cancel-text="취소" confirm-text="확인">
		</u-modal>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import Tbas from '@/components/Tbas.vue';
	export default {
		components: {
			CustomHeader,
			Tbas,
			EmptyData,
		},
		data() {
			return {
				options: {},
				current: 0,
				rawAmount: '', // 原始输入值，不包含格式化  
				displayedAmount: '', // 显示在输入框中的值，包含格式化
				list: [],
				showBuyConfirm: false,
				btns: ['데이 트레이딩', '신청현황', '승인내역'],
			}
		},
		computed: {
			// 格式化金额，添加千分符（仅用于计算属性，不直接用于更新 displayedAmount）  
			formattedAmount() {
				return this.formatCurrency(this.rawAmount);
			},
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {},
		onShow() {},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleChangeTab(val) {
				this.list = [];
				this.current = val;
				if (this.current == 1) {
					this.getSQList();
				} else if (this.current == 2) {
					this.getOrderList();
				}
			},
			// 格式化金额，添加千分符  
			formatCurrency(value) {
				if (!value) return '';
				const parts = value.toString().split('.');
				parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
				return parts.join('.');
			},
			// 当输入框内容改变时调用此方法，更新 rawAmount 但不直接更新 displayedAmount  
			updateRawAmount() {
				// 移除千分符并更新 rawAmount  
				this.rawAmount = this.displayedAmount.replace(/,/g, '');
				// 同时更新 displayedAmount 以保持显示与 rawAmount 同步但带有格式  
				this.displayedAmount = this.formatCurrency(this.rawAmount);
				// 注意：这里可能需要处理小数点和光标位置的问题，以使体验更好  
			},
			// 初始化时设置 displayedAmount  
			mounted() {
				// 假设你想要在加载时预置一个值  
				this.rawAmount = '123456.78';
				this.displayedAmount = this.formatCurrency(this.rawAmount);
			},
			// 购买
			handleBuy() {
				if (this.rawAmount == '') {
					uni.$u.toast('금액을 입력해주세요');
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await this.$http.post('api/rinei/buy', {
					money: this.rawAmount,
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.rawAmount = '';
					this.handleChangeTab(1);

				} else {
					uni.$u.toast(result.data.message);
				}
			},

			// 申请列表
			async getSQList() {
				const result = await this.$http.get('api/rinei/sq-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			// 持仓列表
			async getOrderList() {
				const result = await this.$http.get('api/rinei/order-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>