<template>
	<view>
		<Header></Header>

		<!-- <view style="margin-top: 13vh;">
			<TradeInfo :info="userInfo"></TradeInfo>
		</view> -->

		<view class="common_block" style="padding:10px;margin: 10px;">

			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;">
				<view style="font-weight: 700;">계좌종합 잔고내역</view>

			</view>

			<view style="display: flex;align-items: center;line-height:1.8;border: 1px solid #dfdfdf;margin-top: 10px;">
				<view style="background-color: #c7e4fa;padding: 5px;" class="flex-1 text-center">
					{{$lang.TOTAL_BUY_AMOUNT}}
				</view>
				<view class="flex-3 text-center" :style="{color:$util.THEME.PRIMARY}">
					{{$util.formatNumber(userInfo.frozen)}}<text style="padding:0 4px">원</text>
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height:1.8;border: 1px  solid #dfdfdf;border-top: 0px;">
				<view style="background-color: #c7e4fa;padding: 5px;" class="flex-1 text-center">
					{{$lang.VALUATION_GAIN_LOSS}}
				</view>
				<view class="flex-3 text-center" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(userInfo.holdYingli)}}<text style="padding:0 4px">원</text>
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height:1.8;border: 1px solid #dfdfdf;border-top: 0px;">
				<view style="background-color: #c7e4fa;padding: 5px;" class="flex-1 text-center">
					{{$lang.VALUATION_GAIN_LOSS_AMOUNT}}
				</view>
				<view class="flex-3 text-center" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(userInfo.guzhi)}}<text style="padding:0 4px">원</text>
				</view>
			</view>

			<view style="display: flex;align-items: center;line-height:1.8;border: 1px solid #dfdfdf;border-top: 0px;">
				<view style="background-color: #c7e4fa;padding: 5px;" class="flex-1 text-center">
					{{$lang.RATE_RESPONSE}}
				</view>
				<view class="flex-3 text-center" :style="{color:$util.THEME.TEXT}">
					{{userInfo.huibao}}%
				</view>
			</view>

			<view style="display: flex;align-items: center;line-height:1.8;border: 1px solid #dfdfdf;border-top: 0px;">
				<view style="background-color: #c7e4fa;padding: 5px;" class="flex-1 text-center">
					{{$lang.AMOUNT_TOTAL}}
				</view>
				<view class="flex-3 text-center" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(userInfo.totalZichan)}}<text style="padding:0 4px">원</text>
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height:1.8;border: 1px solid #dfdfdf;border-top: 0px;">
				<view style="background-color: #c7e4fa;padding: 5px;" class="flex-1 text-center">
					{{$lang.TOTAL_GAIN}}
				</view>
				<view class="flex-3 text-center" :style="$util.calcStyleRiseFall(userInfo.totalYingli>0)">
					{{$util.formatNumber(userInfo.totalYingli)}}<text style="padding:0 4px">원</text>
				</view>
			</view>
		</view>

		<view class="common_block" style="margin: -20px 10px;padding:10px;padding-bottom: 60rpx;">
			<view
				style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;line-height: 2.4;">
				<view style="font-weight: 700;">종목 보유 현황</view>
			</view>

			<view>
				<view style="display: flex;align-items: center;" :style="{color:$util.THEME.TITLE}">
					<view
						style="flex:16%;border:1px solid #dfdfdf;height: 40px;line-height: 40px;text-align: center;background-color: #c7e4fa;padding:20rpx 0;">
						<view>종목명</view>
					</view>
					<view
						style="flex:30%;border:1px solid #dfdfdf;height: 40px;line-height: 20px;text-align: center;background-color: #c7e4fa;padding:20rpx 0;">
						<view>평가손익</view>
						<view>수익률</view>
					</view>
					<view
						style="flex:34%;border:1px solid #dfdfdf;height: 40px;line-height: 20px;text-align: center;background-color: #c7e4fa;padding:20rpx 0;">
						<view>보유수량</view>
						<view>평가금액</view>
					</view>
					<view
						style="flex:20%;border:1px solid #dfdfdf;height: 40px;line-height: 20px;text-align: center;background-color: #c7e4fa;padding:20rpx 0;">
						<view>매입가</view>
						<view>현재가</view>
					</view>
				</view>

				<template v-if="list && list.length<=0">
					<EmptyData></EmptyData>
				</template>

				<block v-for="(item,index) in list" :key="index">
					<view class="flex flex-b margin-top-10" @tap="handleShowModal(item)"
						style="border-bottom:1px solid #ccc;line-height: 1.6;">
						<view class="padding-5" :class="index%2==0?'bgyellow':'bglan'" style="width: 16%">
							<view :style="{color:$util.THEME.TIP}"> {{item.goods_info.name}} </view>
						</view>
						<view class="padding-5 flex flex-b" :class="index%2==0?'bgyellow':'bglan'" style="width: 84%"
							v-if="item.order_buy">
							<template v-if="isHold">
								<view class="flex-1" :style="$util.calcStyleRiseFall(item.order_buy.float_yingkui>0)">
									<view style="text-align: right;padding-right: 6px;">
										{{$util.formatNumber(item.order_buy.yingkui)}}<text
											style="padding:0 4px">원</text>
									</view>
									<view class="margin-top-10 " style="text-align: right;padding-right: 16px;">
										{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
									</view>
								</view>
							</template>
							<template v-else>
								<view class="flex-1" style="text-align: right;padding-right: 6px;">
									<view>
										{{$util.formatNumber(item.order_sell.yingkui)}}
									</view>
									<view class="margin-top-10 " style="text-align: right;padding-right: 16px;">
										{{$util.formatNumber((item.order_sell.yingkui/item.order_buy.user_pay/item.order_buy.double*100),2)}}%
									</view>
								</view>
							</template>

							<view class="flex-1">
								<view style="text-align: right;padding-right:6px;" :style="{color:$util.THEME.TEXT}">
									{{$util.formatNumber(item.order_buy.num)}}
								</view>
								<!-- <view class="margin-top-10 " style="text-align: right;"
									:style="{color:$util.THEME.TEXT}">
									{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}<text
										style="padding:0 4px">원</text>
								</view> -->
								<template v-if="isHold">
									<view class="margin-top-10 " style="text-align: right;"
										:style="{color:$util.THEME.TEXT}">
										{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}<text
											style="padding:0 4px">원</text>
									</view>
								</template>
								<template v-else>
									<template v-if="item.order_sell">
										<view class="margin-top-10" style="text-align: right;"
											:style="{color:$util.THEME.TEXT}">
											{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}<text
												style="padding:0 4px">원</text>
										</view>
									</template>
								</template>
							</view>

							<view class="flex-1">
								<view style="text-align: right;padding-right: 6px;" :style="{color:$util.THEME.TEXT}">
									{{$util.formatNumber(item.order_buy.price)}}<text style="padding:0 4px">원</text>
								</view>
								<view class="margin-top-10" style="text-align: right;padding-right: 6px;"
									:style="{color:$util.THEME.RISE}">
									{{$util.formatNumber(isHold? item.goods_info.current_price:item.order_sell.price)}}<text
										style="padding:0 4px">원</text>
								</view>
							</view>
						</view>
					</view>
				</block>
			</view>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header">
						<text :style="{color:$util.THEME.LABEL}" style="text-align: center;font-size: 16px;">주식주문</text>
						<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.STOCK_NAME}}</view>
						<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.goods_info.name}}</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.BUY_DATETIME}}</view>
						<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.order_buy.created_at}}</view>
					</view>
					<template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.SELL_DATETIME}}</view>
							<view style="flex: 75%;" :style="{color:$util.THEME.TEXT}">{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;"
						v-if="info.order_buy">
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.CURRENT_PROFIT_LOSS}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.float_yingkui:info.order_sell.float_yingkui)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.LEVER}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">{{info.order_buy.double}}</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.TOTAL_PROFIT_LOSS_AMOUNT}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui:info.order_sell.yingkui)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.BUY_PRICE}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.BUY_NUM}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.FEE_BUY_SELL}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:info.order_sell.sell_fee)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.BUY_TOTAL_AMOUNT}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}
						</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TIP}">{{$lang.CODE}}</view>
						<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
						v-if="isHold">
						<view class="common_btn btn_primary" style="width: 40%;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.STOCK_DETAIL}}
						</view>
						<view class="common_btn btn_secondary" style="width: 40%;" @tap="handleSell(info.id)">
							{{$lang.STOCK_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			TradeInfo,
			EmptyData,
		},
		data() {
			return {
				userInfo: {}, // 交易信息
				radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				list: [],
				info: {},
				isShow: false, // 买卖弹出
				curPage: 1, // 当前页码	
				maxPage: 1, // 最大页码
				flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题
			}
		},
		computed: {
			locationList() {
				return [{
					name: this.$lang.STOCK_COUNTRY_SELF,
				}, {
					name: this.$lang.STOCK_COUNTRY_OTHER
				}]
			}
		},

		//下拉刷新
		onPullDownRefresh() {
			this.curPage = 1; // 从第一页重新开始
			this.list = []; // 清空所有翻页后内中数据
			this.handleRefresh()
			uni.stopPullDownRefresh()
		},
		onShow() {
			this.getUserInfo();
			this.handleRefresh()
		},

		onUnload() {
			console.log('포지션 종료됨1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('포지션 종료됨2');
			clearInterval(this.timerId);
		},
		//监听页面触底函数
		onReachBottom() {
			// 如果触底，并且当前页码<最大页码
			console.log(this.curPage, this.maxPage);
			if (!this.flag) {
				if (this.curPage < this.maxPage) {
					this.curPage++;
					console.log('page:', this.curPage);
					this.getList()
				}
				if (this.curPage >= this.maxPage) {
					return false;
				}
			}
		},
		methods: {
			groupChange(n) {
				console.log('groupChange', n);
			},
			handleChangeLocation(val) {
				this.isSelf = val == 0;
				this.handleRefresh();
			},
			handleChangeList(val) {
				this.isHold = val == 0;
				this.handleRefresh();
			},

			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			handleRefresh() {
				uni.showLoading({
					mask: true
				})
				this.curPage = 1; // 从第一页重新开始
				this.list = []; // 清空所有翻页后内中数据
				this.getList();
			},
			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.STOCK_SELL_TIP,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							console.log(_this);
							_this.confirmSell(id);
							uni.hideLoading();
						} else if (res.cancel) {
							console.log('사용자가 취소를 클릭합니다.');
						}
					}
				})
			},

			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				console.log('userInfo:', result);
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},

			// 平仓功能
			async confirmSell(id) {
				uni.showLoading({
					title: this.$lang.TIP_SELLING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(this.$http.API_URL.USER_SELL, {
					id
				})
				if (result.data.code == 0) {
					this.handleRefresh()
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				}
			},

			handleStockDetail(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`
				});
			},

			async getList() {
				this.flag = true;
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_ORDER, {
					page: this.curPage,
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: this.isSelf ? 0 : 1,
				})
				this.flag = false;
				if (result.data.code == 0) {
					this.list.push(...result.data.data.data);
					this.maxPage = result.data.data.last_page; // 最大页码
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>
<style>
	page {
		background-color: #fdfdfd;
	}
</style>