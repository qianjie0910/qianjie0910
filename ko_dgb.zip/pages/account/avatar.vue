<template>
	<view >
		<CustomHeader title="설정"></CustomHeader>

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
			<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">
				프로필
			</view>
		</view>
		

		<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
			<view class="common_block" style="width: 80%;padding:20px;">
				<view>	
				<!-- <image mode="aspectFit" src="/static/JH.png" :style="$util.setImageSize(500)" style="margin-left: 20px;margin-top: -20px;" @click="afterRead()"> -->
				<!-- </image> -->
					<u-upload  @afterRead="afterRead" @delete="deletePic" name="6" multiple :maxCount="1" width="100%"
	height="150"  class="justify-center flex align-center">
						<image :src="src" 
							mode="widthFix" style="width:250px;height: 150px;"></image>
					</u-upload>
				</view>				

				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
					<image mode="aspectFit" src="/static/user.png" :style="$util.setImageSize(28)">
					</image>
					<input v-model="nick_name" type="text" placeholder="성함을 입력해주세요"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view>

				<view class="common_btn btn_primary" style="margin-top: 20px;" @click="submit_list">프로필 변경 적용하기
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				fileList6: [],
				is_url: "",
				src: '/static/JH.png',
				nick_name: "",
			};
		},
		mounted() {
			this.userInfo()
		},
		methods: {
			async submit_list() {
				let list = await this.$http.post('api/user/updateAvatar', {
					avatar: this.is_url,
					nickname: this.nick_name,

				})
				if (list.data.code == 0) {
					uni.$u.toast('수정되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
						// 登录成功之后强制刷新页面
						this.$router.go(0)
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			// 回调参数为包含columnIndex、value、values
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {

				})
				if(list.data.data.avatar){
					this.src = list.data.data.avatar
				}
				// this.nick_name = list.data.data.nick_name
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
			},
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,

					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
				this.src = this.fileList6[0].thumb
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
		},
	}
</script>

<style lang="less" scoped>
	.box_but {
		// font-weight: bold;
		// width: 100%;
		// margin: 0 auto;
		// margin: 100rpx 30rpx;
		border-radius: 10rpx;
		background: #90bae7;
		color: #fff;
		text-align: center;
		padding: 20rpx 0;
		position: fixed;
		width: 90%;
		left: 5%;
		right: 5%;
		bottom: 100rpx;

	}

	.box_con {
		padding: 40rpx 40rpx;
		background-color: #fff;
		margin-bottom: 30rpx;
		// color: #000;
		font-weight: bold;
		border-radius: 30rpx;
		margin: 20rpx;
		box-shadow: 1px 1px 1px 1px #f1f1f1;
		font-size: 28rpx;

		.sculpture {
			display: flex;
			align-items: center;
		}

		.name {
			display: flex;
			align-items: center;
			margin: 60rpx 0 0;

			input {
				margin-left: 30rpx;
				font-size: 28rpx;
			}
		}
	}
</style>