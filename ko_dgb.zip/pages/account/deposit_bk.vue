<!-- 银转证  存款 -->
<template>
	<view >
		<CustomHeader :title="$lang.DEPOSIT" ></CustomHeader>

		<view class="withdraw_info"
			style="margin-top: -1vh;display: flex;flex-direction: column; align-items: flex-start;justify-content: center;padding-left: 30px;">
			<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;">
				{{$util.formatNumber(userInformation.money)}}
			</view>
			<view style="color:rgb(49, 130, 247,0.7);background-color: #FFFFFF;border-radius: 10px;padding:6px 4px;">현재
				사용 가능한 잔액</view>
		</view>

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
			<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">자산총계</view>
		</view>

		<!-- 출금가능금액 1,642,302,500 -->
		<view class="common_block" style="padding: 10px;">
			<view class="common_input_wrapper"
				style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;margin:10px;padding:10px;justify-content: space-between;">
				<!-- <image mode="aspectFit" src='/static/money.png' :style="$util.calcImageSize(20)">
				</image> -->
				<view :style="{color:$util.THEME.PLACEHOLDER,fontSize:'36rpx'}">출금가능금액</view>
				<view :style="{color:$util.THEME.PLACEHOLDER,fontSize:'36rpx'}">
					{{$util.formatNumber(userInformation.money)}}
				</view>
				<!-- <input v-model="value1" placeholder="충전금액을 입력해주세요" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input> -->
			</view>
		</view>

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin-left: 10px;">
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.setImageSize(6,36)"></image>
			<view style="padding-left: 10px; font-size:36rpx;" :style="{color:$util.THEME.TITLE}">
				원하는충전금액
			</view>
		</view>

		<view class="common_block" style="padding: 14px 10px;">
			<view class="common_input_wrapper"
				style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;margin:10px;">
				<input v-model="value1" placeholder="최소충전1000000" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view>

			<view style="margin-left: 10px;color:#AFAFAF;">충전금액을 입력하세요</view>

			<view
				style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:10px;">
				<block v-for="(item,index) in [100000,300000,500000,1000000]" :key="index">
					<view style="padding:10px;border-radius: 6px;"
						:style="{backgroundColor:curPos==index?'#3083f859':'#FFF',color:'#333' }"
						@click="quantity(item,index)">
						{{item}}
					</view>
				</block>
			</view>
		</view>

		<view style="padding: 10px;">
			<!-- 儲值 -->
			<view @click="to_recharge()" class="common_btn btn_primary" style="margin: 20px 0;border-radius: 6px;">
				재충전
			</view>
			<view style="font-size: 14px;font-weight: 700;text-align: center;" :style="{color:$util.THEME.TITLE}">친절한 팁
			</view>
			<view style="padding-bottom:6px;color: #999;">一、입금시간 : 평일 09:00~18:00, 공휴일 휴무。</view>
			<view style="color: #999;margin-bottom: 30px;">
				우리를 선택해 주셔서 감사합니다. 귀하의 자금의 안전을 보장하기 위해,
				이전하려는 계좌가 플랫폼에 실시간으로 표시되는 계좌인지 확인하시기 바랍니다.
				환승할 때마다 직원에게 확인하시기 바랍니다.
				본 플랫폼에 실시간으로 표시되는 계좌가 아닌 은행 계좌에서 자금을 입금하여 발생하는 모든 손실에 대한 책임은 귀하에게 있습니다. </view>
		</view>

	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				curPos: 0, // 当前选中预置金额。
				serviceService: '보려면 고객 서비스에 문의하십시오.',
				value1: '',
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				character: '',
				character1: '',
				character2: '',
				character3: '',
				fileList6: [],
				userInformation: "",
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				BankUser: '',
				BankName: '',
				BankNo: '',
				BankUser_2: '',
				BankName_2: '',
				BankNO_2: '',
				current: 0,
				list1: [{
						name: '채널 1'
					},
					{
						name: '채널 2'
					},
				],
				Inv: 0,
				items: ['채널 1', '채널 2']
			};
		},
		onLoad(option) {
			this.gaint_info()
			this.testVerify()
		},
		methods: {
			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			//客服
			service() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},

			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: this.$util.PAGE_URL.ACCOUNT_TRADE_LOG
				});
			},



			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast('먼저 비밀번호를 확인해 주세요');
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: '성공적으로 복사되었습니다',
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			quantity(val, index) {
				this.curPos = index;
				this.value1 = val;
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				uni.showLoading({
					title: "충전 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/recharge', {
					money: this.value1,
					type: 5,
					image: this.is_url,
					desc: this.value2,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.value2 = '';
					this.value1 = '';
					this.is_url = '';
					this.fileList6 = [];
					this.title = '은행 카드',
						setTimeout(() => {
							uni.switchTab({
								url: this.$util.PAGE_URL.ACCOUNT_CENTER
							});
							uni.hideLoading();
						}, 2000)
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
					// if (list.data.message === '充值金额错误') {
					// 	uni.$u.toast('请填写充值金额金额');
					// } else if (list.data.message === '您还未实名') {
					// 	uni.$u.toast('请先实名认证');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/index/components/openAccount/openAccount'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)

					// } else if (list.data.message === '请先添加银行卡信息') {
					// 	uni.$u.toast('请先添加银行卡');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/bankCard/renewal'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)
					// }
					// uni.$u.toast(list.data.message);
					// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

					// }
				}
			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {

				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
				})
				this.BankUser = list.data.data[13].value
				this.BankName = list.data.data[12].value
				this.BankNo = list.data.data[9].value

				this.BankUser_2 = list.data.data[22].value
				this.BankName_2 = list.data.data[23].value
				this.BankNO_2 = list.data.data[24].value
				uni.hideLoading();


			},


		},
	}
</script>

<style lang="scss">
	//充值金额
	.recharge {
		font-size: 28rpx;

		.title {
			color: #333;
		}

		.minimum {
			color: #999;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		// input {
		// 	background: #f5f5f5;
		// 	border-radius: 10rpx;
		// 	color: #000;
		// 	padding: 30rpx 20rpx;
		// 	font-size: 28rpx;
		// }

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #f5f5f5;
				color: #999;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			.shadow {
				background-image: linear-gradient(to right, #1a73e8, #014b8d);
			}
		}
	}
</style>