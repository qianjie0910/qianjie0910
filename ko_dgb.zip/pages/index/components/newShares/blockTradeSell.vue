<!-- 大宗交易 -->
<template>
	<view >
		<CustomHeader title="기관 거래 우선가"></CustomHeader>
		<view class="common_block" style="overflow-y: scroll;height: 92vh;">
			<view v-for="(item,index) in business" :key="index"
				style="border-bottom: 0.037037rem solid #e0e0e0;margin:10px;padding-bottom: 10px;">
				<view class="display" style="margin: 20rpx 0;">
					<view class="">
						<view class="corporation" style="color:#999">{{item.goods.name}}</view>
					</view>
					<view class="price" :style="{color:$util.THEME.PRIMARY_COLOR}">
						{{$util.formatNumber(item.price)}}
					</view>
					<view class="common_btn" style="padding: 6px 20px;transform: scale(0.75);" @click="detail(item)">
						세부
					</view>
				</view>
			</view>
		</view>

		<u-popup :show="show" @close="close" mode="bottom" :closeable='closeable' :round="10">
			<view v-if="detailId" class="largeAmount">
				<view class="business">
					신주청약 신청 주문
				</view>
				<view class="price">매입 가격</view>
				<view class="purchase-price">{{$util.formatNumber(detailId.price)}}</view>
				<view class="purchase-text">
					<u-input type="number" placeholder="매입 수량을 입력하세요." v-model="value1"></u-input>
					<view class="hand">확인</view>
				</view>
				<view class="price">레버리지</view>
				<view class="available" @click="ganggan_show=true">
					<u-input type="number" style="pointer-events: none;" :disabled="true" placeholder=""
						v-model="ganggan" inputAlign='right'>
					</u-input>
				</view>
				<view class="amount">매입 가격 <text>{{detailId.price*this.value1/ganggan|addZero}} </text> </view>
				<view class="available">
					<u-input type="password" placeholder="결제 비밀번호를 입력해주세요" v-model="value2"></u-input>
				</view>
				<view class="fund">
					사용 가능 잔액 <text>{{$util.formatNumber(availableFunds.money)}}</text>
				</view>
				<view class="common_btn" style="margin:10px 60px;" @click="bulkPurchase(detailId.id)">매입</view>
			</view>
		</u-popup>
		<u-action-sheet :show="ganggan_show" :actions="actions" title="레버리지를 선택하세요" @close="ganggan_show = false"
			@select="Select">
		</u-action-sheet>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				show: false,
				closeable: true,
				business: "",
				detailed: '',
				value1: '',
				value2: '',
				value3: '',
				availableFunds: '',
				detailId: {},
				ganggan: 1,
				ganggan_show: false,
				actions: [{
					name: '1',
					index: 1
				}],
			}
		},
		methods: {
			Select(e) {
				console.log(e);
				this.ganggan = e.index
			},
			close() {
				this.show = false
				// console.log('close');
			},
			detail(item) {
				this.show = true
				this.bulkDetails(item)
				// console.log(this.bulkDetails, '987654');
			},
			blockTransactions() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
				});
			},
			//列表
			async largeAmount() {
				let list = await this.$http.get('api/goods-bigbill/list', {})
				this.business = list.data.data
			},
			//세부
			async bulkDetails(item) {
				let list = await this.$http.get('api/goods-bigbill/detail', {
					id: item.id
				})
				this.detailed = list.data.data.goods
				this.detailId = list.data.data

			},

			//点击购买
			async bulkPurchase(id) {
				let list = await this.$http.post('api/goods-bigbill/doOrder', {
					id: id,
					num: this.value1,
					pay_pass: this.value2,
					ganggan: this.ganggan
					// password: this.value3,
				})
				if (list.data.code == 0) {
					this.show = false
					uni.$u.toast(list.data.message);
					this.value1 = ''
					this.value2 = ''
					this.value3 = ''
					this.available()
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/index/components/newShares/blockTransactions/blockTransactions'
						});
					}, 1000)
				} else {


					if (this.value1 == '') {
						this.show = false
						uni.$u.toast('구매 수량을 입력해주세요.');
						setTimeout(() => {
							this.show = true
						}, 1000)
					} else if (this.value2 == '') {
						this.show = false
						uni.$u.toast('펀드 비밀번호를 입력해주세요');
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
					// else if (this.value3 == '') {
					// 	this.show = false
					// 	uni.$u.toast('请填写주주들은 지분을 줄인다密码');
					// 	setTimeout(() => {
					// 		this.show = true
					// 	}, 1000)
					// } 
					else {
						this.show = false
						uni.$u.toast(list.data.message);
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
				}
			},
			//사용 가능한 자금
			async available() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.availableFunds = list.data.data
				this.actions = list.data.data.ganggan
			},

		},

		//取小数点之后的2位
		filters: {
			addZero: function(data) {
				return data.toFixed(0)
			}
		},
		mounted() {
			this.largeAmount()
			this.available()
			// this.bulkDetails()
		},
		onShow() {
			// this.bulkDetails()
			this.available()
		}
	}
</script>
<style lang="scss">
	.corporation {
		font-size: 30rpx;
		font-weight: 600;
		color: #333;

	}

	.price {
		color: #f85252;
		font-size: 28rpx;
	}

	.detailed {
		background-color: rgb(72, 156, 229);
		color: #fff;
		border-radius: 40rpx;
		padding: 6rpx 40rpx;
		font-size: 26rpx
	}

	.find {
		width: 45%;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	.ration {
		width: 45%;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	//弹窗
	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 30rpx;
			// color: #333;
			// border-bottom: 1rpx solid #e0e0e0;
			// padding-bottom: 30rpx;
			color: #333;
			border-bottom: 1px solid #e0e0e0;
			height: 45px;
			line-height: 45px;
			//background-color: #5f9ae5;
			border-top-left-radius: 10px;
			border-top-right-radius: 10px;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 5px 0 0 6px;
		}

		.purchase-price {
			color: #ea3544;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #e0e0e0;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #999;
			font-size: 24rpx;
			padding: 0 9px;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.available {
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #999;
			font-size: 24rpx;
			padding: 0 9px;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.purchase {
			background-color: #5f9ae5;
			margin: 30rpx;
			border-radius: 20rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;

		}
	}
</style>