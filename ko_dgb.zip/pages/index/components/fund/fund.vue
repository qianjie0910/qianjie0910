<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" >
				<view class="icon jiantou" @click="$u.route({type:'navigateBack'});"></view>
				<view class="header-center flex-1">스마트 주문</view><!---->
				<view class="icon ss" @click="$u.route({url:$util.PAGE_URL.SEARCH});"></view>
			</view>
		</view>
		
		<view class="flex flex-c margin-top-20 padding-10">
			<view :class="current==0?'top-a':'top'"  @click="sectionChange(0)">
				주문
			</view>
			<view :class="current==1?'top-a':'top'" @click="sectionChange(1)">
				구매내역
			</view>
		</view>
		
		
		<view style="background-color: #489CE5;justify-content: center;width: 90%;margin-left: 5%;" class="radius30 padding-top-20 margin-top-10" v-for="(item,index) in list" @click="buy(index)" v-if="current==0">
			<view class="bg-white padding-20" style="height: 100%;border-radius: 0 0px 14px 14px;" >
				<view class="flex width100" >
					<view class="align-center flex">
						{{item.name}}
					</view>
					<view style="background-color: #8fc2ed;padding:2px 5px;margin-left: auto;" class="radius10">
						<view class="bg-white radius10 hui2" style="padding:2px 10px;box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;">종료</view>
					</view>
				</view>
				
				<view class="flex width100 margin-top-10" >
					<view class="align-center flex font-size-22 bold" style="color: #E82D28;">
						{{item.syl}}
					</view>
					<view style="padding:2px 5px;margin-left: auto;color: #489CE5;" class="radius10 font-size-18 bold align-center flex">{{item.zhouqi}}일
					</view>
				</view>
				
				<view class="flex width100" >
					<view class="align-center flex hui1" >
						최고수익률	
					</view>
					<view class="align-center flex hui1 left-auto" style="padding:2px 5px;">주기
					</view>
				</view>
			</view>
			
		</view>
		
		<view class="overlay" v-if="item_show" @click="item_show=false"></view>
		<view style="position: fixed;width: 90%;margin-left: 5%;border-radius: 20px;background-color: #489CE5;bottom: 5%;z-index: 9999;" v-if="item_show">
			<view class="color-white  padding-10 flex ">
				<view class="text-center justify-center width100 font-size-16">체험급</view>
				
				<u-icon name="/static/market/close.png" size="24" @click="item_show=false"></u-icon>
			</view>
			<view class="bg-white padding-10">
				<view>{{goods_buy.name}}</view>
				<view style="color: #E82D28;" class="bold margin-top-10">{{goods_buy.syl}}%</view>
				<view class="margin-top-10">
					<u-input type="number" placeholder="구매금액을 입력해주세요" v-model="price" ></u-input>
				</view>
				<view class="margin-top-10 hui1 font-size-12" >
					구매가능잔액
					<text style="color: #E82D28; margin-left: 10px;">
						{{userinfo.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</text>
				</view>
				<view @click="confirm()" class="padding-10 text-center radius40 margin-top-10 color-white" style="background-color: #489CE5;width: 90%;margin-left: 5%;">매수</view>
			</view>
			<!-- <view  class="text-center padding-20" style="background-color: #fff;border-radius: 0 0 20px 20px;">
				
				<view style="width: 100%;background-color: #3779CD;" class="padding-10 radius10 color-white font-size-16" v-if="Inv==0" @tap="productDetails(info.goods_info.number_code)">구입하다</view>
				
			</view> -->
		</view>
		
		<view v-if="current==1" style="background-color: #489CE5;width: 90%;margin-left: 5%;" class="radius30 padding-top-20 margin-top-10 justify-center" v-for="(item,index) in order_list">
			<view class="bg-white padding-20" style="height: 100%;border-radius: 0 0px 14px 14px;" >
				<u-cell-group>
					<u-cell icon="order" :title="item.goodname" :value="item.zhouqi+' 일'"></u-cell>
					<u-cell title="구매 금액" :value="toThousandFilter(item.price)"></u-cell>
					<u-cell title="기간" :value="item.zhouqi+' 일'"></u-cell>
					<u-cell title="구입 날짜" :value="item.cretime"></u-cell>
					<u-cell title="마감일" :value="item.endtime"></u-cell>
					<u-cell title="거래 ID" :value="item.ordersn"></u-cell>
					
					<u-cell title="증거금(레버리지)" :value="item.ganggan"></u-cell>
					
					<u-cell title="배당" :value="item.shouyi"></u-cell>
					<!-- <u-cell title="배당" :value="item.shouyi"></u-cell> -->
					
					<u-cell  style="font-weight: 700;"  v-if="item.status==1">
					
						<u-button color="#6db0ea"  @click="sell(item.id)" slot="value">매도</u-button>
					</u-cell>
										
				</u-cell-group>
			</view>
		</view>
	</view>


</template>

<script>
	export default {
		data() {
			return {
				item_show:false,
				ganggan: 1,
				actions: [{
					name: '1',
					index: 1
				}],
				top_list: [{
						name: '종목'
					},
					{
						name: '구매 내역'
					}
					
				],
				current: 0,
				top_hg: 80,
				show_js: false,
				title: "",
				content: "",
				show_buy: false,
				list: [],
				jijin_name: '',
				goods_buy: [],
				price: '',
				order_list: [],
				xiangqing_show: false,
				xq_list: [],
				userinfo:"",
				item:[]
			};
		},
		onShow() {
			this.getlist()
			this.userInfo()
		},
		methods: {

			async sell(id) {
				uni.showModal({
					content: "정말로 매도하시 겠습니까?",
					cancelText: "취소",
					confirmText: "확인",
					success: (res) => {
						if (res.confirm) {
							this._sell(id)
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}

				})

			},
			async _sell(id) {
				var list = await this.$http.get('api/jijin/sell', {
					id: id,
				})
				uni.hideLoading()
				if (list.data.code == 1) {

					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast(list.data.message);
					this.getlist()
				}
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.userinfo=list.data.data
				if (list.data.code == 1) {
					uni.reLaunch({
						url: "/pages/logon/logon/logon"
					})
				}
				this.actions = list.data.data.ganggan
			},
			async xiangqing(id) {

				var list = await this.$http.post('api/jijin/info', {
					id: id,

				})

				console.log(list)
				this.xq_list = list.data
				this.xiangqing_show = true
			},
			buy(index) {
				console.log('index',index);				
				this.item_show=true;
				// this.item=data;
				
				this.jijin_name = this.list[index].name
				this.show_buy = true
				this.goods_buy = this.list[index]
			},
			jieshao(index) {
				console.log(index);
				this.content = this.list[index].content
				this.show_js = true
			},
			confirm() {
				console.log(this.goods_buy);
				var price = this.price
				this.show_buy = false
				uni.showLoading({

				})
				if (!price || price == '') {
					console.log(price);
					// uni.showToast({
					// 	icon:'none',
					// 	title:'请输入金额'
					// })
					uni.$u.toast('금액을 입력해주세요.');
				}


				this.buy_goods(price)
			},
			async buy_goods(price) {

				var list = await this.$http.get('api/jijin/buy', {
					id: this.goods_buy.id,
					price: price,
					ganggan: this.ganggan
				})
				uni.hideLoading()
				this.item_show = false
				if (list.data.code == 1) {
					this.show_buy = false
					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast("성공적으로 구매");
					this.getlist()
				}

			},
			close() {
				this.show_buy = false
				// console.log('close');
			},
			async getlist() {
				var list = await this.$http.get('api/jijin/list')
				console.log("기금 목록", list);
				this.list = list.data.jj_list
				this.order_list = list.data.order
			},
			sectionChange(index) {
				console.log(index)
				this.current = index;
				this.getlist()
			},

			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.HOME
				});
			},
			async fundDetails(i) {
				console.log(i)
				let list = await this.$http.get('api/peizi/index', {
					index: i
				})
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				})
				// let list = await this.$http.get('api/app/config', {})
				// window.open(list, '_blank');
			}

		}
	}
</script>

<style lang="scss">
	uni-view, uni-text {
	    box-sizing: border-box;
	}
	page{
		background-color: #F3F4F8;
	}
	.page {
	    padding: 50px 0 0;
	}
	.header{
	    height: 60px;
	    background: #489ce5;
	    box-shadow: 0px 1px 4px 0px rgba(0,0,0,.1);
	    padding: 20px 16px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
	
		.header-left {
		    position: absolute;
		    top: 18px;
		    left: 16px;
		    width: 10px;
		    height: 18px;
		}
		.header-center {
		    font-size: 16px;
		    font-weight: 700;
		    color: #fff;
		    text-align: center;
		}
	}
	.top-a{
		height: 33px;
		line-height: 28px;
		text-align: center;
		color: #000;
		width: 70px;
		margin: 5px;
		border-bottom: 2px #f6e464 solid;
	}
	.top{
		color: #000;
		height: 28px;
		line-height: 28px;
		width: 70px;
		text-align: center;	
		margin: 5px;
	}
	/* 遮罩层 */
	.overlay {  
	  
	  position: fixed; /* Stay in place */  
	  top: 0;  
	  left: 0;  
	  width: 100%; /* Full width */  
	  height: 100%; /* Full height */  
	  z-index: 999; /* Sit on top */  
	  background-color: rgba(0,0,0,0.5); /* Black background with opacity */  
	  cursor: pointer; /* Add a pointer on hover */  
	}  
</style>