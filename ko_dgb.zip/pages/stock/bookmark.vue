<template>
	<view >
		<Header></Header>

		<TabFour></TabFour>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import TabFour from '@/components/market/TabFour.vue'
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			EmptyData,
			TabFour
		},
		data() {
			return {
				list: [],
				timer: null,
			}
		},
		onShow() {
			this.getList()
			this.startTimer()
		},
		onHide() {
			clearInterval(this.timer);
		},
		computed: {
			best() {
				return this.list.sort((a, b) => b.goods.rate - a.goods.rate).slice(0, 3);
			}
		},
		methods: {},
	}
</script>