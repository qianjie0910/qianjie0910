<!-- 日内交易 -->
<template>
	<view>
		<view style="background-color: #FFFFFF;">
			<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_DAY"></HeaderSecond>
		</view>

		<view style="padding: 10px 20px;">
			<TabsSecond :tabs="$lang.TRADE_DAY_TABS" @action="changeTab" :acitve="curTab"></TabsSecond>
		</view>


		<view style="padding: 10px;margin-bottom: 20px;">
			<template v-if="curTab==0">
				<TradeDayBuy @action="changeTab"></TradeDayBuy>
			</template>

			<template v-else-if="curTab==1">
				<TradeDayOrderList></TradeDayOrderList>
			</template>
			<template v-else>
				<TradeDaySuccessList></TradeDaySuccessList>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsSecond from '@/components/tabs/TabsSecond.vue';
	import TradeDayBuy from '@/components/trade/TradeDayBuy.vue';
	import TradeDayOrderList from '@/components/trade/TradeDayOrderList.vue';
	import TradeDaySuccessList from '@/components/trade/TradeDaySuccessList.vue';
	export default {
		components: {
			HeaderSecond,
			TabsSecond,
			TradeDayBuy,
			TradeDayOrderList,
			TradeDaySuccessList,
		},
		data() {
			return {
				options: {},
				curTab: 0,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>