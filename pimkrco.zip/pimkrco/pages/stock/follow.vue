<template>
	<view>
		<view class="follow_header" >
			<HeaderPrimary :title="$lang.TABBAR_FOLLOW" isSearch></HeaderPrimary>
		</view>
		
		<view
			style="margin-top: -210px;padding-top: 20px;padding-bottom: 30px;">

		<!-- <template v-if="best.length>0">
				<view class="" style="display: flex; align-items: center;flex-wrap: nowrap;padding:10px 6px;">
					<block v-for="(item,index) in best" :key="index">
						<view @click="handleStockInfo(item.goods.code)" class="common_block"
							style="flex:33.33%;margin:6px 4px;padding:4px;background-color: #F3DCF3;">
							<view style="" :style="{color:$theme.TEXT}">
								{{item.goods.name}}
							</view>
							<view style="text-align: center;font-size:40rpx;font-weight: 700; padding:4px 0;"
								:style="$util.setStockRiseFall(item.goods.rate>0)">
								{{$util.formatNumber(item.goods.current_price)}}
							</view>
							<view style="text-align: center;" :style="$util.setStockRiseFall(item.goods.rate>0)">
								<view style="display:inline-block;padding-right: 10px;font-size: 28rpx;">
									{{item.goods.rate_num>0?'+':''}}{{item.goods.rate_num}}
								</view>
								<view style="display:inline-block;font-size: 28rpx;">
									{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
								</view>
							</view>
						</view>
					</block>
				</view>
			</template> -->

		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view @click="handleStockInfo(item.goods.code)" class="common_block" style="padding:10px;margin:20px;">
					<view style="display: flex;align-items: center;">
						<view style="flex:0 0 6%;">
							<template v-if="!item.goods.logo || item.goods.logo==''">
								<view :style="$util.setImageSize(80)"
									style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;font-size: 18px;">
									{{item.goods.name.slice(0,1)}}
								</view>
							</template>
							<template v-else>
								<image mode="aspectFit" :src="$util.setLogo(item.goods.logo)"
									:style="$util.setImageSize(80)" style="border-radius: 100%;"></image>
							</template>
						</view>
						<view style="flex:0 0 44%;padding-left: 6px;"
							:style="{color:$theme.STOCK_NAME}">
							<view style="display: flex;align-items: center;">
								<view style="padding-right: 10px;font-size: 30rpx;">{{item.goods.name}}</view>
								<image mode="aspectFit" src="/static/stock_follow.png" :style="$util.setImageSize(32)"
									@click.stop="handleUnFollow(item.goods.gid)">
								</image>
							</view>
							<view :style="{color:$theme.LABEL}" style="font-size: 24rpx;">{{item.goods.code}}</view>
						</view>
						<view style="flex:40%;text-align: right;">
							<view style="display: flex;align-items: center;justify-content: flex-end;">
								<image :src="`/static/arrow_${item.goods.rate>0?'rise':'fall'}.png`" mode="aspectFit"
									:style="$util.setImageSize(24)"></image>
								<view style="font-size: 30rpx;font-weight: 700;"
									:style="$util.setStockRiseFall(item.goods.rate>0)">
									{{($util.formatNumber($util.formatMathABS(item.goods.rate),2))}}%
								</view>
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 32rpx;font-weight: 700;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(item.goods.current_price)}}
						</view>
						<image :src="`/static/line_${item.goods.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$util.setImageSize(176,78)"></image>
					</view>
				</view>
			</block>
		</template>
		</view>
	</view>
</template>

<script>
	import {
		getFollowList,
		updateFollow
	} from '@/common/api.js';
	import {
		STOCK_OVERVIEW
	} from '@/common/paths.js';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderPrimary,
			EmptyData,
		},
		data() {
			return {
				list: [],
				timer: null,
			}
		},
		computed: {
			best() {
				// 取最高三条数据为顶部块状展示
				return this.list.sort((a, b) => b.goods.rate - a.goods.rate).slice(0, 3);
			}
		},
		onShow() {
			this.getData()
			this.onSetTimeout()
		},
		onHide() {
			this.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			// 跳转到单股详情页面
			handleStockInfo(code) {
				uni.navigateTo({
					url: `${STOCK_OVERVIEW}?code=${code}`
				});
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getData();
				}, 5000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			async getData() {
				const result = await getFollowList();
				if (result.code == 0) {
					this.list = result.data.list;
				} else {
					uni.$u.toast(result.message);
				}
			},

			// 取关
			async handleUnFollow(gid) {
				const result = await updateFollow({
					gid: gid,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.getList()
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>