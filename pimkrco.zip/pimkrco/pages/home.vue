<template>
	<view>
		<!-- 固定的语言切换 不在header内，避免弹层遮蔽 -->
		<view style="position: fixed;right:20px;top:24px;z-index: 15;">
			<Translate></Translate>
		</view>
		<!-- 固定在页首，且在滚动后改变样式 -->
		<view class="header_fixed">
			<template v-if="scrollTop<=10">
				<view class="home_header">
					<HeaderPrimary isSearch>
						<view style="flex:60%;">
							<image src="/static/logo_name.png" mode="aspectFit" :style="$util.setImageSize(320,48)">
							</image>
						</view>
					</HeaderPrimary>
				</view>
			</template>
			<template v-else>
				<view class="scroll_header">
					<HeaderPrimary isSearch icon="search_dark">
						<view style="flex:60%;">
							<image src="/static/logo_name.png" mode="aspectFit" :style="$util.setImageSize(320,48)">
							</image>
						</view>
					</HeaderPrimary>
				</view>
			</template>
		</view>
		<view style="position: relative;" :style="{zIndex:scrollTop<=10?'13':'10'}">
			<view class="common_block" style="margin-top: 90px;">
				<ButtonGroup :btns="$util.homeBtns()"></ButtonGroup>
			</view>

			<CustomTitle :title="$lang.WITHDRAW_AMOUNT"></CustomTitle>

			<view @click="linkAccountCenter()">
				<AccountAssets :info="userInfo"></AccountAssets>
			</view>

			<FollowList ref="follow"></FollowList>

			<CustomTitle :title="$lang.STOCK_ALL">
				<view style="font-size: 14px;margin-left: auto;" @click="linkAllList()" :style="{color:$theme.PRIMARY}">
					{{$lang.MORE}}
				</view>
			</CustomTitle>

			<GoodsList ref="goods"></GoodsList>
		</view>

		<template v-if="isShow">
			<view class="mask" @click="handleClose()">
				<view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 15vh;"
					@click="handleClose()">
					<image src="/static/close_light1.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;border-radius: 20px;padding: 20px 0;">
						<view style="font-size: 32rpx;font-weight: 700;color: #121212;">
							{{$lang.DIALOG_IPO_SUCCESS_TIP_TITLE}}
						</view>

						<view>
							<image src="/static/dialog_icon.png" mode="aspectFit" :style="$util.setImageSize(280,160)">
							</image>
						</view>
						<template v-if="userInfo.nick_name">
							<!-- <view
								style="text-align: center;font-size: 36rpx;    color: rgb(0, 180, 90);padding-bottom: 16px;">
								{{userInfo.nick_name}}
							</view> -->
						</template>
						<view
							style="width: 90%;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 0px;">
							<view style="font-size: 40rpx;font-weight: 700;color: #EBBD33;padding:4px 40px;">
								{{ipoInfo.name}}
							</view>
							<view style="font-size: 28rpx;font-weight: 700;color: #666;padding:4px 40px;">
								{{ipoInfo.code}}
							</view>

							<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;">
								{{$lang.DIALOG_IPO_SUCCESS_TIP_TEXT}}
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_QTY}}</view>
								<text style="font-weight: 700;color:#ff3636;font-size: 16px;">
									{{$util.formatNumber(ipoInfo.success)}}</text>
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_TOTAL}}</view>
								<text
									style="font-weight: 700;color:#ff3636;font-size: 16px;">{{$util.formatNumber(ipoInfo.total)}}</text>
							</view>
							<view
								style="padding: 5px 0;line-height: 1.5;background-color:#EBBD33;border-radius: 100px;color:#FFF;margin:20px 30px;"
								@click="linkIPOSuccessLog()">{{$lang.BTN_DETAIL_NOW}}</view>
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import {
		accountInfo,
		getIPOSuccessList
	} from '@/common/api.js';
	import {
		STOCK_ALL,
		STOCK_FOLLOW,
		TRADE_IPO,
		ACCOUNT_CENTER
	} from '@/common/paths.js';
	import Translate from '@/components/Translate.vue';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import FollowList from '@/components/FollowList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	export default {
		components: {
			Translate,
			HeaderPrimary,
			ButtonGroup,
			GoodsList,
			FollowList,
			CustomTitle,
			AccountAssets,
		},
		data() {
			return {
				userInfo: {}, // 账户信息
				ipoInfo: {}, // 
				isShow: false, // 是否显示中签弹层
				scrollTop: 0, // 页面滚动值,用于作为页首样式切换判断
			}
		},

		onLoad() {
			console.log('onLoad', this.$refs.goods);
			console.log('onLoad', this.$refs.follow);
			this.ipoSuccess();
		},

		onShow() {
			this.getInfo();
			console.log('onShow', this.$refs.goods);
			console.log('onShow', this.$refs.follow);
			if (this.$refs.goods) {
				this.$refs.goods.onSetTimeout();
			}
			if (this.$refs.follow) {
				this.$refs.follow.onSetTimeout();
			}
		},
		onReady() {
			console.log('onReady', this.$refs.goods);
			console.log('onReady', this.$refs.follow);
		},
		onHide() {
			console.log('onHide', this.$refs.goods);
			console.log('onHide', this.$refs.follow);
			this.$refs.goods.clearTimer();
			this.$refs.follow.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.$refs.goods);
			console.log('deactivated', this.$refs.follow);
			this.$refs.goods.clearTimer();
			this.$refs.follow.clearTimer();
		},
		// 页面滚动监听，改变页首样式
		onPageScroll(e) {
			console.log('页面滚动:', e);
			this.scrollTop = e.scrollTop;
		},

		methods: {
			// 跳转到全部股票
			linkAllList() {
				uni.navigateTo({
					url: STOCK_ALL
				})
			},
			// 跳转到个人中心
			linkAccountCenter() {
				uni.switchTab({
					url: ACCOUNT_CENTER
				})
			},

			// 关闭中签提醒
			handleClose(val) {
				console.log(val);
				this.isShow = val;
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: `${TRADE_IPO}?type=2`,
				})
			},
			// 获取账户信息
			async getInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await getIPOSuccessList();
				console.log(result);
				if (result.code == 0) {
					if (result.data.length > 0) {
						const temp = result.data[0];
						this.ipoInfo = {
							code: temp.goods.code,
							name: temp.goods.name,
							success: temp.success,
							total: temp.total,
						};
						this.isShow = true;
					}
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>

<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		background-image: url(/static/dialog_bg_ipo_success.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 50vh;
		width: 80vw;
	}
</style>