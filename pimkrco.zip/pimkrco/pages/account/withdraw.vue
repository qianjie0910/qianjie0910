<!-- 실시간 이체 -->
<template>
	<view style="background-color: #FFFFFF;min-height: 100vh;">
		<view style="background-image: linear-gradient(90deg, #EBBD33, #F0844E);border-radius: 0 0 12px 12px;">
			<HeaderSecond :title="$lang.PAGE_TITLE_WITHDRAW" color="#FFFFFF"></HeaderSecond>

			<view class="account_assets" style="position: relative;">
				<view style="position: absolute;right: 10px;top:10px;">
					<image src="/static/account_assets3.png" mode="aspectFit" :style="$util.setImageSize(180)">
					</image>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.8;">
					<view style="padding-left: 10px;color:#FFFFFF;font-size: 28rpx;">
						{{$lang.TIP_AMOUNT_AVAIL}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$util.setImageSize(40)" style="margin-left: 10px;">
					</image>
				</view>
				<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;line-height: 1.8;">
					{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
				</view>
			</view>
		</view>

		<view :style="{backgroundColor:$util.RGBConvertToRGBA('#EBBD33',20)}"
			style="display: flex;align-items: center;justify-content: space-between;padding:10px 40px;line-height: 2.4;color:#EBBD33;font-size: 28rpx;margin: 20px;border-radius: 4px;">
			<view>{{$lang.WITHDRAW_AMOUNT}}</view>
			<view>{{showAmount?$util.formatNumber(userInfo.totalZichan)+$lang.CURRENCY_UNIT :hideAmount}}</view>
		</view>

		<view style="padding:20px;margin-top: 10px;margin-bottom: 20px;">
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.WITHDRAW_WITH_AMOUNT}}
			</view>
			<view class="common_input_wrapper" style="padding-left: 30px;margin-bottom: 20px;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;"></input>
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.WITHDRAW_PAY_PWD}}
			</view>
			<view class="common_input_wrapper" style="margin-bottom: 30px;padding-left: 30px;">
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
					:placeholder-style="$util.setPlaceholder()" style=""></input>
			</view>

			<view class="access_btn" style="margin:20px auto; width: 90%;background-color: #EBBD33;"
				@click="handleWithdraw()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>


		<view style="margin:10px; padding: 20px;" :style="{color:$theme.TITLE}">
			<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;" :style="{color:index==5?'#FF6700' :$theme.TITLE}">
					{{item}}
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		postWithdarw,
		accountInfo
	} from '@/common/api.js';
	import {
		ACCOUNT_TRADE_LOG
	} from '@/common/paths.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// handleAllAmount(val) {
			// 	this.amount = val
			// },
			async handleWithdraw() {
				const result = await postWithdarw({
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				}, this.$lang.WITHDRAWING_POST_TIP)
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.navigateTo({
							url: ACCOUNT_TRADE_LOG + `?code=2`,
						});
					}, 500)
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>