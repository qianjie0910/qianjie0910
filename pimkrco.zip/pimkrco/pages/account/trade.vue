<template>
	<view>
		<view class="trade_header">
			<HeaderPrimary :title="$lang.TABBAR_TRADE" isSearch></HeaderPrimary>
		</view>

		<view style="margin-top: -210px;padding-top: 20px;padding-bottom: 30px;">

			<AccountAssets :info="userInfo"></AccountAssets>

			<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;">
				<view class="trade_modal_btn"
					style="background-color: #FF6700;height: 32px;line-height:32px;display: flex;align-items: center;justify-content:center;"
					@click="handleDeposit()">
					<!-- <image src="/static/center_left.png" mode="aspectFit" :style="$util.setImageSize(28)"
						style="padding-right: 20px;"></image> -->
					{{$lang.PAGE_TITLE_DEPOSIT}}
				</view>
				<view class="trade_modal_btn"
					style="background-color:#F5B71C;height: 32px;line-height:32px;display: flex;align-items: center;justify-content:center;"
					@click="handleWithDraw()">
					<!-- <image src="/static/center_right.png" mode="aspectFit" :style="$util.setImageSize(28)"
						style="padding-right: 20px;"></image> -->
					{{$lang.PAGE_TITLE_WITHDRAW}}
				</view>
			</view>
			<!-- <view class="trade_info">
				<view
					style="display: flex;align-items: center; justify-content: space-around; padding:20px 40px 0 40px;">
					<view style="color:#FFFFFF;font-size: 32rpx;">
						{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$util.setImageSize(40)" style="margin-left: auto;">
					</image>
				</view>

				<view style="color:#FFFFFF;font-size: 64rpx;font-weight: 700;padding-left:30px;line-height: 2.4;">
					{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
				</view>

				<view class="trade_withdraw" @click="handleDeposit()">
					{{$lang.PAGE_TITLE_DEPOSIT}}
				</view>
			</view> -->

			<CustomTitle :title="$lang.TRADE_TITLE">
				<view style="margin-left: auto;color:#666666;">
					<!-- {{stockInfo.top3[0].report_year_month}} -->
				</view>
			</CustomTitle>

			<view class="common_block" style="padding:0 10px 20px 10px;">
				<TabsFourth :tabs="$lang.TRADE_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsFourth>
				<view style="background-color: #FFFFFF;padding:6px;border-radius: 6px;">
					<view
						style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
						<view
							style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
							<view style="color:#999">{{$lang.TRADE_TOTAL_BUY_AMOUNT}}</view>
							<view :style="{color:$theme.PRIMARY}">
								{{$util.formatNumber(userInfo.frozen)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
						<view
							style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
							<view style="color:#999">{{$lang.TRADE_VALUATION_GAIN_LOSS}}</view>
							<view :style="{color:$theme.TEXT}">
								{{$util.formatNumber(userInfo.holdYingli)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
						<view
							style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
							<view style="color:#999">{{$lang.TRADE_VALUATION_GAIN_LOSS_AMOUNT}}</view>
							<view :style="{color:$theme.TEXT}">
								{{$util.formatNumber(userInfo.guzhi)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
						<view
							style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
							<view style="color:#999">{{$lang.TRADE_RATE_RESPONSE}}</view>
							<view :style="{color:$theme.TEXT}">
								{{userInfo.huibao}}%
							</view>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between;margin-bottom: 6px;line-height:1.8;margin: 6px 0;">
						<view
							style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
							<view style="color:#999">{{$lang.ACCOUNT_AMOUNT_TOTAL}}</view>
							<view :style="{color:$theme.TEXT}">
								{{$util.formatNumber(userInfo.totalZichan)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
						<view
							style="flex:31%;margin:0 6px;background-color: #F6F6F6;padding:10px;border-radius: 8px;text-align: center;">
							<view style="color:#999">{{$lang.TRADE_TOTAL_GAIN}}</view>
							<view :style="$util.setStockRiseFall(userInfo.totalYingli>0)">
								{{$util.formatNumber(userInfo.totalYingli)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
					</view>
				</view>

				<view style="background-color: #F6F6F6;border-radius: 8px;">
					<view
						style="background-color: #FFFAEB;line-height: 2.4;display: flex;align-items: center;border-radius: 8px 8px 0 0;">
						<view style="flex:0 0 16%;text-align: center;padding:4px 0;">
							<view style="color: #F5B71C;">{{$lang.TRADE_LIST_THEAD[0]}}</view>
						</view>
						<view style="flex:0 0 30%;text-align: right;padding:4px 0;">
							<view style="color: #F5B71C;">{{$lang.TRADE_LIST_THEAD[1]}}</view>
							<view style="color: #F5B71C;">{{$lang.TRADE_LIST_THEAD[2]}}</view>
						</view>
						<view style="flex:0 0 34%;text-align: right;padding:4px 0;">
							<view style="color: #F5B71C;">{{$lang.TRADE_LIST_THEAD[3]}}</view>
							<view style="color: #F5B71C;">{{$lang.TRADE_LIST_THEAD[4]}}</view>
						</view>
						<view style="flex:0 0 20%; text-align: center;padding:4px 0;">
							<view style="color: #F5B71C;">{{$lang.TRADE_LIST_THEAD[5]}}</view>
							<!-- <view>{{$lang.TRADE_LIST_THEAD[6]}}</view> -->
						</view>
					</view>
					<template v-if="list && list.length<=0">
						<EmptyData></EmptyData>
					</template>

					<template v-else>
						<block v-for="(item,index) in list" :key="index">
							<view style="display: flex;align-items: center;line-height: 1.8;margin:6px;"
								:class="index<list.length-1?'line':'' " @tap="handleShowModal(item)">
								<view style="flex:0 0 16%;text-align: center;padding:4px 0;">
									<view :style="{color:$theme.TIP}"> {{item.goods_info.name}} </view>
								</view>


								<view style="flex:0 0 30%;padding:4px 0;">
									<template v-if="isHold">
										<view style="text-align: right;"
											:style="$util.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
											{{$util.formatNumber(item.order_buy.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
										</view>
										<view style="text-align: right;"
											:style="$util.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
											{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view :style="$util.setStockRiseFall(item.order_sell.yingkui*1>0)">
												{{$util.formatNumber(item.order_sell.yingkui*1)}}
											</view>
											<view style="text-align: right;"
												:style="$util.setStockRiseFall(item.order_sell.yingkui*1>0)">
												{{$util.formatNumber((item.order_sell.yingkui*1/item.order_buy.user_pay*1/item.order_buy.double*100),2)}}%
											</view>
										</template>
									</template>
								</view>

								<view style="flex:0 0 34%;padding:4px 0;">
									<view style="text-align: right;padding-right:6px;" :style="{color:$theme.TEXT}">
										{{$util.formatNumber(item.order_buy.num)}}
									</view>

									<template v-if="isHold">
										<view style="text-align: right;" :style="{color:$theme.TEXT}">
											{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view style="text-align: right;" :style="{color:$theme.TEXT}">
												{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
											</view>
										</template>
									</template>
								</view>

								<view style="flex:0 0 20%; text-align: center;padding:4px 0;">
									<view style="" :style="{color:$theme.TEXT}">
										{{$util.formatNumber(item.order_buy.price)}}{{$lang.CURRENCY_UNIT}}
									</view>
									<template v-if="isHold">
										<view style="" :style="{color:$theme.RISE}">
											{{$util.formatNumber(item.goods_info.current_price)}}{{$lang.CURRENCY_UNIT}}
										</view>
									</template>
									<template v-else>
										<template v-if="item.order_sell">
											<view style="" :style="{color:$theme.RISE}">
												{{$util.formatNumber(item.order_sell.price)}}{{$lang.CURRENCY_UNIT}}
											</view>
										</template>
									</template>
								</view>
							</view>
						</block>
					</template>
				</view>
			</view>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
					<view class="popup_header">
						<text :style="{color:$theme.STOCK_NAME}"
							style="text-align: center;font-size: 36rpx;">{{$lang.TRADE_MOADL_TITLE}}</text>
						<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 20px;top:15px;"></image>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[0]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">{{info.goods_info.name}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[1]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.order_buy.created_at}}
						</view>
					</view>
					
					
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;" v-if="jiejin==1&&info.source=='guquan'&&isHold">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">락업 해제일
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{calculateEndDate(info.order_buy.created_at,info.goods_info.day)}}
						</view>
					</view>
					
					<template v-if="!isHold">
						<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[2]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[3]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(
							isHold?info.order_buy.float_yingkui*1
							:!info.order_sell?0:info.order_sell.float_yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>

					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[5]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[6]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[7]}}
						</view>
						<view style="flex: 30%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 20%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[4]}}
						</view>
						<view style="flex: 20%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.order_buy.double}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[8]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[9]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[10]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
						v-if="isHold">
						<view class="trade_modal_btn" style="background-color: #14CF76;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.BTN_DETAIL}}
						</view>
						<view class="trade_modal_btn" style="background-color:#F5B71C;" @tap="handleSell(info.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import {
		getTradeList,
		postStockSell,
		accountInfo,
		getAPPConfig
	} from '@/common/api.js';
	import {
		STOCK_OVERVIEW,
		ACCOUNT_DEPOSIT,
		ACCOUNT_WITHDRAW
	} from '@/common/paths.js';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	export default {
		components: {
			HeaderPrimary,
			TradeInfo,
			EmptyData,
			TabsFourth,
			CustomTitle,
			AccountAssets,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				curTab: 0, // 默认放在持仓列表，即左边

				radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				list: [],
				info: {},
				jiejin:0,
				isShow: false, // 买卖弹出
				curPage: 1, // 当前页码	
				maxPage: 1, // 最大页码
				flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题
			}
		},
		computed: {
			locationList() {
				return [{
					name: this.$lang.STOCK_COUNTRY_SELF,
				}, {
					name: this.$lang.STOCK_COUNTRY_OTHER
				}]
			}
		},

		onLoad() {
			this.getUserInfo();
			this.getconfig()
		},
		onShow() {
			this.getData();
		},
		//下拉刷新
		onPullDownRefresh() {
			// this.curPage = 1; // 从第一页重新开始
			// this.list = []; // 清空所有翻页后内中数据
			this.getData();
			uni.stopPullDownRefresh();
		},

		// //监听页面触底函数
		// onReachBottom() {
		// 	// 如果触底，并且当前页码<最大页码
		// 	console.log(this.curPage, this.maxPage);
		// 	if (!this.flag) {
		// 		if (this.curPage < this.maxPage) {
		// 			this.curPage++;
		// 			console.log('page:', this.curPage);
		// 			this.getData()
		// 		}
		// 		if (this.curPage >= this.maxPage) {
		// 			return false;
		// 		}
		// 	}
		// },
		methods: {
			calculateEndDate(startDates,days) {
			  const startDate = new Date(startDates);
			  const endDate = new Date(startDate.getTime() + days * 24 * 60 * 60 * 1000);
			  return endDate = endDate.toISOString().slice(0, 10);
			},
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				if (this.curTab == 1) {
					this.isHold = false;
				} else {
					this.isHold = true;
				}
				// this.isHold = val == 1;
				// this.curPage = 1; // 从第一页重新开始
				// this.list = []; // 清空数据
				this.getData();
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: ACCOUNT_WITHDRAW
				})
			},
			handleDeposit() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			},
			groupChange(n) {
				console.log('groupChange', n);
			},
			// handleChangeLocation(val) {
			// 	this.isSelf = val == 0;
			// 	this.getData();
			// },
			// handleChangeList(val) {
			// 	this.isHold = val == 0;
			// 	this.getData();
			// },

			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							_this.confirmSell(id);
						} else if (res.cancel) {}
					}
				})
			},

			async getUserInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
			// 获取配置
			async getconfig() {
				const result = await getAPPConfig();
				if (result.code == 0) {
					console.log(1111,result);
					this.jiejin=result.data[28].value
				}
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await postStockSell({
					id
				}, this.$lang.STATUS_SUBMIT);
				if (result.code == 0) {
					this.getData()
					uni.$u.toast(result.message);
				} else {
					uni.$u.toast(result.message);
				}
			},

			handleStockDetail(code) {
				uni.navigateTo({
					url: `${STOCK_OVERVIEW}?code=${code}`
				});
			},

			async getData() {
				// this.flag = true;
				const result = await getTradeList({
					// page: this.curPage,
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: this.isSelf ? 0 : 1,
				});

				// this.flag = false;
				if (result.code == 0 && result.data) {
					// this.list.push(...result.data);
					this.list = result.data;
					// this.maxPage = result.data.last_page; // 最大页码
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>