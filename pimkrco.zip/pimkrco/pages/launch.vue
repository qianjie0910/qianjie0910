<template>
	<view class="launch">



		<view style="display: flex;align-items: center;justify-content: center;margin-top: 20vh;">
			<image src="/static/launch_img.png" mode="aspectFit" :style="$util.setImageSize(480)"></image>
		</view>
		<view style="display: flex;align-items: center;justify-content: center;">
			<view style="margin-top: 20px;text-align: center;font-size: 48rpx;font-family: 700;">
				{{$lang.LAUNCH_TITLE}}
			</view>
		</view>

		<!-- <view style="position: fixed;bottom: 30px;left:0;right: 0;">
			<view style="display: flex;align-items: center;justify-content: center;">
				<image src='/static/logo.png' :style="$util.setImageSize(160,120)" style="margin-bottom: 50px;">
				</image>
			</view>
		</view> -->
		<view
			style="position:relative;margin:30rpx 120rpx 20rpx 120rpx; background-color:rgba(255,255,255,0.15);height:10px;border-radius: 20rpx;border: 1px solid #FEB14D;padding:0 3px;">
			<view :style="setStyle()"></view>
			<view style="background-image: url('/static/launch_loading.png');
	background-repeat: no-repeat;
	background-position: center center;
	background-size: cover;width: 100%;height: 100%;position: absolute;left: 0;right: 0;top: 0;bottom: 0;z-index: 99;">
			</view>
		</view>
		<view style="text-align: center;color: #FFFFFF;font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
			{{`${$lang.STATUS_LOADING} `}} {{`${percentage} %`}}
		</view>

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 10vh;">
			<image src="/static/logo2.jpg" style="border-radius: 100px;" mode="aspectFit" :style="$util.setImageSize(128)"></image>
		</view>
	</view>
</template>

<script>
	import {
		HOME
	} from '@/common/paths.js';
	export default {
		data() {
			return {
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},

		watch: {
			percentage(val, old) {
				this.setStyle()
			},
		},
		onLoad() {
			this.onSetTimeout();
		},
		onHide() {
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		methods: {
			setStyle() {
				return {
					position: 'absolute',
					bottom: 0,
					left: 0,
					height: '10px',
					width: `${this.percentage}%`,
					backgroundImage: `linear-gradient(90deg, #FBED7B ,#FF533B)`,
					borderRadius: '20rpx',
				}
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage++;
					} else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						uni.$u.sleep(1500).then(() => {
							uni.switchTab({
								url: HOME,
							})
						})
					}
					console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>