// 底部导航组
const TABBAR = {
	TABBAR_HOME: "홈",
	TABBAR_FOLLOW: "즐겨찾기",
	TABBAR_MARKET: '시장',
	TABBAR_TRADE: '거래',
	TABBAR_ACCOUNT: '환경설정',
};

// 账户管理相关 登入、注册 계정관리관련 로그인, 회원가입
const ACCESS = {
	SIGN_IN: "로그인",
	SIGN_UP: "회원가입",
	SIMGN_OUT: "로그아웃",
	GO_TO_SIGN_IN: '로그인 하러가기',
	USER_NAME: '계정',
	ENTER_USER_NAME: '계정을 입력하세요',
	PASSWORD: '비밀번호',
	ENTER_PASSWORD: '비밀번호를 입력하세요',
	VERIFY_PASSWORD: '인증번호를 입력하세요',
	ENTER_VERIFY_PASSWORD: '비밀번호를 다시 한 번 입력하세요',
	INVITATION_CODE: '초대코드',
	ENTER_INVITATION_CODE: '초대코드를 입력하세요',
	TIP_PWD_NOEQUAL: '두 개의 비밀번호가 일치하지 않습니다.',
	TIP_SUCCESS_SIGNIN: '로그인 되었습니다.',
	TIP_SUCCESS_REGISTER: '회원가입이 완료되었으니 로그인하시기 바랍니다.',
	TIP_SIGNIN_ING: '로그인 중',
	TIP_SIGNUP_ING: '회원가입 중',
	TIP_REMEMBER_PWD: '비밀번호를 기억하세요',
	API_TOKEN_EXPIRES: '로그인 상태가 만료되었습니다. 다시 로그인하세요.',
	TIP_SIGN_OUT_SUCCESS: '로그아웃 되었습니다.',
	TIP_AGREE: '이미 읽고 동의했습니다.',
	TIP_PRVITE_PACT: '개인 정보 이용 동의',
	TIP_CHECK_AGREE: '개인 정보 이용 동의에 체크해주세요',
};

// 变更登入密码、变更支付密码、变更账户信息 로그인 비밀번호 변경, 결제 비밀번호 변경, 계정 정보 변경
const ACCOUNT = {
	TIP_OLD_PWD: '기존 비밀번호를 입력하세요',
	TIP_NEW_PWD: '새로운 비밀번호를 입력하세요',
	TIP_NEW_PWD_VERIFY: '새로운 비밀번호를 다시 한 번 입력하세요',
	// 个人信息修改页面 개인정보 수정 페이지
	PAGE_TITLE_AVATAR: '계정 정보 변경',
	AVATAR_TIP_NICK_NAME: '닉네임을 입력해 주세요',
};

// 绑定银行卡 은행카드 연동
const BIND_BANK_CARD = {
	REAL_NAME: '예금주 성명',
	TIP_REAL_NAME: '성함을 입력해주세요',
	BANK_NAME: '계좌 개설 은행명',
	TIP_BANK_NAME: '계좌를 개설하신 은행을 입력하거나 선택하세요',
	BANK_CARD: '은행카드번호',
	TIP_BANK_CARD: '은행카드번호를 입력하세요',
	BTN_CHANGE_BANK_CARD: '계정관리',
	BTN_BANK_SELECTED: '은행 선택',

};

// 提款页面 인출 페이지
const WITHDRAW = {
	PAGE_TITLE_WITHDRAW: '출금',
	WITHDRAW_AMOUNT: '나의 자산',
	WITHDRAW_TITLE: "자금인출",
	TIP_AMOUNT_AVAIL: '가용금액',
	WITHDRAW_WITH_AMOUNT: '인출금액',
	TIP_AMOUNT_WITHDRAW: '인출금액 입력',
	WITHDRAW_PAY_PWD: '출금 비밀번호',
	TIP_WITHDRAW_PWD: '결제 비밀번호를 입력하세요',
	WITHDRAWING_POST_TIP: '처리 중입니다...',

	// 提款说明 인출 설명
	WITHDRAW_TIP_TEXT: [`1. 현재 보유하고 있는 주식을 매도하기 전에는 인출이 불가합니다.`, `2. 인출을 위해서 인출 전 실명 및 계정 확인이 필요합니다.`,
		`3. 인출 거래 시간 : 평일 오전 9시 부터 오후 3시까지 (주말 및 공휴일은 불가)`, `4. 최소 인출 요청 금액은 10,000원입니다.`,
		`5. 인출 신청 후 원칙적으로는 당일 지정된 출금 계좌로 입금합니다. `,
		`※ 결제는 영업일 기준 최대 이틀(48시간) 내에 완료됩니다.`
	],
};

// 入金页面 입금 페이지
const DEPOSIT = {
	PAGE_TITLE_DEPOSIT: '예치',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: '예치금액을 입력하세요',
	DEPOSIT_TIP_LOW_AMOUNT: '최저1,000,000',
	DEPOSIT_POST_TIP: '처리 중입니다...',
	DEPOSIT_TIP_TITLE: '공지사항',
	DEPOSIT_TIP_TEXT: ['一、 예치시간: 평일 오전 9 시부터 오후 6 시까지이며 주말 및 공휴일은 쉽니다.',
		'저희를 선택해주셔서 감사합니다.자금 안전을 보장하기 위해 이체하실 계좌가 저희 플랫폼에 실시간으로 확인 가능한 계좌인지 확인해주시기 바라며 은행권 이외의 계좌에서 이체하실 때마다 저희 직원과 확인 부탁드립니다.저희 플랫폼에 실시간으로 표시되는 계좌로 송금하시고, 송금으로 인해 발생하는 모든 손실은 귀하가 책임지셔야 함을 알려드립니다.'
	],
};

// 个人中心页面 개인 센터 페이지
const ACCOUNT_CENTER = {
	// 个人中心 认证状态 개인 센터 인증상태
	ACCOUNT_AUTH_STATUS: ['인증되었습니다.[미인증]', '이미 확인되었습니다.[심사 중]', '이미 확인되었습니다[심사 실패]'],
	ACCOUNT_CHANGE_PWD: '로그인 비밀번호 변경',
	ACCOUNT_CHANGE_PAY_PWD: '결제 비밀번호 변경',
	ACCOUNT_CARD_MANAGEMENT: '은행카드 관리',
	ACCOUNT_TRADE_LOG: '잔액 변동 명세',
	ACCOUNT_SERVICE: '고객센터',
	ACCOUNT_AMOUNT_TOTAL: '총 자산',
	ACCOUNT_AMOUNT_AVAILABLE: '가용자금',
	ACCOUNT_MORE_FEATURES: '더 많은 기능',
	ACCOUNT_COLD_AMOUNT: '동결자금',
}

// 实名认证页面 실명인증 페이지
const AUTH = {
	PAGE_TITLE_AUTH: '실명인증',
	AUTH_TIP_ID_CARD: '정확한 신분증 번호를 입력해주세요',
	AUTH_TIP_CARD_F: '신분증 앞면을 업로드해주세요',
	AUTH_TIP_CARD_B: '신분증 뒷면을 업로드해주세요',
	AUTH_ID_CARD: '신분증 번호',
	AUTH_CARD_F: '신분증 정면 사진',
	AUTH_CARD_B: '신분증 뒷면 사진',
	AUTH_TIP_TEXT: '※ 일부 기능이 차단되지 않도록 실명인증을 완료해주시기 바랍니다.',
};

// 交易记录页面 거래기록 페이지
const TRADE_LOG = {
	TRADE_LOG_BTNS: ['입금/출금', '입금', '출금'],
	TRADE_LOG_TIP_MODAL_TITLE: '출금 요청을 취소하시겠습니까?',
	TRADE_LOG_WITHDRAW_STATUS: ['검토 중', '현금 인출 성공', '현금 인출 실패, 고객센터로 연락주세요', '거부됨'],
	LOG_TRADE_AMOUNT_BEFORE: '거래 전 잔액',
	LOG_TRADE_AMOUNT_AFTER: '거래 후 잔액',
	LOG_TRADE_DW: '거래 금액',
	LOG_TRADE_CREATE_TIME: '거래 시간',
	LOG_TRADE_DESC: '세부정보',
	LOG_TRADE_ORDER_SN: '거래 일련번호',
	LOG_TRADE_DW_DESC: '거래내역',
	LOG_WITHDRAW_AMOUNT: '인출액',
	LOG_STATUS: '상태',
};

// 交易页面 거래 ​​페이지
const ACCOUNT_TRADE = {
	TRADE_TITLE: '투자 성과',
	TRADE_TABS: ['보유기록', '매출기록'],
	TRADE_TOTAL_BUY_AMOUNT: '총 매수 금액',
	TRADE_VALUATION_GAIN_LOSS: '보유수익',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: '총수익',
	TRADE_RATE_RESPONSE: '투자 수익률',
	TRADE_TOTAL_GAIN: '수익 총액',
	// 持仓和卖出的记录 表头 보유 및 매도 기록 표 
	TRADE_LIST_THEAD: ['종목명', '평가손익', '보유수량', '평균가', '매수가', '시가'],
	TRADE_MOADL_TITLE: '주문',
	// 订单的label组  주문 label 그룹
	TRADE_MODAL_LABELS: ['종목명', '매수 시간', '매도 시간', '당기 손익', '레버리지', '손익 총액', '매수가', '수량', '수수료', '총 매수 금액', '코드'],
	// 卖出的二次确认 매도 재확인
	SELL_TIP: '매도 하시겠습니까?',

};

// 日内交易 일중 거래
const TRADE_DAY = {
	PAGE_TITLE_TRADE_DAY: '일중 거래',
	TRADE_DAY_TABS: ['일중거래', '신청현황', '승인내역'],
	TRADE_DAY_BUY: '신청',
	TRADE_DAY_TIP: '알림',
	TRADE_DAY_TIP_TEXT: ['주식은 인공 지능으로 구축된 시스템을 사용하여 당일 거래가 이루어집니다. 장이 마감되면 보유 중인 모든 주식이 정리되고 수익에 따라 결산됩니다.',
		'AI 당일 거래를 신청한 고객님은 AI 신호에 따라 자동으로 매수/매도되며 보유 중인 주식을 직접 매도할 수 있습니다.',
		'인공 지능 자동 거래 시 일부 거래 관련 정보는 비즈니스 비밀을 유지하기 위해 보호되고 관리됩니다.'
	],
	TRADE_DAY_BUY_AMOUNT: '신청금액',
	TRADE_DAY_SUCCESS_AMOUNT: '승인금액',
	TRADE_DAY_BUY_PRICE: '매수 금액',
	TRADE_DAY_ORDER_SN: '주문번호',
	TRADE_DAY_CREATE_TIME: '신청시간',
	TRADE_DAY_ORDER_STATUS: '상태',
	TRADE_DAY_MODAL_CONTENT: '주문을 제출하시겠습니까?',
	TRADE_DAY_TIP_INPUT_AMOUNT: '금액을 입력하세요',
};

// 大宗交易 블록딜 거래
const TRADE_LARGE = {
	PAGE_TITLE_TRADE_LARGE: '블록딜 거래',
	TRADE_LARGE_TABS: ['종목 리스트', '청약내역'],
	TRADE_LARGE_TAB1_TITLES: ['', ''],
	TRADE_LARGE_PRICE: '가격',
	TRADE_LARGE_RATE: '상승률',
	TEADE_LARGE_RATE_AMOUNT: '상승액',
	TRADE_LARGE_MIN_QTY: '최소매수량',
	TRADE_LARGE_MAX_QTY: '최대매수량',
	TRADE_LARGE_MIN_DAY: '최소 보유 기간',
	TRADE_LARGE_ITEM_LABELS: ['가격', '상승률'],
	TRADE_LARGE_ORDER_TITLE: '청약신청주문',
	TRADE_LARGE_BUY_AMOUNT: '매수가',
	TRADE_LARGE_TIP_BUY_COUNT: '매수량을 입력하세요',
	TRADE_LARGE_ORDER_AMOUNT: '매수수량',
	TRADE_LARGE_TIP_BUY_PWD: '결제 비밀번호를 입력해주세요',
	TRADE_LARGE_LOG_FINISH: '매수완료',
	TRADE_LARGE_LOG_PRICE: '매수가',
	TRADE_LARGE_LOG_NUM: '매수수량',
	TRADE_LARGE_LOG_AMOUNT: '총 매수가',
	TRADE_LARGE_LOG_LEVER: '레버리지',
	TRADE_LARGE_LOG_CREATE_TIME: '매수시간',
	TRADE_LARGE_BUY_TOTAL_AMOUNT: '총 매수가',
};

// IPO 交易 IPO 거래
const TRADE_IPO = {
	PAGE_TITLE_TRADE_IPO: 'IPO',
	TRADE_IPO_TABS: ['종목 청약', '청약기록', '청약성공'],
	TRADE_IPO_MODAL_TITLE: '공모주 청약신청',
	TRADE_IPO_MODAL_CONTENT: '청약을 신청을 원하시면 확인을 클릭해주세요',
	TADE_IPO_SUB_PRICE: '청약금액',
	TRADE_IPO_PE_RATE: '주가수익률',
	TRADE_IPO_SUB_CT: '청약시간',
	TRADE_IPO_POST_QTY: '발행량',
	TRADE_IPO_RAISE_MONEY: '모집자금',
	TRADE_IPO_LOG_LABELS: ['청약가', 'PER 비율', '청약시간', '순환'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO 청약성공 기록',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: '청약신청 수량',
	TRADE_IPO_SUCCESS_AMOUNT: '당첨수량',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: '청약신청 금액',
	TRADE_IPO_SUCCESS_ORDER_SN: '주문번호',
	TRADE_IPO_SUCCESS_CT: '일시',
};

// 股权 交易 지분 거래
const TRADE_EQUITY = {
	PAGE_TITLE_TRADE_EQUITY: '지분 거래',
	TRADE_EQUITY_SURPLUS: '남은 수량',
	TRADE_EQUITY_PRICE: '신청가격',
	TRADE_EQUITY_QTY: '신청수량',
	TRADE_EQUITY_TOTAL: '총 신청액',
	TRADE_EQUITY_SUCCESS_QTY: '승인된 수량',
	TRADE_EQUITY_SUCCESS_TOTAL: '승인된 총액',
	TRADE_EQUITY_SUB_AMOUNT: '납입완료 금액',
	TRADE_EQUITY_DEF_AMOUNT: '추가 납입 금액',
	TRADE_EQUITY_DEF_BTN: '추가납입',
	TRADE_EQUITY_DEF_AMOUNT_TIP: '추가 납입 금액을 입력하세요',
	TRADE_EQUITY_DEF_BTN_ALL: '전액',
};

// 单股详情页面 개별 주식 상세페이지
const STOCK_INFO = {
	PAGE_TITLE_STOCK_OVERVIEW: '주식상세',
	// 股票最新数值 주식 최신 수치
	STOCK_INFO_TITLES: ['시장가', '전일 종가', '고가', '저가', '거래량', '거래액'],
	// 股票详情 一级TABS 주식상세 일급
	STOCK_OVERVIEW_TABS: ['최근동향', '상세정보', '주식뉴스'],
	// 股票KLine TABS 주식
	STOCK_OVERVIEW_KLINE_TABS: ['분', '일', '주', '월'],
	// 单股购买页面 개별 주식 매수 페이지
	STOCK_BUY_QUANTITY: '수량',
	STOCK_BUY_TIP_QUANTITY: '수량을 입력해 주세요',
	STOCK_BUY_AMOUNT: '지불 금액',
	STOCK_BUY_FEE: '수수료',
	STOCK_BUY_CONFIRM: '매수 확인',
	// 单股概览 概览信息  주식 개요 개요 정보
	STOCK_BASE_INFO: ['회사순위', '코스닥', '평균가격', '주식수량', '외국인비율', '업종', '상세업종', '52주신고', '52주신저'],
	// 概览 개요
	STOCK_COMPANY: '회사 소개',
	STOCK_SALES: '매출액',
	STOCK_SALES_TABS: ['분기 매출', '연간 매출'],
	// 销售额三块数据 판매액 3가지 데이터 
	STOCK_SALES_TITLE: ['최근 매출', '최근 이익', '최근 순이익'],
	// 销售额折线上方的三个选项 매출 절환선 상단의 세 가지 옵션
	STOCK_SALES_KLINE_TABS: ['매출액', '영업이익', '순이익'],
	// 投资者交易趋势 투자자매매추세
	STOCK_TRADE_TREND_TITLE: '투자자 거래 트렌드',
	STOCK_TRADE_TREND_BUY_AMOUNT: ['순매수량', '누적 순매수량'],
	STOCK_TRADE_TREND_INFO_TITLE: ['개인', '기관', '외국'],
	STOCK_TRADE_TREND_RECENT_TITLE: '최근의 거래 트렌드',
	STOCK_TRADE_TREND_RECENT_LABELS: ['참조일자', '개인', '기관', '국외'],
	// 饼图的title 원그래프
	STOCK_TRADE_TREND_PIE_TITLE: '거래추이',
	STOCK_TRADE_SELL_EMPTY_TITLE: '공매도 물량',
	// 卖空量两组数据的Title 공매도 수량 데이터 타이틀
	STOCK_TRADE_SELL_EMPTY_ITEM_TITLES: ['공매도 물량', '공매도 잔액'],
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC: ['총 거래량 대비', '시가 대비'],
	// 行业内比较 업종내비교
	STOCK_INDUSTRY_TITLE: '업종 내 비교',
	STOCK_INDUSTRY_DESC: '자동차 부품',
	STOCK_INDUSTRY_DESC_SUFFIX: '중에',
	STOCK_INDUSTRY_DATA_TITLES: ['현재', '업종평균'],
	STOCK_INDUSTRY_DATA_LABELS: ['평가금액', '순이익증가율', '자산부채율', 'PER', 'PBR', 'ROE'],
};

// 市场页面 마켓 페이지
const MARKET = {
	MARKET_TABS: ['개요', '인기주', '지표', '뉴스'],
	// 市场概况 시장 개요
	MARKET_OVERVIEW_SELF_TITLE: '국내 종목',
	//国内、国外、虚拟货币 국내, 해외, 가상화폐
	MARKET_OVERVIEW_SELF_TABS: ['국내', '국외', '가상화폐'],
	MARKET_MORE_HOT_TITLE: '인기 상품 더보기',
	MARKET_NEWS_TITLE: '시장 뉴스',
	MARKET_OVERVIEW_THEAD: ['상승폭', '하락폭', '보고가격', '거래량', '거래대금'],
	// 热门股票 인기주
	MARKET_HOT_TABS: ['상승률', '하락률', '보고가격', '거래량', '거래대금', '외국인 순매수', '기관 순매수', '신규상장', '공매도비율'],
	// 热门股票过滤 인기주 필터
	MARKET_HOT_FILTER: ['날', '1주', '1월', '3월', '6월'],
	MARKET_HOT_THEAD: ['이름', '시가', '변동률', '현재지수'],
	// 市场指标 시장지표
	MARKET_INDEX_TABS: ['지수', '환율', '원료', '가상화폐'],
	MARKET_NEWS_TABS: ['뉴스', '시장', '경제', '업종', '채권', '재테크', '회사', '투자'],
	MARKET_NEWS_TIP: '상위 100명의 데이터만 제공',
};

// 首页中签弹层 당첨 메인 팝업창
const DIALOG_IPO_SUCCESS = {
	DIALOG_IPO_SUCCESS_TIP_TITLE: '축하드립니다',
	DIALOG_IPO_SUCCESS_TIP_TEXT: '공모 청약에 당첨되었습니다.',
	DIALOG_IPO_SUCCESS_LABEL_QTY: '수량',
	DIALOG_IPO_SUCCESS_LABEL_TOTAL: '총금액',
}

export default {
	TRANSLATE_TITLE: '언어를 선택해 주세요',
	LAUNCH_TITLE: '주식 온라인 거래 플랫폼',
	...TABBAR,
	...ACCESS,
	...ACCOUNT,
	...BIND_BANK_CARD,
	...WITHDRAW,
	...DEPOSIT,
	...ACCOUNT_CENTER,
	...AUTH,
	...TRADE_LOG,
	...ACCOUNT_TRADE,
	...TRADE_DAY,
	...TRADE_LARGE,
	...TRADE_IPO,
	...TRADE_EQUITY,
	...STOCK_INFO,
	...MARKET,
	...DIALOG_IPO_SUCCESS,
	LEVER: '레버리지',
	STOCK_ALL: '주식 목록',
	STOCK_FOLLOW: '관심리스트',
	// 首页股票列表表头 메인 페이지 주식 목록 헤더
	STOCK_THEAD: ['이름', '최신가', '상승률'],
	PAGE_TITLE_NOTIFICATION: '통지',
	PAGE_TITLE_SEARCH: '검색',
	TIP_SEARCH: '주식의 명칭 또는 코드를 입력하세요',
	SEARCH_HISTORY: '검색기록',
	SEARCH_CLEAR: '기록 지우기',
	// 折价交易  할인거래
	PAGE_TITLE_TRADE_DISCOUNT: '할인거래',
	TIP_POST_SUCCESS: '제출 성공',
	ABOUT_US: '우리에 대해서',
	CURRENCY_UNIT: '원',
	QUANTITY_UNIT: '주',
	UNIT_BILION: '억',
	UNIT_POS: '명',
	UNIT_DAY: '일',
	MORE: '더보기',
	BRIEF: '요약',
	EMPTY_NOTIFIY: '소식 없음',
	EMPTY_DATA: '데이터가 없습니다',
	BTN_CONFIRM: '확인',
	BTN_CONFI: '충전을 원하시면 고객센터로 연락주세요',
	BTN_CANCEL: '취소',
	BTN_SEND_SERVICE: '고객센터에 연락하기',
	BTN_DETAIL: '자세히',
	BTN_BUY: '매수',
	BTN_SELL: '매도',
	BTN_DETAIL_NOW: '바로 확인',
	STATUS_LOADING: "로딩중",
	STATUS_SUBMIT: '제출중',
	STATUS_REQUEST: '새로운 데이터 가져오기',
	STATUS_HTTP_ERROR: '비정상적 요청입니다. 다시 시도해 주세요',
	STATUS_UPLOAD: "업로드중",
}