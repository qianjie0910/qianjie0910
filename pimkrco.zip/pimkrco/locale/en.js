// 底部导航组
const TABBAR = {
	TABBAR_HOME: "Home",
	TABBAR_FOLLOW: "Follow",
	TABBAR_MARKET: 'Market',
	TABBAR_TRADE: 'Trade',
	TABBAR_ACCOUNT: 'Account',
};

// 账户管理相关 登入、注册
const ACCESS = {
	SIGN_IN: "Sign In",
	SIGN_UP: "Create Account",
	SIMGN_OUT: "Sign Out",
	GO_TO_SIGN_IN: 'Go To The Sign In',
	USER_NAME: 'Account',
	ENTER_USER_NAME: 'Enter Your Account',
	PASSWORD: 'Password',
	ENTER_PASSWORD: 'Enter Your Password',
	VERIFY_PASSWORD: 'Verify Password',
	ENTER_VERIFY_PASSWORD: 'Enter Your Password',
	INVITATION_CODE: 'Invitation Code',
	ENTER_INVITATION_CODE: 'Enter Your Code',
	TIP_PWD_NOEQUAL: 'The password entered twice is inconsistent',
	TIP_SUCCESS_SIGNIN: 'sign in suceesfully',
	TIP_SUCCESS_REGISTER: 'Registration has been completed, please log in',
	TIP_SIGNIN_ING: 'Logging in',
	TIP_SIGNUP_ING: 'Registering',
	TIP_REMEMBER_PWD: 'Remember password',
	API_TOKEN_EXPIRES: 'Token Expires. Please Sign In Again',
	TIP_SIGN_OUT_SUCCESS: 'Logout successful',
	TIP_AGREE: 'I agree',
	TIP_PRVITE_PACT: 'Privte and pact',
	TIP_CHECK_AGREE: 'Please checked agree',
};

// 变更登入密码、变更支付密码、变更账户信息
const ACCOUNT = {
	TIP_OLD_PWD: 'Enter the original password',
	TIP_NEW_PWD: 'Enter a new password',
	TIP_NEW_PWD_VERIFY: 'Enter new password again',
	// 个人信息修改页面
	PAGE_TITLE_AVATAR: 'Change account information',
	AVATAR_TIP_NICK_NAME: 'Enter your nickname',
};

// 绑定银行卡
const BIND_BANK_CARD = {
	REAL_NAME: 'Account holder name',
	TIP_REAL_NAME: 'Please type in your name',
	BANK_NAME: 'Bank name',
	TIP_BANK_NAME: 'Enter or select a bank',
	BANK_CARD: 'Bank card number',
	TIP_BANK_CARD: 'Enter bank card number',
	BTN_CHANGE_BANK_CARD: 'Account management',
	BTN_BANK_SELECTED: 'Choose',
};

// 提款页面
const WITHDRAW = {
	PAGE_TITLE_WITHDRAW: 'Withdraw money',
	WITHDRAW_AMOUNT: 'my assets',
	WITHDRAW_TITLE: "Withdraw funds",
	TIP_AMOUNT_AVAIL: 'Amount Available',
	WITHDRAW_WITH_AMOUNT: 'Withdraw amount',
	TIP_AMOUNT_WITHDRAW: 'Enter the withdrawal amount',
	WITHDRAW_PAY_PWD: 'Withdrawal password',
	TIP_WITHDRAW_PWD: 'Enter payment password',
	WITHDRAWING_POST_TIP: 'Processing....',
	// 提款说明
	WITHDRAW_TIP_TEXT: [`1. Cannot be withdrawn until the currently held shares are sold.`, `
2. In order to withdraw money, you need to verify your real name and verify your account before withdrawing money.`,
		`3. Withdrawal trading hours: 09:00-15:00 on weekdays (withdrawals are not allowed on weekends and public holidays).`,
		`4. The minimum amount to request a withdrawal is 10,000 .`,
		`5. After applying for withdrawal, in principle, it will be deposited into the designated withdrawal account on the same day.`,
		`※ Payment will be completed within 2 working days (48 hours) at most.`
	],
};

// 入金页面
const DEPOSIT = {
	PAGE_TITLE_DEPOSIT: 'Deposit',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: 'Enter the recharge amount',
	DEPOSIT_TIP_LOW_AMOUNT: 'Minimum 1,000,000',
	DEPOSIT_POST_TIP: 'Processing....',
	DEPOSIT_TIP_TITLE: 'Friendly reminder',
	DEPOSIT_TIP_TEXT: ['1. Recharge time: 09:00~18:00 on weekdays, closed on holidays.',
		'Thank you for choosing us. To ensure the safety of your funds, please ensure that the account you want to transfer to is the account displayed in real time on our platform, and please verify with our staff each time you transfer funds from a non-bank account. Accounts are displayed live on our platform and you are responsible for any losses incurred as a result of your deposits.'
	],
};

// 个人中心页面
const ACCOUNT_CENTER = {
	// 个人中心 认证状态
	ACCOUNT_AUTH_STATUS: ['Verified[Not verified]', 'Confirmed [under review]', 'Confirmed[Audit failed]'],
	ACCOUNT_CHANGE_PWD: 'Change login password',
	ACCOUNT_CHANGE_PAY_PWD: 'Change payment password',
	ACCOUNT_CARD_MANAGEMENT: 'Bank card management',
	ACCOUNT_TRADE_LOG: 'Capital flow',
	ACCOUNT_SERVICE: 'Customer service center',
	ACCOUNT_AMOUNT_TOTAL: 'Total assets',
	ACCOUNT_AMOUNT_AVAILABLE: 'Available funds',
	ACCOUNT_MORE_FEATURES: 'More Features',
	ACCOUNT_COLD_AMOUNT:'Freeze',
}

// 实名认证页面
const AUTH = {
	PAGE_TITLE_AUTH: 'Authentication',
	AUTH_TIP_ID_CARD: 'Enter the correct ID number',
	AUTH_TIP_CARD_F: 'Please upload a front-facing photo of your ID',
	AUTH_TIP_CARD_B: 'Please upload a photo of the back of your ID',
	AUTH_ID_CARD: 'ID number',
	AUTH_CARD_F: 'Photo of the front of the ID',
	AUTH_CARD_B: 'Photo of the back of the ID',
	AUTH_TIP_TEXT: '※ Please complete the real-name authentication to avoid blocking some functions.',
};

// 交易记录页面
const TRADE_LOG = {
	TRADE_LOG_BTNS: ['Dep/With', 'Deposit', 'Withdraw'],
	TRADE_LOG_TIP_MODAL_TITLE: 'Are you sure you want to cancel the withdrawal request?',
	TRADE_LOG_WITHDRAW_STATUS: ['Under review', 'Withdraw successfully',
		'Withdrawal failed, please contact customer service', 'Reject'
	],
	LOG_TRADE_AMOUNT_BEFORE: 'Balance before trade',
	LOG_TRADE_AMOUNT_AFTER: 'Balance after trade',
	LOG_TRADE_DW: 'Trade Amount',
	LOG_TRADE_CREATE_TIME: 'Trade Datetime',
	LOG_TRADE_DESC: 'Detail',
	LOG_TRADE_ORDER_SN: 'Trade order sn',
	LOG_TRADE_DW_DESC: 'Trade desc',
	LOG_WITHDRAW_AMOUNT: 'Withdrawal amount',
	LOG_STATUS: 'Status',
};

// 交易页面
const ACCOUNT_TRADE = {
	TRADE_TITLE: 'Investment results',
	TRADE_TABS: ['Hold record', 'Sell record'],
	TRADE_TOTAL_BUY_AMOUNT: 'Total purchase',
	TRADE_VALUATION_GAIN_LOSS: 'Profit and loss',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: 'Evaluation amount',
	TRADE_RATE_RESPONSE: 'Response rate',
	TRADE_TOTAL_GAIN: 'Total profit',
	// 持仓和卖出的记录 表头
	TRADE_LIST_THEAD: ['name', 'gains', 'QTY Hold', 'Eval', 'Price', 'Price'],
	TRADE_MOADL_TITLE: 'Order',
	// 订单的label组
	TRADE_MODAL_LABELS: ['name', 'Buy time', 'Sales time', 'Profit', 'Lever', 'Total profit', 'Price', 'QTY', 'Fee',
		'Total amount', 'Code'
	],
	// 卖出的二次确认
	SELL_TIP: 'Confirm sale?',
};

// 日内交易
const TRADE_DAY = {
	PAGE_TITLE_TRADE_DAY: 'Day trade',
	TRADE_DAY_TABS: ['Day trade', 'Status', 'Approval'],
	TRADE_DAY_BUY: 'Apply',
	TRADE_DAY_TIP: 'hint',
	TRADE_DAY_TIP_TEXT: [
		'Stocks use a quantitative system built with artificial intelligence for day trading. When the market closes, all held stocks will be liquidated and settled based on profits.',
		'Customers who apply for AI day trading will automatically buy/sell based on AI signals and can directly sell the stocks they hold. ',
		'In artificial intelligence automated trading, some transaction-related information is protected and managed to maintain business confidentiality.'
	],
	TRADE_DAY_BUY_AMOUNT: 'Application Amount',
	TRADE_DAY_SUCCESS_AMOUNT: 'Approval amount',
	TRADE_DAY_BUY_PRICE: 'Buying amount',
	TRADE_DAY_ORDER_SN: 'Order sn',
	TRADE_DAY_CREATE_TIME: 'Application time',
	TRADE_DAY_ORDER_STATUS: 'Status',
	TRADE_DAY_MODAL_CONTENT: 'Are you sure you want to submit your order?',
	TRADE_DAY_TIP_INPUT_AMOUNT: 'Enter the amount',
};

// 大宗交易
const TRADE_LARGE = {
	PAGE_TITLE_TRADE_LARGE: 'Large trade',
	TRADE_LARGE_TABS: ['Goods', 'Record', ],
	TRADE_LARGE_TAB1_TITLES: ['', ''],
	TRADE_LARGE_PRICE: 'Price',
	TRADE_LARGE_RATE: 'Rate',
	TEADE_LARGE_RATE_AMOUNT: 'Amount of increase',
	TRADE_LARGE_MIN_QTY: 'Min Buy QTY',
	TRADE_LARGE_MAX_QTY: 'Max Buy QTY',
	TRADE_LARGE_MIN_DAY: 'Min hold days',
	TRADE_LARGE_ITEM_LABELS: ['Price', 'Rate'],
	TRADE_LARGE_ORDER_TITLE: 'Subscription application order',
	TRADE_LARGE_BUY_AMOUNT: 'Price',
	TRADE_LARGE_TIP_BUY_COUNT: 'Enter the Buy QTY',
	TRADE_LARGE_ORDER_AMOUNT: 'Buy  QTY',
	TRADE_LARGE_TIP_BUY_PWD: 'Enter payment password',
	TRADE_LARGE_LOG_FINISH: 'Finish',
	TRADE_LARGE_LOG_PRICE: 'Price',
	TRADE_LARGE_LOG_NUM: 'Buy  QTY',
	TRADE_LARGE_LOG_AMOUNT: 'Total price',
	TRADE_LARGE_LOG_LEVER: 'Lever',
	TRADE_LARGE_LOG_CREATE_TIME: 'Buy time',
	TRADE_LARGE_BUY_TOTAL_AMOUNT: 'Total price',
};

// IPO 交易
const TRADE_IPO = {
	PAGE_TITLE_TRADE_IPO: 'IPO',
	TRADE_IPO_TABS: ['Goods', 'Record', 'Success'],
	TRADE_IPO_MODAL_TITLE: 'Public offering stock subscription application',
	TRADE_IPO_MODAL_CONTENT: 'If you want to apply for a subscription, please click Confirm',
	TADE_IPO_SUB_PRICE: 'Subscription',
	TRADE_IPO_PE_RATE: 'P/E ratio',
	TRADE_IPO_SUB_CT: 'Subscription time',
	TRADE_IPO_POST_QTY: 'Circulation',
	TRADE_IPO_RAISE_MONEY: 'Fund raising',
	TRADE_IPO_LOG_LABELS: ['Subscription price', 'P/E ratio', 'Subscription time', 'cycle'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO Subscription success record',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: 'Subscription QTY',
	TRADE_IPO_SUCCESS_AMOUNT: 'Winning',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: 'amount',
	TRADE_IPO_SUCCESS_ORDER_SN: 'Order sn',
	TRADE_IPO_SUCCESS_CT: 'Date time',
};

// EA交易
// 股权 交易
const TRADE_EQUITY = {
	PAGE_TITLE_TRADE_EQUITY: 'Equity',
	TRADE_EQUITY_SURPLUS: 'Surplus',
	TRADE_EQUITY_PRICE: 'Price',
	TRADE_EQUITY_QTY: 'Quantity',
	TRADE_EQUITY_TOTAL: 'Total Amount',
	TRADE_EQUITY_SUCCESS_QTY: 'Pass quantity',
	TRADE_EQUITY_SUCCESS_TOTAL: 'Pass total',
	TRADE_EQUITY_SUB_AMOUNT: 'Amount subscribed',
	TRADE_EQUITY_DEF_AMOUNT: 'Back payment',
	TRADE_EQUITY_DEF_BTN: 'Pay',
	TRADE_EQUITY_DEF_AMOUNT_TIP: 'Enter the back pay amount',
	TRADE_EQUITY_DEF_BTN_ALL: 'All',
};

// 单股详情页面
const STOCK_INFO = {
	PAGE_TITLE_STOCK_OVERVIEW: 'Stock details',
	// 股票最新数值
	STOCK_INFO_TITLES: ['market price', 'Closing price', 'high price', 'low price', 'Trading volume',
		'Trading amount'
	],
	// 股票详情 一级TABS
	STOCK_OVERVIEW_TABS: ['Time', 'Overview', 'news'],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['minute', 'day', 'week', 'moon'],
	// 单股购买页面
	STOCK_BUY_QUANTITY: 'quantity',
	STOCK_BUY_TIP_QUANTITY: 'Enter quantity',
	STOCK_BUY_AMOUNT: 'Payment amount',
	STOCK_BUY_FEE: 'Fee',
	STOCK_BUY_CONFIRM: 'Purchase',
	// 单股概览 概览信息
	STOCK_BASE_INFO: ['Company', 'Kosdak', 'amount', 'Number', 'Ratio', 'industry', 'Detailed', '52-week high',
		'52-week low'
	],
	// 概览 
	STOCK_COMPANY: 'Company Profile',
	STOCK_SALES: 'Sales',
	STOCK_SALES_TABS: ['Quarterly', 'Annual'],
	// 销售额三块数据
	STOCK_SALES_TITLE: ['recent ', 'Profit', 'Income'],
	// 销售额折线上方的三个选项
	STOCK_SALES_KLINE_TABS: ['Sales', 'Profit', 'Income'],
	// 投资者交易趋势
	STOCK_TRADE_TREND_TITLE: 'Investor Trading Trends',
	STOCK_TRADE_TREND_BUY_AMOUNT: ['net purchase quantity', 'Cumulative net buying volume'],
	STOCK_TRADE_TREND_INFO_TITLE: ['personal', 'mechanism', 'foreign'],
	STOCK_TRADE_TREND_RECENT_TITLE: 'recent trading trends',
	STOCK_TRADE_TREND_RECENT_LABELS: ['date', 'personal', 'mechanism', 'foreign'],
	// 饼图的title
	STOCK_TRADE_TREND_PIE_TITLE: 'trading trends',
	STOCK_TRADE_SELL_EMPTY_TITLE: 'selling volume',
	// 卖空量两组数据的Title
	STOCK_TRADE_SELL_EMPTY_ITEM_TITLES: ['selling volume', 'sale balance'],
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC: ['compared to total transaction volume', 'Relative to market capitalization'],
	// 行业内比较
	STOCK_INDUSTRY_TITLE: 'Comparison within the industry',
	STOCK_INDUSTRY_DESC: 'Auto parts',
	STOCK_INDUSTRY_DESC_SUFFIX: 'among',
	STOCK_INDUSTRY_DATA_TITLES: ['current', 'industry average'],
	STOCK_INDUSTRY_DATA_LABELS: ['Evaluation amount', 'net profit growth rate', 'Assets and liabilities', 'PER',
		'PBR', 'ROE'
	],
};

// 市场页面
const MARKET = {
	MARKET_TABS: ['Overview', 'Hot', 'index', 'news'],
	// 市场概况
	MARKET_OVERVIEW_SELF_TITLE: 'domestic',
	//国内、国外、虚拟货币
	MARKET_OVERVIEW_SELF_TABS: ["domestic", "foreign", "Currency"],
	MARKET_MORE_HOT_TITLE: 'View more popular items',
	MARKET_NEWS_TITLE: 'market news',
	MARKET_OVERVIEW_THEAD: ["Increase", "Decline", "Report price", "Trading volume", 'Amount of the transaction'],
	// 热门股票
	MARKET_HOT_TABS: ["Increase", "Decline", "Report price", "Trading volume", 'Amount of the transaction',
		'Foreign net purchases', 'Institutional net buying', 'New Listing', 'selling ratio'
	],
	// 热门股票过滤
	MARKET_HOT_FILTER: ['day', '1week', '1moon', '3moon', '6moon'],
	MARKET_HOT_THEAD: ['Name', 'Price', 'Rate', 'Index'],
	// 市场指标
	MARKET_INDEX_TABS: ['Index', 'Rate', 'Raw', 'Currency'],
	MARKET_NEWS_TABS: ['News', 'Market', 'economy', 'industry', 'bond', 'financial', 'company', 'invest'],
	MARKET_NEWS_TIP: 'Data only available for top 100. ',
};

// 首页中签弹层
const DIALOG_IPO_SUCCESS = {
	DIALOG_IPO_SUCCESS_TIP_TITLE: 'Congratulations',
	DIALOG_IPO_SUCCESS_TIP_TEXT: 'You won the public sale subscription.',
	DIALOG_IPO_SUCCESS_LABEL_QTY: 'Quantity',
	DIALOG_IPO_SUCCESS_LABEL_TOTAL: 'Total Amount',
}

export default {
	TRANSLATE_TITLE: 'Please select language',
	LAUNCH_TITLE: 'Online stock trading platform',
	...TABBAR,
	...ACCESS,
	...ACCOUNT,
	...BIND_BANK_CARD,
	...WITHDRAW,
	...DEPOSIT,
	...ACCOUNT_CENTER,
	...AUTH,
	...TRADE_LOG,
	...ACCOUNT_TRADE,
	...TRADE_DAY,
	...TRADE_LARGE,
	...TRADE_IPO,
	...TRADE_EQUITY,
	...STOCK_INFO,
	...MARKET,
	...DIALOG_IPO_SUCCESS,
	LEVER: 'Lever',
	STOCK_ALL: 'Stock List',
	STOCK_FOLLOW: 'Follow List',
	// 首页股票列表表头
	STOCK_THEAD: ['Name', 'Price', 'Rate'],
	PAGE_TITLE_NOTIFICATION: 'Notify',
	PAGE_TITLE_SEARCH: 'Search',
	TIP_SEARCH: 'Enter keywords',
	SEARCH_HISTORY: 'Search History',
	SEARCH_CLEAR:'Search Clear',
	// 折价交易
	PAGE_TITLE_TRADE_DISCOUNT: 'trade-in',
	TIP_POST_SUCCESS: 'Success',
	ABOUT_US: 'About Us',
	CURRENCY_UNIT: '원',
	QUANTITY_UNIT: '주',
	UNIT_BILION: 'Bilion',
	UNIT_POS: 'Position',
	UNIT_DAY: 'Day',
	MORE: 'More',
	BRIEF: 'Brief',
	EMPTY_NOTIFIY: 'Empty Notifiy',
	EMPTY_DATA: 'Empty Data',
	BTN_CONFIRM: 'Confirm',
	BTN_CANCEL: 'Cancel',
	BTN_SEND_SERVICE: 'Contact Customer Service',
	BTN_DETAIL: 'Details',
	BTN_BUY: 'Buy',
	BTN_SELL: 'Sell',
	BTN_DETAIL_NOW:'Detail Now',
	STATUS_LOADING: "loading",
	STATUS_SUBMIT: 'submitting',
	STATUS_REQUEST: 'Get new data',
	STATUS_HTTP_ERROR: 'Request exception, retrying',
	STATUS_UPLOAD: "Uploading",
}