import Vue from 'vue';
import {
	ACCOUNT_ACCESS
} from '@/common/paths.js';
import md5 from 'js-md5';

export const BASE_URL = `https://api.pimkrco.top`;

const CODE = "Qwd3N5yp";

export default async function http(url, params = {}) {
	console.log('url:', url, 'params:', params);
	const token = uni.getStorageSync("token") || '';
	const headers = {
		"Content-Type": "application/x-www-form-urlencoded",
		// 处理携带token
		"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
		"language": uni.getStorageSync('lang') || 'en', // 'zh-Hans'
	};
	const time = parseInt(new Date().getTime() / 1000);
	const str_url = `/api/${url}`.toLowerCase();
	const mdd = md5(`XPFXMedS${CODE + str_url + time}`);

	try {
		if (!params.hide) {
			// 默认显示状态
			uni.showLoading({
				title: params.title || Vue.prototype.$lang.STATUS_REQUEST,
			})
		}
		const response = await uni.request({
			url: `${BASE_URL}/api/${url}?sign=${mdd}&t=${time}`,
			method: params.method || 'GET',
			data: params.data || {},
			header: headers
		});
		if (!params.hide) {
			uni.hideLoading();
		}
		// console.log('response:', response);
		let [err, res] = response;		
		if (res.statusCode == 200) {
			if (res.data.code === 999) {
				uni.clearStorageSync();
				uni.$u.toast(Vue.prototype.$lang.API_TOKEN_EXPIRES);
				uni.$u.sleep(1000).then(() => {
					uni.navigateTo({
						url: ACCOUNT_ACCESS
					});
				})
				return false;
			}
			return res.data;
		} else {
			uni.$u.toast(Vue.prototype.$lang.STATUS_HTTP_ERROR);
		}
	} catch (error) {
		// console.log(error);
		throw error;
	}
};

uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('请求拦截', requestConfig);
	}
})