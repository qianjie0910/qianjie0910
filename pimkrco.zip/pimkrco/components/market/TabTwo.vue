<template>
	<view style="padding:10px;">
		<TabsSecond :tabs="$lang.MARKET_HOT_TABS" @action="changeTab"></TabsSecond>
		<template v-if="current<=1">
			<TabsThird :tabs="$lang.MARKET_HOT_FILTER" @action="changeTabFilter"></TabsThird>
		</template>

		<!-- <view class="flex flex-b titles" style="padding: 6px 10px;" :style="{color:$theme.TITLE}">
			<view class="flex-2">{{$lang.MARKET_HOT_THEAD[0]}}</view>
			<view class="flex-1 t-r">{{$lang.MARKET_HOT_THEAD[1]}}</view>
			<view class="flex-1 t-r">{{$lang.MARKET_HOT_THEAD[2]}}</view> 
		</view> -->
		<view style="padding:20px 0;">
			<ListPrimary :list="list" :serial="true"></ListPrimary>
		</view>

		<view style="text-align: center;color: #999;margin-top: 20px;">{{$lang.MARKET_NEWS_TIP}}</view>
	</view>
</template>

<script>
	import {
		postMarketHot
	} from '@/common/api.js';
	import TabsSecond from '@/components/tabs/TabsSecond.vue';
	import TabsThird from '@/components/tabs/TabsThird.vue';
	import ListPrimary from '@/components/list/ListPrimary.vue';
	export default {
		name: 'TabTwo',
		components: {
			TabsSecond,
			TabsThird,
			ListPrimary,
		},
		props: {},
		data() {
			return {
				list: [],
				current1: 0,
				current: 0,
			}
		},
		created() {
			this.getdata();
		},
		methods: {
			changeTab(val) {
				this.current = val;
				this.getdata();
			},
			changeTabFilter(val) {
				this.current1 = val;
				this.getdata()
			},

			async getdata() {
				const result = await postMarketHot({
					current: this.current,
					current1: this.current1,
				})
				this.list = result.data.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
					}
				});
			},
		},
	}
</script>