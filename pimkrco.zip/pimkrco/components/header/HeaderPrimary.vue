<template>
	<header class="common_header">
		<slot></slot>
		<template v-if="title!=''">
			<view class="header_title" :style="{color:color}">{{title}}</view>
		</template>
		<template v-if="isService">
			<image mode="aspectFit" src="/static/service_dark.png" :style="$util.setImageSize(40)"
				@click="linkService()" style="padding-right: 20px;"></image>
		</template>
		<template v-if="isSearch">
			<image mode="aspectFit" :src="`/static/${icon}.png`" :style="$util.setImageSize(40)" @click="linkSearch()"
				style="padding-right: 60px;"></image>
		</template>
		<!-- <image mode="aspectFit" src="/static/notification.png" :style="$util.setImageSize(40)" @click="linkNotifiy()"
			style="padding-right: 8rpx;"></image> -->
	</header>
</template>

<script>
	import {
		NOTIFICATION,
		SEARCH
	} from '@/common/paths.js';
	import Translate from '@/components/Translate.vue';
	export default {
		name: 'HeaderPrimary',
		components: {
			Translate
		},
		props: {
			// 标题
			title: {
				type: String,
				default: ''
			},
			// 标题文字颜色
			color: {
				type: String,
				default: '#333333'
			},
			// 是否需要搜索
			isSearch: {
				type: Boolean,
				default: false,
			},
			// 搜索的icon
			icon: {
				type: String,
				default: 'search',
			},
			// 是否需要客服
			isService: {
				type: Boolean,
				default: false,
			}
		},
		data() {
			return {};
		},
		methods: {
			// 跳转到通知页面
			// linkNotifiy() {
			// 	uni.navigateTo({
			// 		url: NOTIFICATION
			// 	})
			// },

			// 跳转到客服
			linkService() {
				this.$util.linkCustomerService();
			},
			// 跳转到查询页面
			linkSearch() {
				uni.navigateTo({
					url: SEARCH
				})
			}
		}
	}
</script>