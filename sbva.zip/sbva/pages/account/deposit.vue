<!-- 银转证  存款 -->
<template>
	<view style="background-color: #FFFFFF;">
		<HeaderSecond :title="$lang.PAGE_TITLE_DEPOSIT"></HeaderSecond>

		<view class="deposit_info_bg">
			<view style="display: flex;align-items: center; justify-content: space-around; padding:40px 20px 0 20px;">
				<view style="color:#FFFFFF;font-size: 32rpx;">
					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}[{{$lang.CURRENCY_UNIT}}]
				</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="color:#FFFFFF;font-size: 64rpx;font-weight: 700;padding-left:30px;line-height: 2.4;">
				{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
			</view>
		</view>

		<!-- <CustomTitle :title="$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT"></CustomTitle> -->


		<view style="padding: 20px 10px;">
			<!-- <view style="margin-left: 10px;color:#AFAFAF;">{{$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT}}</view> -->
			<!-- <view class="common_input_wrapper" style="background-color: #FFFFFF;border: 1px solid #E8EAF3;margin:10px;">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view> -->

			<!-- <view
				style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:10px;"> -->
				<!-- <block v-for="(item,index) in amountList" :key="index">
					<view style="padding:10px;border-radius: 6px;"
						:style="{backgroundColor:curPos==index?'#F5B71C':'#F6F8FC',color:curPos==index? '#FFFFFF':'#666666' }"
						@click="quantity(item,index)">
						{{item}}
					</view>
				</block> -->
			<!-- </view> -->
			<view class="access_btn" style="margin:20px auto; width: 90%;" @click="recharge()">
				고객센터로 연락하여 충전해주세요
			</view>
		</view>

		<view style="padding: 10px 20px;">
			<view style="font-size: 14px;font-weight: 700;text-align: center;" :style="{color:$theme.TITLE}">
				{{$lang.DEPOSIT_TIP_TITLE}}
			</view>
			<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
				<view style="padding-bottom:6px;color: #999;">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import {
		accountInfo,
		postDeposit
	} from '@/common/api.js';
	import {
		ACCOUNT_CENTER
	} from '@/common/paths.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
			};
		},
		computed: {
			amountList() {
				// 充值预置额
				return [1000000, 3000000, 5000000, 10000000];

			}
		},
		onLoad(option) {
			this.gaint_info()
			this.amount = this.amountList[0];
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			recharge(){
				this.$util.linkService();
			},
			
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				const result = await postDeposit({
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				}, this.$lang.DEPOSIT_POST_TIP);

				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			// //凭证
			// deletePic(event) {
			// 	this[`fileList${event.name}`].splice(event.index, 1)
			// },
			// // 新增图片
			// async afterRead(event) {
			// 	// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
			// 	let lists = [].concat(event.file)
			// 	let fileListLen = this[`fileList${event.name}`].length
			// 	lists.map((item) => {
			// 		this[`fileList${event.name}`].push({
			// 			...item,
			// 		})
			// 	})
			// 	for (let i = 0; i < lists.length; i++) {
			// 		const result = await this.uploadFilePromise(lists[i].url)
			// 		let item = this[`fileList${event.name}`][fileListLen]
			// 		this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
			// 			status: 'success',
			// 			message: '',
			// 			url: result
			// 		}))
			// 		fileListLen++
			// 	}
			// },
			//个人信息
			async gaint_info() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},

			// uploadFilePromise(url) {
			// 	// console.log(url)
			// 	pathToBase64(url).then(base64 => {
			// 			// 这就是转为base64格式的图片
			// 			this.is_url = base64
			// 			// console.log(base64)
			// 		})
			// 		.catch(error => {
			// 			console.error(error)
			// 		})
			// },
		},
	}
</script>