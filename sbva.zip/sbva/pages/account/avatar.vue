<template>
	<view style="background-image: linear-gradient(180deg, #F5B71C, transparent);">
		<HeaderSecond :title="$lang.PAGE_TITLE_AVATAR" color="#FFFFFF"></HeaderSecond>

		<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
			<view class="common_block" style="width: 80%;padding:20px;">
				<view style="width: 100%;height: 30vh;">
					<u-upload @afterRead="afterRead" @delete="deletePic" name="6" multiple :maxCount="1" width="360px"
						height="240px">
						<image :src="imgUrl" mode="aspectFit"></image>
					</u-upload>
				</view>

				<view class="common_input_wrapper" style="background-color:#FFFFFF;border: 1px solid #E8EAF3;">
					<image mode="aspectFit" src="/static/user.png" :style="$util.setImageSize(28)">
					</image>
					<input v-model="nick_name" type="text" :placeholder="$lang.AVATAR_TIP_NICK_NAME"
						:placeholder-style="$util.setPlaceholder()"></input>
				</view>

				<view class="common_btn btn_primary" style="margin-top: 20px;" @click="submit_list">
					{{$lang.BTN_CONFIRM}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import {
		ACCOUNT_CENTER
	} from '@/common/paths.js';
	import {
		putAccountInfo,
		userFastInfo
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				fileList6: [],
				is_url: "",
				imgUrl: '',
				nick_name: "",
			};
		},
		created() {
			this.userInfo()
		},
		methods: {
			async submit_list() {
				const result = await putAccountInfo({
					avatar: this.is_url,
					nickname: this.nick_name,

				})
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_CENTER
						});
						// 登录成功之后强制刷新页面
						this.$router.go(0)
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
			// 回调参数为包含columnIndex、value、values
			async userInfo() {
				const result = await userFastInfo();
				this.imgUrl = result.data.avatar
				this.nick_name = result.data.nick_name
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
			},
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
				this.src = this.fileList6[0].thumb
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						this.imgUrl = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
		},
	}
</script>