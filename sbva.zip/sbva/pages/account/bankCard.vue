<!-- 绑定银行卡 -->
<template>
	<view style="background-color: #FFFFFF;min-height: 100vh;">
		<view style="background-image: linear-gradient(180deg, #F5B71C, transparent);">
			<HeaderSecond :title="$lang.ACCOUNT_CARD_MANAGEMENT"></HeaderSecond>
		</view>

		<view style="margin: 20px;padding: 10px;">
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.REAL_NAME}}
			</view>
			<view class="common_input_wrapper"
				style="background-color:#FFFFFF;border: 1px solid #E8EAF3;padding-left: 10px;">
				<template v-if="isRenewal">
					<input v-model="realname" type="text" :placeholder="$lang.TIP_REAL_NAME"
						:placeholder-style="$util.setPlaceholder()"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;"> {{info.realname ||''}}
					</view>
				</template>
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.BANK_NAME}}
			</view>
			<view class="common_input_wrapper"
				style="background-color:#FFFFFF;border: 1px solid #E8EAF3;padding-left: 10px;">
				<template v-if="isRenewal">
					<input v-model="bank_name" type="text" :placeholder="$lang.TIP_BANK_NAME"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
					<view @click="handleShowBankList()"
						style="width:80px;height: 23px;line-height: 23px; background-color:#c7ddff;text-align: center;margin-right: 3px;border-radius: 6px;">
						{{$lang.BTN_BANK_SELECTED}}
					</view>
					<u-picker :show="showBankList" :columns="bankList" @cancel="showBankList = false"
						@confirm="handleConfirmBank" :cancelText="$lang.BTN_CANCEL"
						:confirmText="$lang.BTN_CONFIRM"></u-picker>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;"> {{info.bank_name ||''}}
					</view>
				</template>
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.BANK_CARD}}
			</view>
			<view class="common_input_wrapper"
				style="background-color:#FFFFFF;border: 1px solid #E8EAF3;margin-bottom: 30px;padding-left: 10px;">
				<template v-if="isRenewal">
					<input v-model="card_sn" type="text" :placeholder="$lang.TIP_BANK_CARD"
						:placeholder-style="$util.setPlaceholder()"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;"> {{info.card_sn}}
					</view>
				</template>
			</view>
			<template v-if="isRenewal">
				<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;">
					<view class="trade_modal_btn" style="background-color: #FF6700;" @click="replaceBank()">
						{{$lang.BTN_CONFIRM}}
					</view>
					<view class="trade_modal_btn" style="background-color:#F5B71C;" @click="handleCancel()">
						{{$lang.BTN_CANCEL}}
					</view>
				</view>
			</template>
			<template v-else>
				<view class="access_btn" style="margin:20px auto; width: 90%;" @click="renewal()">
					{{$lang.BTN_CHANGE_BANK_CARD}}
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_CENTER,
		ACCOUNT_AUTH
	} from '@/common/paths';
	import {
		accountInfo,
		bindBankCard
	} from '@/common/api.js';
	import {
		LIST_BANK
	} from '@/common/config.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				showBankList: false, // 是否显示银行备选列表
				info: {},
				isRenewal: false,
				realname: '', // 开户人
				bank_name: '', // 银行名称
				card_sn: '', // 卡号
			};
		},
		computed: {
			// 银行备选列表， u-picker中需要套一层数组
			bankList() {
				return [LIST_BANK];
			}
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleShowBankList() {
				this.showBankList = true;
			},
			handleConfirmBank(e) {
				console.log('e:', e);
				this.bank_name = e.value[0];
				this.showBankList = false;
			},
			renewal() {
				this.isRenewal = true;
			},
			handleCancel() {
				this.isRenewal = false;
				this.replaceBank();
			},
			// 换绑银行卡
			async replaceBank() {
				const result = await bindBankCard({
					realname: this.realname,
					bank_name: this.bank_name,
					card_sn: this.card_sn,
				})
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			//用户信息
			async gaint_info() {
				const result = await accountInfo();
				console.log(result);
				if (result.code == 0) {
					// 未有真实姓名，跳转到实名认证
					if (!result.data.real_name) {
						uni.navigateTo({
							url: ACCOUNT_AUTH,
						})
					}
					// 未有银行卡信息，自动切换到绑卡状态
					if (!result.data.bank_card_info) {
						this.isRenewal = true;
					} else {
						this.info = result.data.bank_card_info;
					}
				}
			},
		},
	}
</script>