<!-- 关于我们 -->
<template>
	<view>
		<view style="background-image: linear-gradient(180deg, #F5B71C, transparent);">
			<HeaderSecond :title="about.title"></HeaderSecond>
		</view>

		<view class="common_block" style="margin-top: 10px;min-height: 80vh;">
			<view v-html="about.content"
				style="font-size: 14px;white-space: break-spaces;line-height: 1.3;padding:10px;"
				:style="{color:$theme.TEXT}"></view>
		</view>
	</view>
</template>

<script>
	import {
		getAboutInfo
	} from '@/common/api.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				about: {},
			};
		},
		created() {
			this.getAbout()
		},
		methods: {
			//关于我们
			async getAbout() {
				const result = await getAboutInfo();
				this.about = result.data
			},
		},
	}
</script>