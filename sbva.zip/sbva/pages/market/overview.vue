<template>
	<view>
		<view class="market_header">
			<HeaderPrimary :title="$lang.TABBAR_MARKET"></HeaderPrimary>
		</view>
		<view
			style="background-color:#F8F8F8;width: 100%;margin-top: -60px;border-radius: 30px 30px 0 0;padding-top: 20px;">
			<TabsFourth :tabs="$lang.MARKET_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsFourth>

			<view>
				<TabOne v-if="curTab==0" ref="tab0"></TabOne>
				<TabTwo v-if="curTab==1"></TabTwo>
				<TabThree v-if="curTab==2"></TabThree>
				<TabFour v-if="curTab==3"></TabFour>
			</view>
		</view>
	</view>
</template>

<script>
import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import TabOne from '@/components/market/TabOne.vue'
	import TabTwo from '@/components/market/TabTwo.vue'
	import TabThree from '@/components/market/TabThree.vue'
	import TabFour from '@/components/market/TabFour.vue';
	
	export default {
		components: {
			HeaderPrimary,
			TabsFourth,
			TabOne,
			TabTwo,
			TabThree,
			TabFour
		},
		data() {
			return {
				curTab: 0,
				// timer: null,
			}
		},
		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type);
				// this.changeTab(this.curTab);
			}
		},
		onShow() {
			console.log('onShow', this.$refs.tab0);
			// if (this.$refs.tab0) {
			// 	this.$refs.tab0.onSetTimeout();
			// }
			this.changeTab(this.curTab);
		},
		onReady() {
			console.log('onReady', this.$refs.tab0);
		},
		onHide() {
			console.log('onHide', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},
		deactivated() {
			console.log('deactivated', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},

		methods: {
			changeTab(val) {
				if (this.$refs.tab0) {
					this.$refs.tab0.clearTimer();
				}
				this.curTab = val;
				if (this.curTab == 0) {
					if (this.$refs.tab0) {
						this.$refs.tab0.onSetTimeout();
					}
				}
			},
		},
	}
</script>