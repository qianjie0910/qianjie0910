<template>
	<view style="background-color: #FFFFFF;min-height: 100vh;">
		<view style="background-image: linear-gradient(180deg, #F5B71C, transparent);">
			<HeaderSecond :title="$lang.PAGE_TITLE_SEARCH"></HeaderSecond>
		</view>
		<view style="margin:20px;">
			<u-search shape="round" :placeholder="$lang.TIP_SEARCH" v-model="keyword" :showAction="false" height="40px"
				:searchIconColor="$theme.PRIMARY" searchIconSize="30" bgColor="#F2F4F5" @clear="keyword=''"
				:actionText="$lang.PAGE_TITLE_SEARCH" @search="searchButton" @custom="searchButton"></u-search>
		</view>

		<CustomTitle :title="$lang.SEARCH_HISTORY">
			<image mode="aspectFit" src="/static/delete.png" :style="$util.setImageSize(44)" style="margin-left: auto;"
				@click="clearKeywords()"></image>
		</CustomTitle>



		<view style="display: flex;align-items: center;margin:0 10px;padding:10px;flex-wrap: wrap;">
			<template v-if="keywords.length>0">
				<block v-for="(item,index) in keywords" :key="index">
					<view
						style="padding:4px 10px;margin:4px;border-radius: 16px;background-color: #F2F4F5;color:#333333;"
						@click="selectedItem(item)">{{item}}</view>
				</block>
			</template>
		</view>


		<view class="common_block" style="">
			<template v-if="!list || list.length<=0">
				<EmptyData img="search"></EmptyData>
			</template>

			<template v-else>
				<!-- <view style="display: flex;align-items: center;padding: 10px;border-bottom: 1px solid #A0A0A0;">
					<block v-for="(item,index) in $util.setStockListThead()" :key="index">
						<view style="font-size: 32rpx;"
							:style="{color:$theme.LABEL,flex:item.width,textAlign:item.align}">
							{{item.label}}
						</view>
					</block>
				</view> -->

				<ListPrimary :list="list"></ListPrimary>

			</template>
		</view>
	</view>
</template>
<script>
	import {
		postSearchList,
		updateFollow
	} from '@/common/api.js';
	import {
		STOCK_OVERVIEW
	} from '@/common/paths.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import ListPrimary from '@/components/list/ListPrimary.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
			CustomTitle,
			ListPrimary,
		},
		data() {
			return {
				keyword: "", // 当前关键词
				keywords: [], // 搜索词条组
				list: [], // 搜索结果
				curPage: 1,
				limit: 20,

				// gp_select: [{
				// 	name: "국내",
				// }, {
				// 	name: "해외",
				// }],
				// gp_index: 0,
			};
		},
		onReachBottom() {
			// 只要最大条数20，条件永不成立。
			if (this.list.length > this.limit) {
				this.curPage++;
				this.searchButton();
			}
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
		},
		methods: {
			// 点击查看股票详情
			handleStockInfo(code) {
				uni.navigateTo({
					url: `${STOCK_OVERVIEW}?code=${code}`,
				})
			},
			// 清空搜索记录
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = []; // 手动清理缓存数据
				this.list = []; // 查询结果重置
			},

			// 选中一项搜索历史词条 
			selectedItem(item) {
				this.keyword = item;
				this.searchButton()
			},

			//搜索
			async searchButton() {
				if (this.keyword == '' || this.keyword.length < 3) {
					uni.$u.toast(this.$lang.TIP_SEARCH);
					return false;
				}
				const result = await postSearchList({
					key: this.keyword,
					page: this.curPage,
					limit: this.limit,
					gp_index: 0
				})
				if (result.code == 0) {
					this.list = result.data.map(item => {
						return {
							logo: item.logo,
							name: item.name,
							code:item.code,
							price: item.current_price,
							rate: item.rate,
						}
					});
					console.log('search result:', result.data)
					if (this.keywords.indexOf(this.keyword) < 0) {
						this.keywords.push(this.keyword);
						uni.setStorageSync("keywords", this.keywords)
					}
				}
			},
			// 取关
			async handleUnFollow(gid) {
				const result = await updateFollow({
					gid: gid,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.getList()
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>