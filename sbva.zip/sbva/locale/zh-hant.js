// 底部导航组
const TABBAR = {
	TABBAR_HOME: "首頁",
	TABBAR_FOLLOW: "關注",
	TABBAR_MARKET: '市場',
	TABBAR_TRADE: '交易',
	TABBAR_ACCOUNT: '我的',
};

// 账户管理相关 登入、注册
const ACCESS = {
	SIGN_IN: "登入",
	SIGN_UP: "加入會員",
	SIMGN_OUT: "登出",
	GO_TO_SIGN_IN: '去登入',
	USER_NAME: '帳號',
	ENTER_USER_NAME: '請輸入帳戶',
	PASSWORD: '密碼',
	ENTER_PASSWORD: '請輸入密碼',
	VERIFY_PASSWORD: '驗證密碼',
	ENTER_VERIFY_PASSWORD: '請再輸入密碼',
	INVITATION_CODE: '邀請碼',
	ENTER_INVITATION_CODE: '請輸入邀請碼',
	TIP_PWD_NOEQUAL: '兩次輸入密碼不一致',
	TIP_SUCCESS_SIGNIN: '登入成功',
	TIP_SUCCESS_REGISTER: '註冊已完成，請登入',
	TIP_SIGNIN_ING: '登錄中',
	TIP_SIGNUP_ING: '註冊中',
	TIP_REMEMBER_PWD: '記住密碼',
	API_TOKEN_EXPIRES: '登陸狀態已過期，請重新登入',
	TIP_SIGN_OUT_SUCCESS: '登出成功',
	TIP_AGREE: '我已閱讀並同意',
	TIP_PRVITE_PACT: '用戶隱私協定',
	TIP_CHECK_AGREE: '請勾選同意用戶隱私協定',
};

// 变更登入密码、变更支付密码、变更账户信息
const ACCOUNT = {
	TIP_OLD_PWD: '請輸入原密碼',
	TIP_NEW_PWD: '請輸入新密碼',
	TIP_NEW_PWD_VERIFY: '請再輸入新密碼',
	// 個人資訊修改頁面
	PAGE_TITLE_AVATAR: '更改帳號資訊',
	AVATAR_TIP_NICK_NAME: '請輸入你的暱稱',
};

// 绑定银行卡
const BIND_BANK_CARD = {
	REAL_NAME: '開戶人姓名',
	TIP_REAL_NAME: '請輸入姓名',
	BANK_NAME: '開戶銀行名稱',
	TIP_BANK_NAME: '請輸入或選擇開戶行',
	BANK_CARD: '銀行卡號',
	TIP_BANK_CARD: '請輸入銀行卡號碼',
	BTN_CHANGE_BANK_CARD: '帳戶管理',
	BTN_BANK_SELECTED: '選擇銀行',
};

// 提款页面
const WITHDRAW = {
	PAGE_TITLE_WITHDRAW: '提款',
	WITHDRAW_AMOUNT: '我的資產',
	WITHDRAW_TITLE: "提取資金",
	TIP_AMOUNT_AVAIL: '可用金額',
	WITHDRAW_WITH_AMOUNT: '提領金額',
	TIP_AMOUNT_WITHDRAW: '輸入提款金額',
	WITHDRAW_PAY_PWD: '提款密碼',
	TIP_WITHDRAW_PWD: '請輸入付款密碼',
	WITHDRAWING_POST_TIP: '處理中....',

	// 提款说明
	WITHDRAW_TIP_TEXT: [`1.在出售目前持有的股票之前無法提取。`, `2.為了提款，您需要在提款前驗證您的真實姓名並驗證您的帳戶。`,
		`3.提現交易時間：平日09:00-15:00（週末及公眾假期不可提現）.`, `4.請求提款的最低金額為 10,000 韓元.`, `5.申請提款後，原則上當日存入指定提款帳戶. `,
		`※ 付款將在 2 個工作天（48 小時）內完成.`
	],
};

// 入金页面
const DEPOSIT = {
	PAGE_TITLE_DEPOSIT: '儲值',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: '輸入儲值金額',
	DEPOSIT_TIP_LOW_AMOUNT: '最低1000000',
	DEPOSIT_POST_TIP: '處理中....',
	DEPOSIT_TIP_TITLE: '友情提示',
	DEPOSIT_TIP_TEXT: ['一、儲值時間：平日09:00~18:00，假日休息。 ',
		'感謝您選擇我們。為了確保您的資金安全，請確保您要轉帳的帳戶是我們平台上即時顯示的帳戶，每次從非銀行帳戶轉帳時請與我們的工作人員核實。我們平台上即時顯示的帳戶，您應對因存款而產生的任何損失負責。 '
	],
};

// 个人中心页面
const ACCOUNT_CENTER = {
	// 个人中心 认证状态
	ACCOUNT_AUTH_STATUS: ['已驗證[未驗證]', '已確認[審核中]', '已確認[審核失敗]'],
	ACCOUNT_CHANGE_PWD: '變更登錄密碼',
	ACCOUNT_CHANGE_PAY_PWD: '變更支付密碼',
	ACCOUNT_CARD_MANAGEMENT: '銀行卡管理',
	ACCOUNT_TRADE_LOG: '餘額變動明細',
	ACCOUNT_SERVICE: '客戶服務',
	ACCOUNT_AMOUNT_TOTAL: '總資產',
	ACCOUNT_AMOUNT_AVAILABLE: '可用資金',
	ACCOUNT_MORE_FEATURES: '更多功能',
}

// 实名认证页面
const AUTH = {
	PAGE_TITLE_AUTH: '實名認證',
	AUTH_TIP_ID_CARD: '請輸入正確的證件號碼',
	AUTH_TIP_CARD_F: '請上傳證件正面照',
	AUTH_TIP_CARD_B: '請上證件背面照',
	AUTH_ID_CARD: '證件號碼',
	AUTH_CARD_F: '證件正面照',
	AUTH_CARD_B: '證件背面照',
	AUTH_TIP_TEXT: '※ 請完成實名認證，以免部分功能受阻。 ',
};

// 交易记录页面
const TRADE_LOG = {
	TRADE_LOG_BTNS: ['存款/提款', '存款', '提領'],
	TRADE_LOG_TIP_MODAL_TITLE: '確定取消提款請求嗎？ ',
	TRADE_LOG_WITHDRAW_STATUS: ['審核中', '提現成功', '提現失敗，請聯絡客服', '拒絕'],
	LOG_TRADE_AMOUNT_BEFORE: '交易前餘額',
	LOG_TRADE_AMOUNT_AFTER: '交易後餘額',
	LOG_TRADE_DW: '交易額',
	LOG_TRADE_CREATE_TIME: '交易時間',
	LOG_TRADE_DESC: '詳情',
	LOG_TRADE_ORDER_SN: '交易流水號',
	LOG_TRADE_DW_DESC: '交易明細',
	LOG_WITHDRAW_AMOUNT: '提現額',
	LOG_STATUS: '狀態',
};

// 交易页面
const ACCOUNT_TRADE = {
	TRADE_TITLE: '投資成果',
	TRADE_TABS: ['持有記錄', '賣出記錄'],
	TRADE_TOTAL_BUY_AMOUNT: '總購買量',
	TRADE_VALUATION_GAIN_LOSS: '持股獲利',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: '總收益',
	TRADE_RATE_RESPONSE: '回報率',
	TRADE_TOTAL_GAIN: '利潤總額',
	// 持倉和賣出的記錄 表頭
	TRADE_LIST_THEAD: ['項目名稱', '估價損益', '持有數量', '平均價格', '購買價格', '時價'],
	TRADE_MOADL_TITLE: '訂單',
	// 訂單的label群組
	TRADE_MODAL_LABELS: ['項目名稱', '購買時間', '銷售時間', '當期損益', '槓桿', '損益總額', '購買價格', '數量', '手續費', '總購買金額', '代碼'],
	// 賣出的二次確認
	SELL_TIP: '確認賣出嗎？ ',

};

// 日内交易
const TRADE_DAY = {
	PAGE_TITLE_TRADE_DAY: '日內交易',
	TRADE_DAY_TABS: ['日內交易', '申請狀態', '核准詳情'],
	TRADE_DAY_BUY: '申請',
	TRADE_DAY_TIP: '提示',
	TRADE_DAY_TIP_TEXT: ['股票採用人工智慧建構的量化系統進行當天交易，當收盤時，所有持有的股票將被清算，並根據利潤進行結算。 ',
		'申請AI當日交易的客戶將根據AI訊號自動買入/賣出，並可以直接賣出所持有的股票。 ', '在人工智慧自動交易中，一些與交易相關的資訊受到保護和管理，以維護商業機密。 '
	],
	TRADE_DAY_BUY_AMOUNT: '申請金額',
	TRADE_DAY_SUCCESS_AMOUNT: '核准金額',
	TRADE_DAY_BUY_PRICE: '買入金額',
	TRADE_DAY_ORDER_SN: '訂單編號',
	TRADE_DAY_CREATE_TIME: '申請時間',
	TRADE_DAY_ORDER_STATUS: '狀態',
	TRADE_DAY_MODAL_CONTENT: '確定提交訂單嗎？ ',
	TRADE_DAY_TIP_INPUT_AMOUNT: '請輸入金額',
};

// 大宗交易
const TRADE_LARGE = {
	PAGE_TITLE_TRADE_LARGE: '大宗交易',
	TRADE_LARGE_TABS: ['產品清單', '交易記錄'],
	TRADE_LARGE_TAB1_TITLES: ['', ''],
	TRADE_LARGE_PRICE: '價格',
	TRADE_LARGE_RATE: '漲幅',
	TEADE_LARGE_RATE_AMOUNT: '漲額',
	TRADE_LARGE_MIN_QTY: '最少購買量',
	TRADE_LARGE_MAX_QTY: '最大購買量',
	TRADE_LARGE_MIN_DAY: '最低持倉天數',
	TRADE_LARGE_ITEM_LABELS: ['價格', '漲幅率'],
	TRADE_LARGE_ORDER_TITLE: '認購申請單',
	TRADE_LARGE_BUY_AMOUNT: '購買價格',
	TRADE_LARGE_TIP_BUY_COUNT: '請輸入購買數量',
	TRADE_LARGE_ORDER_AMOUNT: '購買數量',
	TRADE_LARGE_TIP_BUY_PWD: '請輸入付款密碼',
	TRADE_LARGE_LOG_FINISH: '購買完成',
	TRADE_LARGE_LOG_PRICE: '購買價格',
	TRADE_LARGE_LOG_NUM: '購買數量',
	TRADE_LARGE_LOG_AMOUNT: '購買總價',
	TRADE_LARGE_LOG_LEVER: '槓桿',
	TRADE_LARGE_LOG_CREATE_TIME: '購買時間',
	TRADE_LARGE_BUY_TOTAL_AMOUNT: '購買總價',
};

// IPO 交易
const TRADE_IPO = {
	PAGE_TITLE_TRADE_IPO: 'IPO',
	TRADE_IPO_TABS: ['產品申購', '申購記錄', '申購成功'],
	TRADE_IPO_MODAL_TITLE: '公開發行股票認購申請',
	TRADE_IPO_MODAL_CONTENT: '如果您想申請訂閱，請點選 確認',
	TADE_IPO_SUB_PRICE: '認購金額',
	TRADE_IPO_PE_RATE: '本益比',
	TRADE_IPO_SUB_CT: '訂閱時間',
	TRADE_IPO_POST_QTY: '發行量',
	TRADE_IPO_RAISE_MONEY: '募集資金',
	TRADE_IPO_LOG_LABELS: ['認購價', '本益比', '訂閱時間', '순환'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO 申購成功記錄',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: '申購數量',
	TRADE_IPO_SUCCESS_AMOUNT: '中籤數量',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: '申購金額',
	TRADE_IPO_SUCCESS_ORDER_SN: '訂單編號',
	TRADE_IPO_SUCCESS_CT: '日期時間',
};

// 股权 交易
const TRADE_EQUITY = {
	PAGE_TITLE_TRADE_EQUITY: '股權 交易',
	TRADE_EQUITY_SURPLUS: '餘量',
	TRADE_EQUITY_PRICE: '申請價格',
	TRADE_EQUITY_QTY: '申請數量',
	TRADE_EQUITY_TOTAL: '申請總額',
	TRADE_EQUITY_SUCCESS_QTY: '通過數量',
	TRADE_EQUITY_SUCCESS_TOTAL: '通過總額',
	TRADE_EQUITY_SUB_AMOUNT: '已認繳金額',
	TRADE_EQUITY_DEF_AMOUNT: '補繳金額',
	TRADE_EQUITY_DEF_BTN: '補繳',
	TRADE_EQUITY_DEF_AMOUNT_TIP: '請輸入補繳金額',
	TRADE_EQUITY_DEF_BTN_ALL: '全部',
};

// 单股详情页面
const STOCK_INFO = {
	PAGE_TITLE_STOCK_OVERVIEW: '股票詳情',
	// 股票最新數值
	STOCK_INFO_TITLES: ['市價', '前日收盤價', '高價', '低價', '交易量', '交易額'],
	// 股票詳情 一級TABS
	STOCK_OVERVIEW_TABS: ['最新', '概況', '新聞'],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['分', '日', '週', '月'],
	// 單股購買頁面
	STOCK_BUY_QUANTITY: '數量',
	STOCK_BUY_TIP_QUANTITY: '請輸入數量',
	STOCK_BUY_AMOUNT: '付款金額',
	STOCK_BUY_FEE: '手續費',
	STOCK_BUY_CONFIRM: '確認購買',
	// 單股概覽 概覽資訊
	STOCK_BASE_INFO: ['公司排名', '科斯達克', '平均價格', '股份數量', '外國人比例', '行業', '詳細行業', '52週新高', '52週新低'],
	// 概覽
	STOCK_COMPANY: '公司簡介',
	STOCK_SALES: '銷售',
	STOCK_SALES_TABS:['季度銷售','年度銷售'],
	// 銷售額三塊數據
	STOCK_SALES_TITLE: ['最近銷售', '最近營利', '最近淨利'],
	// 銷售額折線上方的三個選項
	STOCK_SALES_KLINE_TABS: ['銷售額', '營業利潤', '淨利'],
	// 投資者交易趨勢
	STOCK_TRADE_TREND_TITLE: '投資者交易趨勢',
	STOCK_TRADE_TREND_BUY_AMOUNT: ['淨購買數量', '累積淨買入量'],
	STOCK_TRADE_TREND_INFO_TITLE: ['個人', '機構', '國外'],
	STOCK_TRADE_TREND_RECENT_TITLE: '最近的交易趨勢',
	STOCK_TRADE_TREND_RECENT_LABELS: ['參考日期', '個人', '機構', '國外'],
	// 圓餅圖的title
	STOCK_TRADE_TREND_PIE_TITLE: '交易趨勢',
	STOCK_TRADE_SELL_EMPTY_TITLE: '賣空量',
	// 賣空量兩組資料的Title
	STOCK_TRADE_SELL_EMPTY_ITEM_TITLES: ['賣空量', '賣空餘額'],
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC: ['與總交易量相比', '相對於市值'],
	// 產業內比較
	STOCK_INDUSTRY_TITLE: '產業內比較',
	STOCK_INDUSTRY_DESC: '汽車零件',
	STOCK_INDUSTRY_DESC_SUFFIX: '之中',
	STOCK_INDUSTRY_DATA_TITLES: ['目前', '產業平均'],
	STOCK_INDUSTRY_DATA_LABELS: ['評價金額', '淨利潤成長率', '資產負債比率', 'PER', 'PBR', 'ROE'],
};

// 市场页面
const MARKET = {
	MARKET_TABS: ['概況', '熱股', '指標', '新聞'],
	// 市場概況
	MARKET_OVERVIEW_SELF_TITLE: '國內品',
	//國內、國外、虛擬貨幣
	MARKET_OVERVIEW_SELF_TABS: ["國內", "國外", "虛擬貨幣"],
	MARKET_MORE_HOT_TITLE: '看更多熱門商品',
	MARKET_NEWS_TITLE: '市場新聞',
	MARKET_OVERVIEW_THEAD: ["上漲幅度", "下跌幅度", "申報價格", "交易量", '交易金額'],
	// 熱門股票
	MARKET_HOT_TABS: ['上升率', '下降率', '報告價格', '交易量', '交易金額', '외국인순매수', '機構淨買入', '新上市', '賣空比例'],
	// 熱門股票過濾
	MARKET_HOT_FILTER: ['天', '1週', '1月', '3月', '6月'],
	MARKET_HOT_THEAD: ['名稱', '時價', '波動率', '當前指數'],
	// 市場指標
	MARKET_INDEX_TABS: ['指數', '匯率', '原料', '虛擬貨幣'],
	MARKET_NEWS_TABS: ['新聞', '市場', '經濟', '產業', '債券', '理財', '公司', '投資'],
	MARKET_NEWS_TIP: '僅提供前 100 名的資料. ',
};

export default {
	TRANSLATE_TITLE: '请选择语言',
	...TABBAR,
	...ACCESS,
	...ACCOUNT,
	...BIND_BANK_CARD,
	...WITHDRAW,
	...DEPOSIT,
	...ACCOUNT_CENTER,
	...AUTH,
	...TRADE_LOG,
	...ACCOUNT_TRADE,
	...TRADE_DAY,
	...TRADE_LARGE,
	...TRADE_IPO,
	...TRADE_EQUITY,
	...STOCK_INFO,
	...MARKET,
	LEVER: '槓桿',
	STOCK_ALL: '股票列表',
	STOCK_FOLLOW: '關注列表',
	// 首頁股票清單表頭
	STOCK_THEAD: ['名稱', '最新價', '漲幅率'],
	PAGE_TITLE_NOTIFICATION: '通知',
	PAGE_TITLE_SEARCH: '搜尋',
	TIP_SEARCH: '請輸入股票的名稱或代號',
	SEARCH_HISTORY: '搜尋記錄',
	// 折價交易
	PAGE_TITLE_TRADE_DISCOUNT: '折價交易',
	TIP_POST_SUCCESS: '提交成功',
	ABOUT_US: '關於我們',
	CURRENCY_UNIT: '원',
	QUANTITY_UNIT: '주',
	UNIT_BILION: '億',
	UNIT_POS: '名',
	UNIT_DAY: '天',
	MORE: '更多',
	BRIEF: '簡單',
	EMPTY_NOTIFIY: '暫無訊息',
	EMPTY_DATA: '暫無資料',
	BTN_CONFIRM: '確認',
	BTN_CANCEL: '取消',
	BTN_SEND_SERVICE: '聯絡客服',
	BTN_DETAIL: '詳情',
	BTN_BUY: '購買',
	BTN_SELL: '賣出',
	STATUS_LOADING: "載入中",
	STATUS_SUBMIT: '提交中',
	STATUS_REQUEST: '取得新資料',
	STATUS_HTTP_ERROR: '請求異常，正在重試',
	STATUS_UPLOAD: "上傳中",
}