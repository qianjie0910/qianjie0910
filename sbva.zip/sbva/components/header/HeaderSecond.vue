<template>
	<header class="common_header">
		<view class="custom_header_left" @click="actionEvent()">
			<view class="arrow rotate_225" :style="arrowStyle"></view>
		</view>
		<text class="custom_header_center" :style="{color:color}">{{title}}</text>
		<view class="custom_header_right"></view>
	</header>
</template>

<script>
	export default {
		name: 'HeaderSecond',
		props: {
			// 标题
			title: {
				type: String,
				default: 'TITLE'
			},
			// 标题文字颜色
			color: {
				type: String,
				default: '#333333'
			},
		},
		data() {
			return {};
		},
		computed: {
			// 设置回退箭头的样式
			arrowStyle() {
				return {
					...this.$util.setImageSize(20),
					// 通常与标题文字同色
					borderColor: this.color
				}
			}
		},
		methods: {
			actionEvent() {
				// 默认回退一级
				uni.navigateBack({
					delta: 1,
				})
				// 特殊回退，外部使用该事件
				this.$emit('action', '');
			}
		}
	}
</script>
