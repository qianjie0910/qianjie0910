<template>
	<view class="btns" style="">
		<block v-for="(item,index) in btns" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize(80)"></image>
				<text style="padding-top: 6px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: ['btns'],
		data() {
			return {};
		},

		methods: {
			actionEvent(url, index) {
				if(url=="/pages/servicePush"){
					this.$util.linkService();
					return 
				}
				if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>