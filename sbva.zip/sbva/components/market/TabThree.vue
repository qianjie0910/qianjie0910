<template>
	<view style="padding:10px;">
		<TabsSecond :tabs="$lang.MARKET_INDEX_TABS" @action="handleChangeTab"></TabsSecond>
		<view style="padding:6px 10px;display: flex;align-items: center;" :style="{color:$theme.TITLE}">
			<view style="flex:50%;">{{$lang.MARKET_HOT_THEAD[0]}}</view>
			<view style="flex:30%;text-align: right;padding-right: 16px;">
				{{current==0?$lang.MARKET_HOT_THEAD[1] :$lang.MARKET_HOT_THEAD[3] }}
			</view>
			<view style="flex:20%;text-align: right;padding-right: 16px;">{{$lang.MARKET_HOT_THEAD[2]}}</view>
		</view>

		<ListPrimary :list="list" :serial="true"></ListPrimary>

		<view style="text-align: center;color: #999;margin-top: 20px;">{{$lang.MARKET_NEWS_TIP}} </view>
	</view>
</template>

<script>
	import {
		postMarketIndex
	} from '@/common/api.js';
	import TabsSecond from '@/components/TabsSecond.vue';
	import ListPrimary from '@/components/list/ListPrimary.vue';
	export default {
		name: 'TabThree',
		components: {
			TabsSecond,
			ListPrimary
		},
		props: {},
		data() {
			return {
				list: [],
				current: 0,
			}
		},
		created() {
			this.getList()
		},
		methods: {
			handleChangeTab(val) {
				this.current = val;
				this.getList();
			},
			async getList() {
				const result = await postMarketIndex({
					current: this.current
				});
				if (result.code == 0) {
					const temp = this.$util.ObjectConvertArray(result.data);
					this.list = temp.map(item => {
						return {
							logo: item.logo,
							name: item.ko_name,
							price: item.close,
							rate: item.returns,
						}
					});
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>