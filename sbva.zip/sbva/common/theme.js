/* change theme 挂在全局，方便后期做主题切换 */

// 主题，一些通用的颜色值 硬编码
export default {
	PRIMARY: '#F5B71C', // 
	RISE: '#FF533B', // 股票涨
	FALL: '#00B45A',// 股票跌	
	
	LABEL:'#666666', // 列表的标题
	
	
	ACCESS_TEXT: '#FFFFFF', // 标题文字	
	TITLE:'#666666', // 	
	
	STOCK_NAME: '#121212',
	FG: ' #AFAFAF',
	SECONDARY: '#FF8C00',	
	// LABEL: '#F7F7F7',
	TEXT: '#333333', // D3D3D3
	TIP: '#333333',
	PLACEHOLDER: '#66666652', // 输入框占位符
};