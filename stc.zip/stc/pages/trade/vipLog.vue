<!-- 短打交易记录 -->
<template>
	<view class="common_page_bg">
		<CustomHeader title="기관 거래 우선가" @action="handleBack()"></CustomHeader>
		<TradeLog url="duanda"></TradeLog>
		
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TradeLog from '@/components/TradeLog.vue';
	export default {
		components: {
			CustomHeader,TradeLog
		},
		data() {
			return { };
		},
		onLoad(option) {
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
		}
	}
</script>

