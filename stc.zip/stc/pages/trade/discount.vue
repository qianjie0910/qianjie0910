<!-- 折价交易 -->
<template>
	<view>
		<CustomHeader :title="title" @action="handleBack()"></CustomHeader>
		<view class="common_block" style="padding: 6px;">
			<TradeHeader :title="title" icon="block_trade" @action="handlePayHistory()"></TradeHeader>
			<TradeList type="discount" :height="85" @action="handleGoodDetail"></TradeList>
		</view>

		<u-popup :show="show" @close="close" mode="bottom" :closeable='closeable' :round="10">
			<view v-if="info" class="largeAmount">
				<view class="business">
					청약 신청 내역
				</view>
				<view class="price">매입 가격</view>
				<view class="purchase-price">{{$util.formatNumber(info.price)}}</view>
				<view class="purchase-text">
					<u-input type="number" placeholder="매입 수량을 입력하세요." v-model="value1"></u-input>
					<view class="hand">확인</view>
				</view>
				<view class="price">레버리지</view>
				<view class="available" @click="ganggan_show=true">
					<u-input type="number" style="pointer-events: none;" :disabled="true" placeholder=""
						v-model="ganggan" inputAlign='right'>
					</u-input>
				</view>
				<view class="amount">매입 가격 <text>{{info.price*this.value1/ganggan|addZero}} </text> </view>
				<view class="available">
					<u-input type="password" placeholder="비밀번호 6자리 입력해주세요." v-model="value2"></u-input>
				</view>
				<view class="fund">
					사용 가능 잔액 <text>{{$util.formatNumber(availableFunds.money)}}</text>
				</view>
				<view class="purchase" @click="bulkPurchase(info.id)" style="background-color:  #4b5fcc;			margin: 30rpx;
			border-radius: 20rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;">매입</view>
			</view>
		</u-popup>
		<u-action-sheet :show="ganggan_show" :actions="actions" title="레버리지를 선택하세요" @close="ganggan_show = false"
			@select="Select">
		</u-action-sheet>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TradeHeader from '@/components/TradeHeader.vue';
	import TradeList from '@/components/TradeList.vue';
	export default {
		components: {
			CustomHeader,
			TradeHeader,
			TradeList
		},
		data() {
			return {
				options: {},
				show: false,
				closeable: true,
				value1: '',
				value2: '',
				value3: '',
				availableFunds: '',
				info: {},
				ganggan: 1,
				ganggan_show: false,
				actions: [{
					name: '1',
					index: 1
				}],
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {
			// this.largeAmount()
			this.available()
		},
		onShow() {
			this.available()
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			// 单项详情
			handleGoodDetail(val) {
				this.show = true;
				this.bulkDetails(val);
			},
			// 查看购买历史
			handlePayHistory() {
				uni.navigateTo({
					url: '/pages/trade/discountLog'
				});
			},

			Select(e) {
				console.log(e);
				this.ganggan = e.index
			},
			close() {
				this.show = false
				// console.log('close');
			},

			// 单条数据详情
			async bulkDetails(val) {
				const result = await this.$http.get('api/goods-discount/detail', {
					id: val
				})
				this.info = result.data.data
			},
			//点击购买
			async bulkPurchase(id) {
				let list = await this.$http.post('api/goods-discount/doOrder', {
					id: id,
					num: this.value1,
					pay_pass: this.value2,
					ganggan: this.ganggan
					// password: this.value3,
				})
				if (list.data.code == 0) {
					this.show = false
					uni.$u.toast(list.data.message);
					this.value1 = ''
					this.value2 = ''
					this.value3 = ''
					this.available()
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/trade/largeLog'
						});
					}, 1000)
				} else {
					if (this.value1 == '') {
						this.show = false
						uni.$u.toast('구매 수량을 입력해주세요.');
						setTimeout(() => {
							this.show = true
						}, 1000)
					} else if (this.value2 == '') {
						this.show = false
						uni.$u.toast('펀드 비밀번호를 입력해주세요');
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
					// else if (this.value3 == '') {
					// 	this.show = false
					// 	uni.$u.toast('请填写주주들은 지분을 줄인다密码');
					// 	setTimeout(() => {
					// 		this.show = true
					// 	}, 1000)
					// } 
					else {
						this.show = false
						uni.$u.toast(list.data.message);
						setTimeout(() => {
							this.show = true
						}, 1000)
					}
				}
			},
			// 사용 가능한 자금 可用资金
			async available() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.availableFunds = list.data.data
				this.actions = list.data.data.ganggan
			},

		},

		//取小数点之后的2位
		filters: {
			addZero: function(data) {
				return data.toFixed(0)
			}
		},

	}
</script>

<style lang="scss">
	//弹窗
	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 30rpx;
			color: #333;
			border-bottom: 1px solid #e0e0e0;
			height: 45px;
			line-height: 45px;
			border-top-left-radius: 10px;
			border-top-right-radius: 10px;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 5px 0 0 6px;
		}

		.purchase-price {
			color: #ea3544;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #e0e0e0;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #999;
			font-size: 24rpx;
			padding: 0 9px;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}

		.available {
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #999;
			font-size: 24rpx;
			padding: 0 9px;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}
	}
</style>