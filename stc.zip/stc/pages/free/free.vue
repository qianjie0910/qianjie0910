<!-- 收藏的 -->
<template>
	<view class="common_page_bg">
		<Header :title="$lang.FAVORITES"></Header>

		<view class="common_block" style="margin-top: 30rpx;min-height: 100vh;">
			<view style="display: flex;align-items: center;padding:20rpx;">
				<text style="flex:60%;color: #121212;">주식/코드</text>
				<text style="flex:20%;color: #121212;">등락률</text>
				<text style="flex:10%;color: #121212;">최신</text>
				<view style="flex:6%;"> </view>
			</view>

			<EmptyData v-if="business.length<=0"></EmptyData>

			<block v-for="(item,index) in business" :key="index">
				<view style="padding: 12rpx 30rpx;display: flex;align-items: center;"
					:style="{backgroundColor:index%2===0?'#fff':'rgba(255, 255, 255, 0.75)'}"
					@click="$u.route('/pages/productDetails/productDetails',{code:item.goods.code});">

					<view style="flex: 6%;padding:10rpx 0;">
						<template v-if="!item.goods.logo || item.goods.logo==''">
							<view :style="$util.setImageSize(60)"
								style="background-color:#2d2c62;text-align: center;line-height: 60rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">
								{{item.goods.name.slice(0,1)}}
							</view>
						</template>
						<template v-else>
							<view style="display: flex;flex-direction: column;justify-content: center;">
								<image mode="aspectFit" :src="setLogo(item.goods.logo)" :style="$util.setImageSize(60)"
									style="border-radius: 100%;"></image>
							</view>
						</template>
					</view>

					<view style="flex: 40%;padding-left: 10rpx;">
						<view>{{item.goods.name}}</view>
						<view style="font-size: 24rpx;color: #999;">{{item.goods.code}}</view>
					</view>

					<view style="flex:30%;color:#121212;">
						{{$util.formatNumber(item.goods.current_price*1)}}
					</view>

					<view style="flex:20%;" :style="{color:`${item.goods.rate>0?'#ff3636':'#18BFB4'}`}">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<image mode="aspectFit" :src="`/static/${item.goods.rate>0?'up':'down'}.png`"
								:style="$util.setImageSize(20)"></image>
							<view>{{$util.formatMathABS(1*item.goods.rate).toFixed(2)}}%</view>
						</view>
					</view>
					<view style="flex: 4%;margin-left:10px;">
						<image style="width: 12px; height: 12px;" mode="aspectFit" src="/static/star2.png"></image>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			EmptyData
		},
		data() {
			return {
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				business: '',
				updata: true,
				// exchange: '',
				timerId: null
			}
		},
		//页面显示了，会触发多次，只要页面隐藏，然后再显示出来都会触发
		onShow() {
			this.free()
			// this.market()
			// this.is_token()
			this.startTimer()
		},
		onLoad() {
			this.startTimer()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		methods: {
			setLogo(val) {
				return this.$BaseUrl + val;
			},

			//产品세부
			productDetails(gid) {
				uni.navigateTo({
					url: `/pages/productDetails/productDetails?gid=${gid}`
				});
			},

			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.business = list.data.data.list;
			},

			// async market() {
			// 	let list = await this.$http.get('api/goods/updownlist', {
			// 		page: 1,
			// 		limit: 10,
			// 	})
			// 	//上证指数
			// 	this.exchange = list.data.data.zhishu
			// },
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.free();
					// this.market()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
		},
	}
</script>