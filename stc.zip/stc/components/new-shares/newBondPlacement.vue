<template>
	<view>
		<view class="white-background">
			<view class="take-notes">
				<view class="purchase" @tap="applyPurchase()">
					<image src="../../static/erceng/shengou.png" mode=""></image>
					<view class="">구독기록</view>
				</view>
				<view class="purchase" @tap="luckyNumber()">
					<image src="../../static/erceng/shengou.png" mode=""></image>
					<view class="">
						우승기록
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			applyPurchase() {
				uni.navigateTo({
					url: '/pages/applyPurchaseLog'
				});
			},

			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
		}
	}
</script>

<style lang="scss">
	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.take-notes {
			display: flex;
			justify-content: space-around;
			align-items: center;
			text-align: center;
			padding: 60rpx 60rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;

			.purchase {
				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}
	}
</style>
