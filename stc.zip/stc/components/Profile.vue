<!-- 用户基本信息 -->
<template>
	<view class="common_block" style="margin-bottom: 30rpx;">
		<view style="display: flex;align-items: center;padding:20rpx 60rpx;">
			<view style="flex:20%">
				<image style="width: 60px; height: 80px;" mode="aspectFit" src="/static/applogo.png"></image>
			</view>
			<view style="flex:80%;padding-left: 10px;">
				<view style="font-size: 20px;text-align: left;font-weight: 700;color: #333;">
					{{info.real_name}}
				</view>
				<view style="font-size: 12px;text-align: left;font-weight: 700;color: #999;">
					{{info.p_mobile}}
				</view>
			</view>
		</view>
		<view style="display: flex;align-items: center;line-height: 1.8;padding:0 60rpx 30rpx 60rpx;">
			<view style="flex:50%">
				<view>총자산
					<image :src="`/static/${yan_show?'zhengyan':'biyan' }.png`" mode="aspectFit"
						:style="$util.setImageSize(30)" @click="toggleAmount()" style="padding-left: 20rpx;"></image>
				</view>
				<view style="color:#18BFB4;font-size: 36rpx;">
					{{yan_show? $util.formatNumber(info.totalZichan):hideAmount  }}
				</view>
			</view>

			<view style="flex:50%">
				<view>예수금 </view>
				<view style="color:#18BFB4;font-size: 36rpx;">{{yan_show? $util.formatNumber(info.money):hideAmount  }}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true,
				hideAmount: '****',
			};
		},
		methods: {
			toggleAmount() {
				this.yan_show = !this.yan_show;
			}
		}
	}
</script>

<style>

</style>