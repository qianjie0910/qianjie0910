<template>
	<view style="padding:100rpx 30rpx;text-align: center;width: 100%;color:#999;min-height: 15vh;">{{$lang.ENPTY_DATA}}</view>
</template>

<script>
	export default {
		name: "EmptyData",
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>