<template>
	<view class="common_block" style="padding: 6px;">
		<view style="position: relative;">
			<view
				style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #283480;position: absolute;top: 10px;">
			</view>
		</view>
		<u-tabs :list="list1" style="margin: 10px 10px;"
			activeStyle="color:#fff;font-weight: 700;background:#283480;padding:5px 10px;border-radius:6px"
			lineColor="#f3f4f8" @change="change" :current="current">

		</u-tabs>

		<view>
			<view class="list">
				<view class="list">
					<view class="item flex flex-b" v-for="(item,index) in list" @click="open(item.url)">
						<view class="img" v-if="current==0">
							<image :src="item.pic"></image>
						</view>

						<view class="flex-2">
							<view class="t el">{{item.title}}</view>
							<view class="t1">{{item.created_at}}
							</view>
						</view>
					</view>

				</view>
			</view>
			<view style="text-align: center;color: #999999;" class="content-end-text">특징종목은 총 100위까지<br>순위만 제공합니다.
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TabOne',
		components: {},
		props: {},
		data() {

			return {
				show: false,
				list1: [{
					name: '뉴스',
				}, {
					name: '시장',
				}, {
					name: '경제'
				}, {
					name: '산업'
				}, {
					name: '채권'
				}, {
					name: '파생'
				}, {
					name: '기업'
				}, {
					name: '투자'
				}],

				list: [],
				current: 0,

			}
		},

		methods: {
			open(url) {
				window.open(url)
			},
			async lists() {
				uni.showLoading({

				})
				let list = await this.$http.post('api/goods/get_news', {
					current: this.current
				})
				this.list = list.data.data
				uni.hideLoading()
			},

			change(index) {
				console.log(index)
				this.current = index.index;
				this.lists()
			},

		},

		mounted() {

			this.lists()
		},

		onLoad() {},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	text {
		box-sizing: border-box;
	}

	.list {
		padding: 10px;

		.item {
			margin-bottom: 16px;

			.img {
				width: 120px;
				height: 80px;
				margin-right: 10px;
				border-radius: 5px;

				image {
					width: 100%;
					height: 100%;
					border-radius: 5px;
				}
			}

			.t {
				color: #333;
			}

			.t1 {
				color: #999;
				margin-top: 10px;
			}
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 50px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 50px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			font-weight: 700;
			color: #014b8d;

			span {
				background: #014b8d;
			}
		}
	}
</style>