// 页面URL 硬编码 通常用于指定跳转
export const LAUNCH = `/pages/launch`; // 启动页
export const ACCOUNT_ACCESS = `/pages/account/access`; // 登入、注册
export const HOME = `/pages/index/index`; // 主页

export const SERVICE = `/pages/service`; // 客服
export const ABOUT_US = `/pages/about`; // 关于、隐私协议、用户协议、版本更新
export const SEARCH = `/pages/search`; // 搜索 
export const NOTIFICATION = `/pages/notification`; // 通知 

export const ACCOUNT_WITHDRAW = `/pages/account/withdraw`; // 提款
export const ACCOUNT_DEPOSIT = `/pages/account/deposit`; // 存款
export const ACCOUNT_AUTH = `/pages/account/auth`; // 认证
export const ACCOUNT_CENTER = `/pages/account/center`; // 个人中心
export const ACCOUNT_PWD = `/pages/account/pwd`; // 登入密码
export const ACCOUNT_PWD_PAY = `/pages/account/pwdPay`; // 支付密码
export const ACCOUNT_BANK_CARD = `/pages/account/bankCard`; // 银行卡 绑定换绑
export const ACCOUNT_TRADE = `/pages/account/trade`; // 个人交易
export const ACCOUNT_TRADE_LOG = `/pages/account/tradeLog`; // 账户交易记录
export const ACCOUNT_AVATAR = `/pages/account/avatar`; // 变更头像
export const ACCOUNT_PRVITE_PACT = `/pages/account/pact`; // 用户隐私协议

export const TRADE_AI = `/pages/trade/ai`; // AI交易
export const TRADE_DAY = `/pages/trade/day`; // 日内交易
export const TRADE_LARGE = `/pages/trade/large`; // 大宗交易
export const TRADE_IPO = `/pages/trade/ipo`; // ipo交易
export const TRADE_DISCOUNT = `/pages/trade/discount`; // 折扣交易
export const TRADE_EQUITY = `/pages/trade/equity`; // 股权交易

export const MARKET_OVERVIEW = `/pages/market/overview`; // 市场概况

export const STOCK_ALL = `/pages/stock/all`; // 全部股票
export const STOCK_FOLLOW = `/pages/stock/follow`; // 关注的股票
export const STOCK_OVERVIEW = `/pages/stock/overview`; // 单股概况
export const STOCK_BUY = `/pages/stock/buy`; // 单股买入

// 设置当前挂载主页按钮组的链接
export const HOME_BTNS_LINK = [
	TRADE_DAY, TRADE_LARGE, TRADE_DISCOUNT, TRADE_IPO,
	ACCOUNT_DEPOSIT, ACCOUNT_WITHDRAW, ACCOUNT_AUTH, SERVICE
];