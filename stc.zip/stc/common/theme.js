/* 将一些常用的放在这里，每个项目，注释掉未使用的那些常量及函数 */
const PRIMARY = '#FFB044'; // 通常为主要配色
const SECOND = '#14102B';
const THIRD = '#FF2D30';
const RISE = PRIMARY; // 涨/跌
const FALL = '#12F6B8'; // 跌/涨
const TRANSPARENT = 'transparent'; // 使用父级元素颜色

const PROGRESS_FROM = '#6458FF'; // 进度条渐变 之一
const PROGRESS_TO = '#29205E'; // 进度条渐变 之二

const LOG_LABEL = '#CBCBCF'; // 一些记录的明文颜色
const LOG_VALUE = '#FFFFFF'; // 一些记录的数据颜色

const LABEL = '#CBCBCF'; // 列表的标题
// ACCESS_TEXT: '#FFFFFF', // 标题文字	 
// TITLE: '#666666', // 
// STOCK_NAME: '#121212',
// FG: ' #AFAFAF',
// SECONDARY: '#FF8C00',
// // LABEL: '#F7F7F7',
// TEXT: '#333333', // D3D3D3
// TIP: '#333333',
// PLACEHOLDER: '#CBCBCF', // 输入框占位符

// flex布局相关 水平
const DISPLAY_FLEX = {
	display: 'flex',
	alignItems: 'center',
};

// 渐变色设置
const linerGradient = (deg, from, to) => {
	return {
		backgroundImage: `linear-gradient(${deg}deg, ${from} ,${to})`
	}
};

// 渐变值
const LG_PRIMARY = linerGradient(90, '#F87D7B', '#AFF8DF');
const LG_SECOND = linerGradient(90, '#41EB87', '#3AF5C2');
const LG_THIRD = linerGradient(90, '#FF2D30', '#FE7FD3');
const LG_FOURTH = linerGradient(90, '#12F6C0', '#FFB044');
const LG_FIFTH = linerGradient(90, '#BB44FF', '#6458FF');

// 按钮通用样式 之一 在tabs中为激活样式
const btnCommon = (isActive, obj = {}) => {
	let style = {
		...DISPLAY_FLEX,
		justifyContent: 'center',
		flex: '1 1 auto',
		margin: '6rpx',
		borderRadius: '16rpx',
		color: isActive ? SECOND : PRIMARY,
		fontSize: '28rpx',
		// 非激活按钮有边框，为保证同等大小，激活需要加1像素值
		// padding: `${isActive?'6px 26px' :'5px 25px'}`,
		lineHeight: '1.3',
		textAlign: 'center',
	};

	if (!isActive) {
		style.border = `2px solid ${PRIMARY}`;
	} else {
		style = {
			...style,
			...linerGradient(90, PRIMARY, THIRD),
		}
	}
	return style = {
		...style,
		...obj,
	};
}

// 交易记录 数据状态
const setStatusPrimary = (val) => {
	// 渐变的背景
	const temp = [LG_PRIMARY, LG_SECOND, LG_THIRD, LG_THIRD];
	// 文字的颜色
	// const colors = ['#FF6700', '#00B45A', '#00A9DE', '#f56a6a'];

	let style = {
		borderRadius: '4rpx',
		fontSize: '24rpx',
		padding: '4rpx 12rpx',
		color: '#14102B',
		width: 'max-content',
		...temp[val],
	};
	return style;
}



// 主题，一些通用的颜色值 硬编码
export default {
	PRIMARY,
	RISE,
	FALL,
	LOG_LABEL,
	LOG_VALUE,
	LG_PRIMARY,
	LG_SECOND,
	LG_THIRD,
	LG_FOURTH,
	LG_FIFTH,

	linerGradient,
	btnCommon,
	setStatusPrimary,




};