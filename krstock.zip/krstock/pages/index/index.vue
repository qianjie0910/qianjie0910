<template>
	<view class="page">
		<view class="home"
			style="padding: 30px 10px 10px 20px;background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));">
			<view class="flex flex-b">

				<view class="flex-1 flex " style="color: #fff;font-size: 38rpx;">
					<view class="margin-right-10">
						<u-avatar size='30' :src="userinfo.avatar" default-url="/static/logo.png"
							shape="circle"></u-avatar>
					</view>
					<view class="font-size-18 bold" style="color: #333333;">
						{{userinfo.real_name}}
					</view>
				</view>

				<view class="flex-1 flex justify-end margin-right-10"
					@click="$u.route({url:'/pages/searchFor/searchFor'});">
					<image src="../../static/sousuo.png" mode="widthFix" style="width: 20px;"></image>
				</view>

			</view>

			<view style="border-radius: 23rpx;width: 100%;background-color: #ffffff;padding: 20px 10px;"
				class="margin-top-25">
				<view class="flex">
					<view class=" flex-column text-center flex flex-1" @click="link(3,'/pages/position/position')">
						<view class=" text-center flex">
							<image src="/static/home/top1.png" style="width: 50px;height: 50px;"></image>
						</view>
						<!-- 倒卖 -->
						<view class="margin-top-5 font-size-11">
							거래
						</view>
					</view>


					<view class="flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newShares?index=3')">
						<!-- <u-icon name="/static/home/top2.png" style="width: 30px;height: 30px;"></u-icon> -->
						<image src="/static/home/top2.png" style="width: 50px;height: 50px;"></image>
						<view class="margin-top-5 font-size-11">
							블록딜
						</view>
					</view>

					<view class="flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/aiBank/aiBank')">
						<view class="flex-column text-center flex">
							<image src="/static/home/top3.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							AI 트레이딩
						</view>
					</view>
					<view class="flex-column text-center flex flex-1"
						@click="link(3,'/pages/index/components/newShares/newSharesIPO?index=0')">
						<view class=" flex-column text-center flex">
							<!-- <u-icon name="/static/home/top4.png" ></u-icon> -->
							<image src="/static/home/top4.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							IPO
						</view>
					</view>
				</view>

				<view class="margin-top-25  flex">
					<view class="flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/certificateBank/silver')">
						<view class="flex-column text-center flex">
							<!-- <u-icon name="/static/home/top5.png"></u-icon> -->
							<image src="/static/home/top5.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							입금
						</view>
					</view>


					<view class="flex-column text-center flex flex-1"
						@click="link(2,'/pages/my/components/certificateBank/prove')">
						<view class="flex-column text-center flex">
							<!-- <u-icon name="/static/home/top6.png"></u-icon> -->
							<image src="/static/home/top6.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							출금
						</view>
					</view>

					<view class="flex-column text-center flex flex-1"
						@click="link(2,'/pages/marketQuotations/authentication')">
						<view class="flex-column text-center flex">
							<!-- <u-icon name="/static/home/top7.png"></u-icon> -->
							<image src="/static/home/top7.png" style="width: 50px;height: 50px;"></image>
						</view>
						<view class="margin-top-5 font-size-11">
							실명인증
						</view>
					</view>
					<view class="flex-column text-center flex flex-1"
						@click="link(1,'/pages/marketQuotations/marketQuotations')">
						<view class="flex-column text-center flex">
							<!-- <u-icon name="/static/home/top8.png" ></u-icon> -->
							<image src="/static/home/top8.png" style="width: 50px;height: 50px;"></image>

						</view>
						<view class="margin-top-5 font-size-11">
							시장정보
						</view>
					</view>
				</view>
			</view>

			<view class="font-size-18 color-black  margin-top-20">
				계정
			</view>
			<view class="radius20 padding-20 color-white margin-top-10"
				style="background: linear-gradient(to right, #2E67F6, #6492FF);">
				<view class="flex flex-b">
					<view class="font-size-18">총자산</view>
					<view class="flex">
						<view class="radius10  font-size-14" style="background-color: #FFC156;padding: 5px 10px;"
							@click="$u.route({url:'/pages/index/components/customer/customer'});">충전</view>
						<view class="radius10 font-size-14 margin-left-10 color-black"
							style="background-color: #fff;padding: 5px 10px;"
							@click="$u.route({url:'/pages/my/components/certificateBank/prove'});">출금신청</view>
					</view>
				</view>
				<view class="font-size-25 margin-top-10 bold">
					₩{{userinfo.totalZichan}}
				</view>
				<view class="flex flex-b margin-top-20">
					<view class="flex">
						<image src="/static/new/up1.png" mode="widthFix" style="width: 50px;height: 50px;"></image>
						<view class="margin-left-10">
							<view>
								운용 자금
							</view>
							<view class="bold">
								₩{{userinfo.money}}
							</view>
						</view>
					</view>
					<view class="flex">
						<image src="/static/new/home1.png" mode="widthFix" style="width: 50px;height: 50px;"></image>
						<view class="margin-left-10">
							<view>
								AI 계정
							</view>
							<view class="bold">
								₩{{userinfo.aiMoney4}}
							</view>
						</view>
					</view>
				</view>
			</view>



			<view class="font-size-18 color-black  margin-top-20">
				종목
			</view>

			<view class="padding-20 flex margin-top-10 bg-white radius20" v-for="(item,index) in list"
				@click="$u.route('/pages/marketQuotations/productDetails',{code:item.code});">
				<template v-if="!item.logo || item.logo==''">
					<view
						style="width: 30px;height: 30px;background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;;border-radius:10px;">
						{{item.ko_name.slice(0,1)}}
					</view>
				</template>
				<template v-else>
					<image mode="aspectFit" :src="item.logo" style="width: 40px;height: 40px;border-radius: 10px">
					</image>
				</template>

				<!-- <u--image :src="item.logo" shape="circle" width="30px" height="30px"></u--image> -->
				<view style="border-radius: 3px;padding: 3px 8px;" class="margin-left-10">
					<view class="font-size-15">
						{{item.ko_name}}
					</view>
					<view style="color: #999999;">
						{{item.code}}
					</view>
				</view>
				<view style="margin-left:auto;">
					<view class="text-center" style="gap: 20px">
						<view :class="item.returns>0?'red bold':'green bold'">
							<image :src="item.returns>0?'/static/new/up.png':'/static/new/down.png'" mode="widthFix"
								style="width: 15px;"></image>
							{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%

						</view>
						<view style="border-radius: 3px;padding: 3px 8px;color: #000;font-size: 18px;">
							{{numberToCurrency(item.close*1)}}
						</view>
					</view>

				</view>
			</view>

		</view>

		<!-- 每次由登入跳转进入时，显示该弹层，关闭后，不再显示。 -->

		<template v-if="isShow && ipoSuccessItem">
			<view class="mask" @click="handleClose">
				<view style="position: fixed;top: 26vh;right: 12vw;z-index: 1000;" @click="handleClose">
					<image src="/static/close.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;justify-content: center;border-radius: 20px;">
						<view
							style="width: 90%;background-color: #fbfdff;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 90px;">
							<view style="font-size: 20px;padding: 10px 0 2px 0;color:#4451da;">
								{{ipoSuccessItem.goods.name}}
							</view>
							<view style="font-size: 11px;color:#999;padding:2px 0 10px 0;">
								{{ipoSuccessItem.goods.number_code}}
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding: 10px 60rpx;">
								<view>배정 수량</view>
								<view style="color:#4451da;">{{numberToCurrency(ipoSuccessItem.success)}}</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;padding: 10px 60rpx;">
								<view>납부금</view>
								<view style="color:#4451da;">{{numberToCurrency(ipoSuccessItem.total)}}</view>
							</view>

							<view
								style="padding: 10px 0;line-height: 1;background-color: #4451da;border-radius: 100px;color:#FFF;margin:20px 30px;"
								@click="handleIPO(ipoSuccessItem.type)">지금 구매</view>
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import {
		TYPES
	} from '../../consts/index.js'
	export default {
		data() {
			return {
				isShow: true, // 是否显示ad层,
				ipoSuccessItem: null, // IPO中签弹层
				userinfo: [],
				show_money: true,
				page: 1,
				list: [],
				gp_index: 0,
				keyword: "",
				business: "",
				peishou_order: ""
			}
		},

		// computed: {
		// 	adStock() {
		// 		if (this.isShow && this.list.length > 0) {
		// 			return this.list[0];
		// 		}
		// 	}
		// },
		onLoad() {
			this.ipoSuccess();
		},
		async onShow() {
			this.page = 1;
			this.is_token()
			this.good_list()
			this.gaint_info()
			// this.free()
			this.startTimer()
		},

		onReachBottom() {
			this.page = this.page + 1;
			this.good_list()
		},
		onHide() {
			clearInterval(this.timerId);
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		methods: {
			// AD层关闭
			handleClose() {
				this.isShow = false;
			},
			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get('api/goods-shengou/tanchuang', {})
				if (result.data.data[0]) {
					this.isShow = true;
					
					this.ipoSuccessItem = result.data.data[0];
				}
				console.log('抢筹', result.data.data[0]);
			},
			handleIPO(type) {
				if(type==1){
					uni.navigateTo({
						url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
					});
				}else{
					uni.navigateTo({
						url: '/pages/index/components/newShares/ration/ration'
					});
				}
				
			},
			// tiaozhuan(type) {
			// 	if (type == "scramble") {
			// 		uni.navigateTo({
			// 			url: '/pages/index/components/newShares/ration/ration'
			// 		})
			// 	} else {
			// 		uni.navigateTo({
			// 			url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
			// 		})
			// 	}
			// },
			async placement() {
				let list = await this.$http.get('api/goodsscramble/userApplyLog1', {})
				this.peishou_order = list.data.data
				this.isShow = true;
				console.log(777, list.data.data)
				// console.log(list.data.data[0], '抢筹');
			},


			qiehuan(index) {
				this.gp_index = index
				this.good_list()
			},
			link(type, url) {
				if (type == 1) {
					uni.switchTab({
						url: url
					})
				} else if (type == 3) {
					uni.reLaunch({
						url: url
					})
				} else {
					uni.navigateTo({
						url: url
					})
				}
			},
			// 银转证
			silver(money, bank_card_info, idno) {
				// if (bank_card_info && idno !== null) {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/components/customer/customer'
				});
				// } else if (bank_card_info == null) {
				// 	uni.$u.toast('은행 카드에 묶여 있지 않음');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/my/components/bankCard/renewal'
				// 		});
				// 	}, 2000)
				// } else if (idno == null) {
				// 	uni.$u.toast('실명인증 불가');
				// 	setTimeout(() => {
				// 		uni.navigateTo({
				// 			//保留当前页面，跳转到应用内的某个页面
				// 			url: '/pages/index/components/openAccount/openAccount'
				// 		});
				// 	}, 2000)
				// }

			},
			/* 数字金额逢三加， 比如 123,464.23 */
			numberToCurrency(value) {
				if (!value) return '0'
				// 将数值截取，保留两位小数
				value = value.toFixed(2)
				// 获取整数部分
				const intPart = Math.trunc(value)
				// 整数部分处理，增加,
				const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')

				return intPartFormat
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
					this.free()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let list = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.list = list.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = list.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '먼저 로그인을 해주세요',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {

				}
			},
			async free() {
				let list = await this.$http.get('api/user/collect_list', {})
				this.business = list.data.data.list
			},


		},
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		min-height: 100vh;
		background-color: #F3F4F8;
	}

	.home {
		height: 600rpx;
		margin-left: -10px;
	}

	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		background-image: url(/static/bg_ad.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 30vh;
		width: 80vw;
	}
</style>