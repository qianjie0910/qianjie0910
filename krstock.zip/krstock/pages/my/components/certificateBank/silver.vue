<!-- 银转证 -->
<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<view class="account">
				<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<view class="college-text">입금 신청</view>
				<view class=""></view>
			</view>
			<!-- <view class="progress"> {{userInformation.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view> -->
			<!-- <view class="vacancies">현재 사용 가능한 잔액</view> -->
		</view>
		<!-- 
		<u-tabs lineColor="#f85252" :list="list1" @click="strike"
			:activeStyle="{color: '#fff',background:'#f85252',padding:'10px 20px',}"></u-tabs> -->

	<!-- 	<view class="inv-h-w">
			<block v-for="(item,index) in items" :key="index">
				<view :class="['inv-h',Inv== index?'inv-h-se':'']" @click="Inv=index">{{item}}</view>
			</block>

		</view>

		<view v-show="Inv == 0">
			<view class="collections">
				<view class="call">
					<view class="beneficiaryName">수취인 이름</view>
					<view class="">{{BankUser}}</view>
					<view class="duplicate" @click="copy(BankUser)">복사</view> -->
					<!-- <view class="duplicate" @tap="customer()">客服</view> -->
				<!-- </view>
			</view>
			<view class="xian"></view>
			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">수취은행</view>
					<view class="">{{BankName}}</view>
					<view class="duplicate" @click="copy(BankName)">복사</view>
				</view>
			</view>
			<view class="xian"></view>

			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">미수금</view>
					<view class="">{{BankNo}}</view>
					<view class="duplicate" @click="copy(BankNo)">복사</view>
				</view>
			</view>
			<view class="xian"></view> -->
			<!-- 密码 -->
			<!-- <view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">输入密码</view>
					<view class="beneficiaryinput">
						<u-input placeholder="输入密码,可查看银行信息" type="password" v-model="value3"></u-input>
					</view>
					<view class="duplicate" style="color: red; font-weight: 900;" @click="testVerify()">验证</view>
				</view>
			</view> -->
		<!-- </view>
		<view v-show="Inv == 1">
			<view class="collections">
				<view class="call">
					<view class="beneficiaryName">수취인 이름</view>
					<view class="">{{BankUser_2}}</view>
					<view class="duplicate" @click="copy(BankUser_2)">복사</view> -->
					<!-- <view class="duplicate" @tap="customer()">客服</view> -->
				<!-- </view>
			</view>
			<view class="xian"></view>
			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">수취은행</view>
					<view class="">{{BankName_2}}</view>
					<view class="duplicate" @click="copy(BankName_2)">복사</view>
				</view>
			</view>
			<view class="xian"></view>

			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">미수금</view>
					<view class="">{{BankNO_2}}</view>
					<view class="duplicate" @click="copy(BankNO_2)">복사</view>
				</view>
			</view>
			<view class="xian"></view> -->
			<!-- 密码 -->
			<!-- <view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">输入密码</view>
					<view class="beneficiaryinput">
						<u-input placeholder="输入密码,可查看银行信息" type="password" v-model="value4"></u-input>
					</view>
					<view class="duplicate" style="color: red; font-weight: 900;" @click="testVerify_2()">验证</view>
				</view>
			</view> -->
		<!-- </view> -->



		<!-- <view class="xian"></view> -->

		<!-- 查看 -->
		<!-- <view class="make-collections">
			<view class="call">
				<view class="beneficiaryName">입금내역</view>
				<view class=""></view>
				<view class="duplicate" @tap="capitalDetails()">내역확인</view>
			</view>
		</view>
		<view class="xian"></view> -->
		<!-- 充值金额 -->

		<!-- <view class="recharge">
			<view class="title">입금금액</view>
			<view class="minimum">최소 입금금액<text>10,000원</text> </view>
			<input placeholder="입금금액을 입력해주세요" type="number" v-model="value1"></input>
			<view class="select">
				<view class="" :style="{ 'background':shadow,'color':character}" @click="quantity('50000')">50000
				</view>
				<view class="" :style="{ 'background':shadow1, 'color':character1}" @click="quantity('100000')">100000
				</view>
				<view class="" :style="{ 'background':shadow2, 'color':character2}" @click="quantity('300000')">300000
				</view>
				<view class="" :style="{ 'background':shadow3, 'color':character3}" @click="quantity('500000')">500000
				</view>

			</view>


		</view>

		<view class="uploadVoucher">인증서 업로드</view>
		<view class="success"> -->
			<!-- <image src="../../../../static/my/yinzhuanzheng.jpg" mode=""></image> -->
			<!-- <view style="flex: 100%;">
				<u-upload :fileList="fileList6" @afterRead="afterRead" @delete="deletePic" name="6" multiple
					:maxCount="1" width="" height="200"> -->
					<!-- <image src="https://cdn.uviewui.com/uview/demo/upload/positive.png" mode="widthFix"
						style="width: 250px;height: 150px;"></image> -->
				<!-- 	<view class="" style="text-align: center;margin: 30rpx 0; font-size: 24rpx;color: #95918a;">
						인증서를 업로드하시려면 여기를 클릭하세요. 
					</view> -->
					<!-- <image src="../../../../static/my/22.png" mode="" style="width: 50%;height: 50%;margin-left: 25%;"></image> -->
				<!-- </u-upload>
			</view>
		</view> -->
		<!-- 		<view class="cash-withdrawal">
			<view class="withdrawal">通道密码</view>
			<view class="money">
				<input placeholder="请输入" type="password">
			</view>
		</view> -->
		<view style="margin-top: 30px; font-size: 24px;margin-left: 10px;">입금 계좌 번호를 신청하시려면 고객센터로 문의하세요.</view>


		<view class="purchase" @click="silver()">
			고객 센터 문의
		</view>



	<!-- 	<view class="point-out">
			<view class="">친절한 팁</view>
			<view>一、입금시간 : 평일 09:00~18:00, 공휴일 휴무。</view>
			<view>
우리를 선택해 주셔서 감사합니다. 귀하의 자금의 안전을 보장하기 위해,
이전하려는 계좌가 플랫폼에 실시간으로 표시되는 계좌인지 확인하시기 바랍니다.
환승할 때마다 직원에게 확인하시기 바랍니다.
본 플랫폼에 실시간으로 표시되는 계좌가 아닌 은행 계좌에서 자금을 입금하여 발생하는 모든 손실에 대한 책임은 귀하에게 있습니다.			</view>
		</view>
		<view style="height: 30rpx;"></view> -->



	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	export default {
		data() {
			return {
				customerService: '보려면 고객 서비스에 문의하십시오.',
				value1: '',
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				character: '',
				character1: '',
				character2: '',
				character3: '',
				fileList6: [],
				userInformation: "",
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				BankUser: '',
				BankName: '',
				BankNo: '',
				BankUser_2: '',
				BankName_2: '',
				BankNO_2: '',
				current: 0,
				list1: [{
						name: '채널 1'
					},
					{
						name: '채널 2'
					},
				],
				Inv: 0,
				items: ['채널 1', '채널 2']
			};
		},
		methods: {

			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			silver() {
				uni.navigateTo({
					url:"/pages/index/components/customer/customer"
				});
				},

			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
				});
			},



			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast('먼저 비밀번호를 확인해 주세요');
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: '성공적으로 복사되었습니다',
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			quantity(value1) {
				if (value1 == 50000) {
					this.value1 = 50000
					// this.shadow = "#ea4445";
					// this.character = "#fff";
				}
				// else if (value1 != 50000) {
				// 	this.shadow = "";
				// 	this.character = "";
				// }
				if (value1 == 100000) {
					this.value1 = 100000
					// this.shadow1 = "#ea4445";
					// this.character1 = "#fff";
				}
				// else if (value1 != 100000) {
				// 	this.shadow1 = "";
				// 	this.character1 = "";
				// }
				if (value1 == 300000) {
					this.value1 = 300000
					// this.shadow2 = "#ea4445";
					// this.character2 = "#fff";
				}
				// else if (value1 != 300000) {
				// 	this.shadow2 = "";
				// 	this.character2 = "";
				// }
				if (value1 == 500000) {
					this.value1 = 500000
					// this.shadow3 = "#ea4445";
					// this.character3 = "#fff";
				}
				// else if (value1 != 500000) {
				// 	this.shadow3 = "";
				// 	this.character3 = "";
				// }
				// if (value1 != 50000 || value1 != 100000 || value1 != 300000 || value1 != 500000) {
				// 	// this.shadow3 = "";
				// 	// this.character3 = "";
				// }
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				uni.showLoading({
					title: "충전 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/recharge', {
					money: this.value1,
					type: 5,
					image: this.is_url,
					desc: this.value2,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.value2 = '';
					this.value1 = '';
					this.is_url = '';
					this.fileList6 = [];
					this.title = '은행 카드',
						setTimeout(() => {
							uni.switchTab({
								url: '/pages/my/my'
							});
							uni.hideLoading();
						}, 2000)
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
					// if (list.data.message === '充值金额错误') {
					// 	uni.$u.toast('请填写充值金额金额');
					// } else if (list.data.message === '您还未实名') {
					// 	uni.$u.toast('请先实名认证');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/index/components/openAccount/openAccount'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)

					// } else if (list.data.message === '请先添加银行卡信息') {
					// 	uni.$u.toast('请先添加银行卡');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/bankCard/renewal'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)
					// }
					// uni.$u.toast(list.data.message);
					// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

					// }
				}
			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {
				
				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
				})
				this.BankUser = list.data.data[13].value
				this.BankName = list.data.data[12].value
				this.BankNo = list.data.data[9].value
				
				this.BankUser_2 = list.data.data[22].value
				this.BankName_2 = list.data.data[23].value
				this.BankNO_2 = list.data.data[24].value
				uni.hideLoading();
			

			},
		},

		onLoad(option) {
			this.gaint_info()
			this.testVerify()
		},
		
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		background-color: #4f61f5;


		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #fff;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #f47b78;
			font-size: 26rpx;
		}
	}

	.xian {
		width: 100%;
		height: 2rpx;
		background: #e9e9e9;
	}

	/deep/.u-tabs {
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		background: #fff;
	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-around;
	}

	.collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				color: #000;
				font-weight: 700;

			}
		}
	}

	.make-collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		// background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				color: #000;
				font-weight: 700;

			}
		}
	}

	//充值金额
	.recharge {
		margin: 30rpx;
		font-size: 28rpx;

		.title {
			color: #333;
		}

		.minimum {
			color: #999;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		input {
			background: #f5f5f5;
			border-radius: 10rpx;
			color: #000;
			padding: 30rpx 20rpx;
			font-size: 28rpx;
		}

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #f5f5f5;
				color: #999;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			.shadow {
				background-color: #4f61f5;
			}
		}
	}


	.cash-withdrawal {

		padding: 30rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

		}
	}

	.purchase {
		background-color: #4f61f5;
		margin: 80rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.uploadVoucher {
		margin: 30rpx;
		color: #333;
		font-size: 28rpx;
	}

	.success {
		// width: 100%;
		height: 420rpx;
		margin: 30rpx;
		display: flex;
		
		image {
			width: 100%;
			height: 100%;
		}

		/deep/.u-upload__wrap {
			width: 100% !important;
			height: 720rpx !important;
			flex-wrap: nowrap;
			flex: none;

			view {
				width: 100%;
			}
		}

		/deep/.u-upload__wrap__preview__image {
			height: 420rpx !important;
		}

		/deep/.u-upload__wrap__preview__image {
			width: 100% !important;
		}

		/deep/ .u-upload__deletable {
			width: 14px !important;
		}

		/deep/ .u-upload__success {
			width: 60rpx !important;
			border-right-color: transparent;
		}
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

	}

	.beneficiaryinput {
		width: 65%;
		word-break: break-word; //文本超出 自动换行

		input {
			word-break: break-word; //文本超出 自动换行
			font-size: 26rpx;
			overflow: hidden;
			white-space: nowrap;
			text-overflow: ellipsis;
			text-align: left;
		}
	}

	.inv-h-w {
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		padding: 30rpx 100rpx;

	}

	.inv-h {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #666666;
		position: relative;

	}

	.inv-h-se {
		font-size: 28rpx;
		color: #fff;
		background: #f85252;
		border-radius: 40rpx;
		padding: 10rpx 0;
	}

	.inv-h-se:after {
		content: '';
		position: absolute;
		bottom: -2rpx;
		top: auto;
		left: 42%;
		height: 6rpx;
		width: 44rpx;
		background-color: #4DB046;
		display: none;
	}
</style>