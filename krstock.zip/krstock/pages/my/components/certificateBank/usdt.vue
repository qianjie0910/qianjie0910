<!-- 银转证 -->
<template	>
	<uni-view data-v-ac2ac4ac="" class="page"><uni-view data-v-3dcc744d="" data-v-ac2ac4ac="" class="top-pad"><uni-view data-v-3dcc744d="" class="header flex flex-b"><img data-v-3dcc744d="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAUpJREFUaEPt2NEJgzAQBuAGF7EbCDqATlK6STtJ3aT2PSeO4CBKSkD7IMRqLnenEJ9N/L+7BA7V5eSPOnn+SwRIdzB2IHYAWYF4hHwKWBRFaYy5GWM+bdvWPnvMa9g7MIV//wIo9dRaP3wRrIBl+Cl0AwDV4QGO8DZ3DQD3QwNWwvcAcPUNb9eRHyHK8OQA6vCkAI7wZACu8CQAzvDBAdzhgwIkwgcDSIUPApAMjwZIh0cD8jy3U2W5GAXQ48Ge0QI1SrgA4zhWXdf1e4L4vosCZFmWJkliu5Auu8CFQAFs6OkevKQQaIA0IghAEhEMIIUICpBABAdwI0gAnAgyABeCFMCBIAdQI1gAfxDH/7E1z0mOseMcvxZdCKVUpbVuRKZR34/OR2oYhh47drPdAQx2bW0EUFV2676xA1srRfVe7ABVZbfue/oOfAHhOCpAFt9NxgAAAABJRU5ErkJggg==" class="header-left"><uni-view data-v-3dcc744d="" class="header-center flex-1" _msttexthash="11534094" _msthash="0">货币兑换</uni-view><uni-view data-v-3dcc744d="" class="header-right"></uni-view><!----></uni-view></uni-view><uni-view data-v-ac2ac4ac="" class="list"><uni-view data-v-ac2ac4ac="" class="item "><uni-view data-v-ac2ac4ac="" class="flex-1 t" _msttexthash="11534094" _msthash="1">货币兑换</uni-view><uni-view data-v-ac2ac4ac="" class="border"><uni-view data-v-ac2ac4ac="" class="flex flex-b"><uni-view data-v-ac2ac4ac="" class="flex flex-b from"><uni-view data-v-ac2ac4ac="" class="icon kor"></uni-view><uni-view data-v-ac2ac4ac="" class="flex-2 t-c" _msttexthash="5702411" _msthash="2">韩元</uni-view></uni-view><uni-view data-v-ac2ac4ac="" class="flex flex-b to"><uni-view data-v-ac2ac4ac="" class="icon usa"></uni-view><uni-view data-v-ac2ac4ac="" class="flex-2 t-c" _msttexthash="5135026" _msthash="3">美元</uni-view></uni-view></uni-view><uni-view data-v-ac2ac4ac="" class="icon jt1"></uni-view></uni-view><uni-view data-v-ac2ac4ac="" class="txt" _msttexthash="37713962" _msthash="4">汇率：1韩元=0.000769美元</uni-view></uni-view><uni-view data-v-ac2ac4ac="" class="item"><uni-view data-v-ac2ac4ac="" class="flex flex-b"><uni-view data-v-ac2ac4ac="" class="flex-1 t" _msttexthash="13986778" _msthash="5">兑换金额</uni-view><uni-view data-v-ac2ac4ac="" class="t1" _msttexthash="3377647" _msthash="6">都</uni-view></uni-view><uni-view data-v-ac2ac4ac="" class="ipt" _msthidden="1"><uni-input data-v-ac2ac4ac="" _msthidden="1"><div class="uni-input-wrapper" _msthidden="1"><div class="uni-input-placeholder input-placeholder" data-v-ac2ac4ac="" style="color: rgb(153, 153, 153); display: none;" _msttexthash="14958216" _msthash="7" _mstvisible="0">输入金额</div><input maxlength="140" step="0.000000000000000001" enterkeyhint="done" autocomplete="off" type="number" class="uni-input-input"><!----></div></uni-input></uni-view><uni-view data-v-ac2ac4ac="" class="txt" _msttexthash="23718721" _msthash="8">可用资金： 38550278.247 KRW</uni-view></uni-view></uni-view><uni-view data-v-ac2ac4ac="" class="pd30"><uni-view data-v-ac2ac4ac="" class="b-btn" _msttexthash="4418960" _msthash="9">提交</uni-view></uni-view></uni-view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	export default {
		data() {
			return {
				customerService: this.$t('index.qlxkfck'),
				value1: '',
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				character: '',
				character1: '',
				character2: '',
				character3: '',
				fileList6: [],
				userInformation: "",
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				BankUser: '',
				BankName: '',
				BankNo: '',
				BankUser_2: '',
				BankName_2: '',
				BankNO_2: '',
				current: 0,
				list1: [{
						name: this.$t('index.pd1')
					},
					{
						name: this.$t('index.pd2')
					},
				],
				Inv: 0,
				items: [this.$t('index.pd1'), this.$t('index.pd2')]
			};
		},
		methods: {

			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},

			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
				});
			},



			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast(this.$t('index.qxjcmm'));
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: this.$t('index.fzcg'),
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			quantity(value1) {
				if (value1 == 50000) {
					this.value1 = 50000
					// this.shadow = "#ea4445";
					// this.character = "#fff";
				}
				// else if (value1 != 50000) {
				// 	this.shadow = "";
				// 	this.character = "";
				// }
				if (value1 == 100000) {
					this.value1 = 100000
					// this.shadow1 = "#ea4445";
					// this.character1 = "#fff";
				}
				// else if (value1 != 100000) {
				// 	this.shadow1 = "";
				// 	this.character1 = "";
				// }
				if (value1 == 300000) {
					this.value1 = 300000
					// this.shadow2 = "#ea4445";
					// this.character2 = "#fff";
				}
				// else if (value1 != 300000) {
				// 	this.shadow2 = "";
				// 	this.character2 = "";
				// }
				if (value1 == 500000) {
					this.value1 = 500000
					// this.shadow3 = "#ea4445";
					// this.character3 = "#fff";
				}
				// else if (value1 != 500000) {
				// 	this.shadow3 = "";
				// 	this.character3 = "";
				// }
				// if (value1 != 50000 || value1 != 100000 || value1 != 300000 || value1 != 500000) {
				// 	// this.shadow3 = "";
				// 	// this.character3 = "";
				// }
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				uni.showLoading({
					title: this.$t('index.sfqsh'),
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/recharge', {
					money: this.value1,
					type: 5,
					image: this.is_url,
					desc: this.value2,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.value2 = '';
					this.value1 = '';
					this.is_url = '';
					this.fileList6 = [];
					this.title = this.$t('index.yhk'),
						setTimeout(() => {
							uni.switchTab({
								url: '/pages/my/my'
							});
							uni.hideLoading();
						}, 2000)
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
					// if (list.data.message === '充值金额错误') {
					// 	uni.$u.toast('请填写充值金额金额');
					// } else if (list.data.message === '您还未实名') {
					// 	uni.$u.toast('请先实名认证');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/index/components/openAccount/openAccount'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)

					// } else if (list.data.message === '请先添加银行卡信息') {
					// 	uni.$u.toast('请先添加银行卡');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/bankCard/renewal'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)
					// }
					// uni.$u.toast(list.data.message);
					// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

					// }
				}
			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {
				
				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
				})
				this.BankUser = list.data.data[13].value
				this.BankName = list.data.data[12].value
				this.BankNo = list.data.data[9].value
				
				this.BankUser_2 = list.data.data[22].value
				this.BankName_2 = list.data.data[23].value
				this.BankNO_2 = list.data.data[24].value
				uni.hideLoading();
			

			},
		},

		onLoad(option) {
			this.gaint_info()
			this.testVerify()
		},
		
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 280rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);


		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #fff;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #f47b78;
			font-size: 26rpx;
		}
	}

	.xian {
		width: 100%;
		height: 2rpx;
		background: #e9e9e9;
	}

	/deep/.u-tabs {
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		background: #fff;
	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-around;
	}

	.collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				color: #000;
				font-weight: 700;

			}
		}
	}

	.make-collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		// background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				color: #000;
				font-weight: 700;

			}
		}
	}

	//充值金额
	.recharge {
		margin: 30rpx;
		font-size: 28rpx;

		.title {
			color: #333;
		}

		.minimum {
			color: #999;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		input {
			background: #f5f5f5;
			border-radius: 10rpx;
			color: #000;
			padding: 30rpx 20rpx;
			font-size: 28rpx;
		}

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #f5f5f5;
				color: #999;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			.shadow {
				background-image: linear-gradient(to right, #1a73e8, #014b8d);
			}
		}
	}


	.cash-withdrawal {

		padding: 30rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

		}
	}

	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.uploadVoucher {
		margin: 30rpx;
		color: #333;
		font-size: 28rpx;
	}

	.success {
		// width: 100%;
		height: 420rpx;
		margin: 30rpx;
		display: flex;
		
		image {
			width: 100%;
			height: 100%;
		}

		/deep/.u-upload__wrap {
			width: 100% !important;
			height: 720rpx !important;
			flex-wrap: nowrap;
			flex: none;

			view {
				width: 100%;
			}
		}

		/deep/.u-upload__wrap__preview__image {
			height: 420rpx !important;
		}

		/deep/.u-upload__wrap__preview__image {
			width: 100% !important;
		}

		/deep/ .u-upload__deletable {
			width: 14px !important;
		}

		/deep/ .u-upload__success {
			width: 60rpx !important;
			border-right-color: transparent;
		}
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

	}

	.beneficiaryinput {
		width: 65%;
		word-break: break-word; //文本超出 自动换行

		input {
			word-break: break-word; //文本超出 自动换行
			font-size: 26rpx;
			overflow: hidden;
			white-space: nowrap;
			text-overflow: ellipsis;
			text-align: left;
		}
	}

	.inv-h-w {
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		padding: 30rpx 100rpx;

	}

	.inv-h {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #666666;
		position: relative;

	}

	.inv-h-se {
		font-size: 28rpx;
		color: #fff;
		background: #f85252;
		border-radius: 40rpx;
		padding: 10rpx 0;
	}

	.inv-h-se:after {
		content: '';
		position: absolute;
		bottom: -2rpx;
		top: auto;
		left: 42%;
		height: 6rpx;
		width: 44rpx;
		background-color: #4DB046;
		display: none;
	}
</style>