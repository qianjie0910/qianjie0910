<template>
	<view class="page">
		<view class="top-pad">
			<view class="header flex flex-b">
				<img
					src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAUpJREFUaEPt2NEJgzAQBuAGF7EbCDqATlK6STtJ3aT2PSeO4CBKSkD7IMRqLnenEJ9N/L+7BA7V5eSPOnn+SwRIdzB2IHYAWYF4hHwKWBRFaYy5GWM+bdvWPnvMa9g7MIV//wIo9dRaP3wRrIBl+Cl0AwDV4QGO8DZ3DQD3QwNWwvcAcPUNb9eRHyHK8OQA6vCkAI7wZACu8CQAzvDBAdzhgwIkwgcDSIUPApAMjwZIh0cD8jy3U2W5GAXQ48Ge0QI1SrgA4zhWXdf1e4L4vosCZFmWJkliu5Auu8CFQAFs6OkevKQQaIA0IghAEhEMIIUICpBABAdwI0gAnAgyABeCFMCBIAdQI1gAfxDH/7E1z0mOseMcvxZdCKVUpbVuRKZR34/OR2oYhh47drPdAQx2bW0EUFV2676xA1srRfVe7ABVZbfue/oOfAHhOCpAFt9NxgAAAABJRU5ErkJggg=="
					class="header-left" @click="$u.route({type:'navigateBack'});">
				<view class="header-center flex-1">{{$t('index.zhgl')}}</view>
				<view class="header-right"></view><!---->
			</view>
		</view>
		<view class="card">
			<view class="card-top">{{cardManagement.realname}}</view>
			<view class="flex flex-b">
				<view class="card-num">{{cardManagement.card_sn.substring(0,3) + new Array(cardManagement.card_sn.length).join('*')}}</view>
			</view>
		</view>
		<view class="pad">
			<view class="b-btn" @tap='renewal()'>{{$t('index.zctkzh')}}</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				cardManagement: '',
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			renewal() {
				uni.navigateTo({
					url: '/pages/my/components/bankCard/renewal'
				});
			},
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.cardManagement = list.data.data.bank_card_info
			},
		},
		onLoad(option) {
			this.gaint_info()
		},
	}
</script>

<style lang="scss">
	uni-view, uni-text {
	    box-sizing: border-box;
	}
	.page {
	    background: #fff;
	    min-height: 100vh;
	}
	.top-pad {
	    padding-top: 50px;
	}
	.header {
	    height: 50px;
	    background: #fff;
	    padding: 0 15px;
	    width: 100vw;
	    position: fixed;
	    top: 0;
	    left: 0;
	    z-index: 999;
		.header-center {
		    font-size: 18px;
		    font-weight: 700;
		    color: #333;
		    text-align: center;
		}
		.header-right {
		    width: 9px;
		    height: 16px;
		}
		.header-left {
		    width: 24px;
		    height: 24px;
		}
	}
	.card {
	    margin: 15px 15px 0 15px;
	    padding: 15px;
	    background: -webkit-linear-gradient(315deg,#00367a,#018ba8);
	    background: linear-gradient(135deg,#00367a,#018ba8);
	    border-radius: 6px;
		.card-top {
		    color: #fff;
		}
		.card-num {
		    font-size: 18px;
		    font-weight: 700;
		    color: #fff;
		    margin-top: 15px;
		}
	}
	.pad {
	    padding: 40px 15px;
	}
	.b-btn {
	    width: 100%;
	    height: 44px;
	    line-height: 44px;
	    background: #ffcd24;
	    border-radius: 22px;
	    text-align: center;
	    font-size: 16px;
	    font-weight: 500;
	    color: #333;
	    margin: 15px 0;
	}
</style>