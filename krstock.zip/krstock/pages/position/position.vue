<template>
	<view class="page">
		<view class="home"
			style="padding: 30px 5px 0px 5px;background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));height: 300px;">
			<view class="flex flex-b">

				<view class="flex-1 flex margin-left-10" style="color: #000;font-size: 38rpx;">
					투자내역
				</view>
				<view class="flex-1 flex justify-end margin-right-10"
					@click="$u.route({url:'/pages/searchFor/searchFor'});">
					<image src="../../static/sousuo.png" mode="widthFix" style="width: 20px;"></image>
				</view>

			</view>


			<view class="radius20 padding-20 color-white"
				style="background: linear-gradient(to right, #2E67F6, #6492FF);margin: 20px 10px;">
				<view class="flex flex-b">
					<view class="font-size-18">총자산</view>
					<view class="flex">
						<view class="radius10  font-size-14" style="background-color: #FFC156;padding: 5px 10px;"
							@click="$u.route({url:'/pages/index/components/customer/customer'});">충전</view>
						<view class="radius10 font-size-14 margin-left-10 color-black"
							style="background-color: #fff;padding: 5px 10px;"
							@click="$u.route({url:'/pages/my/components/certificateBank/prove'});">출금신청</view>
					</view>
				</view>
				<view class="font-size-25 margin-top-10 bold">
					₩{{userInformation.totalZichan}}
				</view>
				<view class="flex flex-b margin-top-20">
					<view class="flex">
						<image src="/static/new/up1.png" mode="widthFix" style="width: 50px;height: 50px;"></image>
						<view class="margin-left-10">
							<view>
								운용 자금
							</view>
							<view class="bold">
								₩{{userInformation.money}}
							</view>
						</view>
					</view>
					<view class="flex">
						<image src="/static/new/home1.png" mode="widthFix" style="width: 50px;height: 50px;"></image>
						<view class="margin-left-10">
							<view>
								AI 계정
							</view>
							<view class="bold">
								₩{{userInformation.aiMoney}}
							</view>
						</view>
					</view>
				</view>
			</view>

			<view class="flex flex-b" style="margin: 15px 20px;">
				<view class="bold font-size-16">
					투자성과
				</view>
				<view class="flex gap5" @click="shuaxin">
					<u-icon name="/static/shuaxin.png" style="margin-right: 5px;"></u-icon>
					<view style="color: #2E67F6;">새로고침</view>

				</view>
			</view>
			<view style="border-radius: 10px;background: #fff;margin: 10px;padding:20px;">
				<view class="flex flex-b ">
					<view class="text-center width100" :class="Inv==0?'with-bottom-line':''" @click="qiehuan(0)">
						종목 보유 현황
					</view>
					<view class="text-center width100 hui1" :class="Inv==1?'with-bottom-line':''" @click="qiehuan(1)">
						매매 내역
					</view>
				</view>
				<view style="width: 100%;background-color: #E8EAF3;height: 1px;margin-top: 10px;"></view>

				<view class="flex flex-b margin-top-15 gap10">
					<view class="text-center flex-1 padding-10 radius10"
						style="background-color: #F6F8FC;color: #333333;">
						<view class="text-center font-size-12">
							매입금액
						</view>
						<view class="bold margin-top-10">
							{{$util.formatNumber(userInformation.frozen)}}
						</view>
					</view>
					<view class="text-center flex-1 padding-10 radius10"
						style="background-color: #F6F8FC;color: #333333;">
						<view class="text-center font-size-12">
							평가수익금
						</view>
						<view class="bold margin-top-10">
							{{$util.formatNumber(userInformation.holdYingli)}}
						</view>
					</view>

				</view>
				<view class="flex flex-b margin-top-5 gap10">
					<view class="text-center flex-1 padding-10 radius10"
						style="background-color: #F6F8FC;color: #333333;">
						<view class="text-center font-size-12">
							평가금액
						</view>
						<view class="bold margin-top-10">
							{{$util.formatNumber(userInformation.guzhi)}}
						</view>
					</view>
					<view class="text-center flex-1 padding-10 radius10"
						style="background-color: #F6F8FC;color: #333333;">
						<view class="text-center font-size-12">
							평가수익률
						</view>
						<view class="bold margin-top-10">
							{{userInformation.huibao}}%
						</view>
					</view>

				</view>
				<view class="flex flex-b margin-top-5 gap10" style="align-items: stretch;">
					<view class="text-center flex-1 padding-10 radius10"
						style="background-color: #F6F8FC;color: #333333;">
						<view class="text-center font-size-12">
							총자산
						</view>
						<view class="bold margin-top-10">
							{{$util.formatNumber(userInformation.totalZichan)}}
						</view>
					</view>
					<view class="text-center flex-1 padding-10 radius10"
						style="background-color: #F6F8FC;color: #333333;">
						<view class="text-center font-size-12">
							실현손익
						</view>
						<view class="bold margin-top-10">
							{{$util.formatNumber(userInformation.totalYingli)}}
						</view>
					</view>

				</view>
				<view style="background-color: #F6F8FC;">
					<view class="flex flex-b margin-top-20 gap5  padding-10"
						style="align-items:stretch;background-color: #c2dbf4;border-radius: 10px 10px 0 0;">
						<view class="flex-1 text-center  flex justify-center" style="color: #2E67F6;">
							<view class="bold">
								<view class="font-size-12">
									종목명
								</view>
								<view class="margin-top-10 font-size-12">
									종목코드
								</view>
							</view>
						</view>
						<view class="flex-1 text-center  flex justify-center" style="color: #2E67F6;">
							<view class="bold">
								<view class="font-size-12">
									평가수익금
								</view>
								<view class="margin-top-10 font-size-12">
									평가수익률
								</view>
							</view>
						</view>
						<view class="flex-1 text-center  flex justify-center" style="color: #2E67F6;">
							<view class="bold">
								<view class="font-size-12">
									보유수량
								</view>
								<view class="margin-top-10 font-size-12">
									평가금액
								</view>
							</view>
						</view>
						<view class="flex-1 text-center  flex justify-center" style="color: #2E67F6;">
							<view class="bold">
								<view class="font-size-12">
									매수가
								</view>
								<view class="margin-top-10 font-size-12">
									현재가
								</view>
							</view>
						</view>

					</view>
					<view class="gap5" style="margin-bottom: 100px;background-color: #F6F8FC;">
						<view class="flex flex-b margin-top-5" v-for="(item,index) in storehouse" :key="index"
							@tap="sell(item)" style="border-bottom: 1px #DBDBDB solid;padding: 5px;margin: 5px;">
							<view class="padding-5" style="width: 24%">
								<view class="">
									{{item.goods_info.name}}
								</view>
								<view class="margin-top-10" style="color: #899C6C	;">
									{{item.goods_info.number_code}}
								</view>
							</view>
							<view class="padding-5 flex flex-b" style="width: 75%">
								<view :class="item.order_buy.float_yingkui>0?'red':'green'" class="flex-1"
									v-if="Inv==0">
									<view>
										{{$util.formatNumber(item.order_buy.yingkui)}}
									</view>
									<view class="margin-top-10 ">
										{{$util.formatNumber(item.order_buy.yingkui/item.order_buy.user_pay/item.order_buy.double*100,2)}}%
									</view>
								</view>
								<view :class="item.order_sell.yingkui>0?'red':'green'" class="flex-1" v-if="Inv==1">
									<view>
										{{$util.formatNumber(item.order_sell.yingkui)}}
									</view>
									<view class="margin-top-10 ">
										{{$util.formatNumber(item.order_sell.yingkui/item.order_buy.user_pay/item.order_buy.double*100,2)}}%
									</view>
								</view>

								<view class="flex-1">
									<view class="text-right">
										{{$util.formatNumber(item.order_buy.num)}}
									</view>
									<view class="margin-top-10 text-right" v-if="Inv==0">
										{{$util.formatNumber(item.goods_info.current_price*1*item.order_buy.num)}}
									</view>
									<view class="margin-top-10 text-right" v-if="Inv==1">
										{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}
									</view>
								</view>

								<view class="flex-1">
									<view class="text-right">
										{{$util.formatNumber(item.order_buy.price)}}
									</view>
									<view class="margin-top-10 text-right red" v-if="Inv==0">
										{{$util.formatNumber(item.goods_info.current_price)}}
									</view>
									<view class="margin-top-10 text-right red" v-if="Inv==1">
										{{$util.formatNumber(item.order_sell.price)}}
									</view>
								</view>
							</view>
						</view>

					</view>
				</view>

			</view>

			<u-picker :show="gp_show" :columns="gp_select" cancelText="취소" confirmText="확인" :closeOnClickOverlay="true"
				@close="gp_show=false" @cancel="gp_show=false" @confirm="gp_changes"></u-picker>




		</view>
		<view class="overlay" v-if="item_show" @click="item_show=false"></view>
		<view
			style="position: fixed;width: 100%;border-radius: 20px 20px 0 0;background-color: #fff;bottom: 0;z-index: 9999;padding-bottom: 30px;padding:20px;"
			v-if="item_show">
			<view class="padding-10 flex ">
				<view class="text-center justify-center width100 font-size-18 bold" >세부</view>

				<u-icon name="/static/market/close.png" size="24" @click="item_show=false"></u-icon>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">종목</view>
					<view class="flex-1" style="text-align: right;">{{info.goods_info.name}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매수 시간</view>
					<view class="flex-1" style="text-align: right;">{{info.order_buy.created_at}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;" v-if="Inv==1">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold" >매도시간</view>
					<view class="flex-1" style="text-align: right;">{{info.order_sell.created_at}}</view>
				</view>

			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">유동손익</view>
					<view class="flex-1" v-if="Inv==0" style="text-align: right;">
						{{$util.formatNumber(info.order_buy.float_yingkui)}}
					</view>
					<view class="flex-1" v-if="Inv==1" style="text-align: right;">
						{{$util.formatNumber(info.order_sell.float_yingkui)}}
					</view>
				</view>
				</view>
					<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">레버리지</view>
					<view class="flex-1" style="text-align: right;">X{{info.order_buy.double}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총손익</view>
					<view class="flex-1" v-if="Inv==0" style="text-align: right;">
						{{$util.formatNumber(info.order_buy.yingkui)}}
					</view>
					<view class="flex-1" v-if="Inv==1" style="text-align: right;">
						{{$util.formatNumber(info.order_sell.yingkui)}}
					</view>
				</view>
				</view>
					<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매입가</view>
					<view class="flex-1" style="text-align: right;">{{$util.formatNumber(info.order_buy.price)}}
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수량</view>
					<view class="flex-1" style="text-align: right;">{{$util.formatNumber(info.order_buy.num)}}
					</view>
				</view>
				</view>
					<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수수료</view>
					<view class="flex-1" style="text-align: right;">{{$util.formatNumber(info.order_buy.buy_fee)}}
						<span v-if="Inv==1">/{{$util.formatNumber(info.order_sell.sell_fee)}}</span>
					</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총 매입가</view>
					<view class="flex-1" style="text-align: right;">{{$util.formatNumber(info.order_buy.amount)}}
					</view>
				</view>
				</view>
					<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">종목코드</view>
					<view class="flex-1" style="text-align: right;">{{info.goods_info.number_code}}</view>
				</view>
			</view>

			<template v-if="Inv==0">
				<view style="display: flex;align-items: center;">
					<view style="background-color: #2E67F6;flex:40%;margin:10px 20px;text-align: center;border-radius: 30px;"
						class="padding-10 radius10 color-white font-size-16"
						@tap="productDetails(info.goods_info.number_code)">매수</view>
					<view style="background-color: #e82d28;flex:40%;margin:10px 20px;text-align: center;border-radius: 30px;"
						class="padding-10 radius10 color-white font-size-16" v-if="Inv==0" @tap="position(info.id)">매도
					</view>
				</view>
			</template>
		</view>
		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
			:showCancelButton='showCancelButton' :content='content' cancel-text="취소" confirm-text="확인">
		</u-modal>
	</view>
</template>

<script>
	export default {

		data() {
			return {
				gp_select: [
					["국내", "해외"]
				],
				gp_index: 0,
				gp_show: false,

				// //是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				// closeOnClickOverlay: false,
				Inv: 0,
				items: ['종목 보유 현황', '매매 내역',
					// '보유수량', '매매내역'
				],
				show: false,
				title: '매도 주문',
				content: '매도 하시겠습니까?',
				showCancelButton: true,
				storehouse: '',
				storehouses: '',
				subscribe: '',
				luckyNumber: '',
				userInformation: '',
				timerId: null,
				info: [],
				item_show: false
			}
		},
		// watch: {
		// 	Inv: 'position'
		// },
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '로드 중',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.shuaxin()
			uni.stopPullDownRefresh()
		},

		methods: {
			sell(item) {
				this.info = item
				this.item_show = true;
			},
			gp_changes(index) {
				console.log(index)
				this.gp_index = index.indexs[0]
				this.gp_show = false

				this.storehouse = ""

				this.shuaxin()
			},
			qiehuan(index) {
				this.Inv = index
				this.shuaxin()
			},
			shuaxin() {
				this.storehouse = ""
				uni.showLoading({
					mask: true
				})
				if (this.Inv == 1) {
					this.flat()
				} else {
					this.hold();
				}
			},
			// 平仓
			position(id) {
				this.item_show = false
				this.show = true;
				this.confirmation = id


			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.closingFunction(confirmation)
				this.show = false;
			},
			//产品세부
			productDetails(code) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?code=${code}`
				});
			},

			//点击下标
			subscript() {
				this.Inv == items.index
				// console.log(this.Inv, '下标');
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			// 银转证
			silver() {
				if (this.userInformation.bank_card_info && this.userInformation.idno !== null) {
					uni.navigateTo({
						//保留当前页面，跳转到应用内的某个页面
						url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
					});
				} else if (this.userInformation.bank_card_info == null) {
					uni.$u.toast('은행 카드에 묶여 있지 않음');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/my/components/bankCard/renewal'
						});
					}, 2000)
				} else if (this.userInformation.idno == null) {
					uni.$u.toast('실명인증 불가');
					setTimeout(() => {
						uni.navigateTo({
							//保留当前页面，跳转到应用内的某个页面
							url: '/pages/index/components/openAccount/openAccount'
						});
					}, 2000)
				}

			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			// 新股持仓
			async holdings(e) {
				let list = await this.$http.post('api/user/sg-order', {
					gp_index: this.gp_index
				})
				this.luckyNumber = list.data.data

			},

			// 구독기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-all-apply-log', {
					gp_index: this.gp_index
				})
				this.subscribe = list.data.data
				console.log(this.subscribe, '1111111111')
				// console.log(list.data.data)
			},



			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order', {
					// language: this.$i18n.locale
					status: 1,
					gp_index: this.gp_index
				})
				this.storehouse = list.data.data
				uni.hideLoading()
				// console.log(list.data.data, '持仓');

			},
			//持仓
			async flat() {
				let list = await this.$http.post('api/user/order', {
					// language: this.$i18n.locale
					status: 2,
					gp_index: this.gp_index
				})
				// this.storehouses = list.data.data
				this.storehouse = list.data.data
				uni.hideLoading()
				// console.log(list.data.data, '持仓');
				// setTimeout(() => {
				// 	this.marketQuotations()
				// }, 10000)
			},
			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: "포지션을 마감 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// price: item.price
				})
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					this.shuaxin()
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();

				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}

			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					console.log('위치요청');
					this.shuaxin()
					this.gaint_info()
				}, 8000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求

			},

			duihuan() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					// url: '/pages/my/components/duihuan/index'
					url: "/pages/my/components/certificateBank/prove"
				});
			}
		},

		onShow() {
			this.is_token()
			this.gaint_info()
			// this.flat()
			this.shuaxin()
			// this.startTimer()
		},

		onUnload() {
			console.log('포지션 종료됨1');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('포지션 종료됨2');
			clearInterval(this.timerId);
		},

	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	page {
		background-color: #f3f4f8;
	}

	.with-bottom-line {
		color: #2E67F6;
		font-weight: 700;
	}

	.with-bottom-line::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 2px solid #2E67F6;
		/* 添加底部横线 */
		width: 20%;
		margin-left: 40%;
		/* 使横线宽度与父元素相同 */
		margin-top: 3px;
		/* 可选：添加一些顶部外边距 */
		text-align: center;
	}

	.bglan {
		background-color: #EEF4FF;
	}

	.bgyellow {
		background-color: #F8F8F8;
	}

	/* 遮罩层 */
	.overlay {

		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>