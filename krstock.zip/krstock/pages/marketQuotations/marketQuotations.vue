<template>
	<view class="page" >
		<view style="background: linear-gradient(to bottom, rgba(147, 156, 238, 1.0), rgba(189, 193, 238, 0));height: 200px;">
			
		</view>
		<view class="flex padding-10" style="gap: 10px;margin-top: -180px;">
			<view class="flex-1  text-center" :class="current==index?'top-a':'top'"  v-for="(item,index) in tablist" @click="change(index)">
				{{item.name}}
			</view>
		</view>
		<!-- <u-tabs :list="tablist" lineColor="#014bab"  activeStyle="color:#014bab;font-size:18px;font-weight: 700;"  inactiveStyle="font-size:18px;font-weight: 700;" @change="change" :current="current"></u-tabs> -->
		
		<TabOne v-if="current==0"></TabOne>
		<TabTwo v-if="current==1"></TabTwo>
		<TabThree v-if="current==2"></TabThree>
		<TabFour v-if="current==3"></TabFour>
	</view>
</template>

<script>
	// import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import  TabOne   from '@/components/market/TabOne.vue'
	import  TabTwo   from '@/components/market/TabTwo.vue'
	import  TabThree   from '@/components/market/TabThree.vue'
	import  TabFour   from '@/components/market/TabFour.vue'
	export default {
		components: {
			TabOne,
			TabTwo,
			TabThree,
			TabFour
		},
		data() {
			return {
				tablist: [{
					name: '전체요약'
				}, {
					name: '인기종목'
				}, {
					name: '시장지표'
				}, {
					name: '시장이슈'
				}],
				current:0
			}
		},
		onShow() {},
	
		
		methods: {
			change(index) {
				console.log(index)
				this.current = index;
			},
		},

		mounted() {},
		
		onLoad(op) {
			if(op.type){
				this.current=op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">

	view, text {
	    box-sizing: border-box;
	}
	page{
		background-color: #F3F4F8;
	}
	.home{
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */  
		background-size: cover;  
	  /* 让背景图片始终位于容器的中心 */  
		background-position: center;  
	  /* 不重复背景图片 */  
		background-repeat: no-repeat;  
		height: 600rpx;
		margin-left: -10px;
	}
	.top-a{
		color: #2E67F6;
		height: 25px;
		line-height: 25px;
		font-weight: 700;
	}
	.top-a::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 3px solid #1d7ed2;
		/* 添加底部横线 */
		width: 60%;
		text-align: center;
		margin-left: 20%;
	}
	.top{
		color: #333333;
		height: 25px;
		line-height: 25px;
		margin-top: -4px;
	}
</style>