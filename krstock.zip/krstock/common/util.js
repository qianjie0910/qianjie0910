// 数字值格式化
const formatNumber = (value, fixed = 0) => {
	if (isNaN(value)) return '0';
	let result = Number(value).toFixed(fixed);
	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return result;
};

export default {
	formatNumber,
}