<template>
	<view>
		<view style="display: flex;align-items: center;padding: 60rpx 40rpx 20rpx 40rpx;background-color: #FFFFFF;" >
			<!-- <view class="custom_header_left" @click="handleBack()">
				<view class="arrow rotate_225" :style="$util.setImageSize(20)"></view>
			</view> -->
			<text class="custom_header_center" style="color:#121212">{{$lang.LICAI_LICAI}}</text>
			<view style="margin-left: auto;" @click="linkRecord()">
				<image mode="aspectFit" src="/static/icon_record.png" :style="$util.setImageSize(40)"></image>
			</view>
		</view>
		<view style="background-color: #ffffff;margin: 10px;padding: 10px;" >
			<view class="flex margin-top-10" style="justify-content: space-between;">
				<view class="flex">
					<view style="color: #666666;">{{$lang.LEVEL_CURRENT_LEVEL}}</view>
					<image src="/static/level_desc.png" mode="widthFix" style="width: 15px;margin-left: 5px;" @click="linkDesc()"></image>
				</view>
				<image src="/static/level2.png" mode="widthFix" style="width: 70px;margin-left: 5px;"></image>
			</view>
			<view class="flex margin-top-10" style="justify-content: space-between;">
				<view style="color: #666666;">{{$lang.LEVEL_CURRENT_TEAM}}</view>
				<view class="flex" @click="home()">
					<view style="font-size: 16px;">{{setInfo.teamNum}}{{$lang.LICAI_REN}}</view>
					<image src="/static/youjiantou.png" mode="widthFix" style="width: 5px;margin-left: 10px;"></image>
				</view>
			</view>

		</view>

		<template >
			 
			<u-collapse style="padding: 0px 10px 0px 5px;background-color: #FFFFFF;">
				<u-collapse-item  :title="$lang.LEVEL_NEXT_LEVEL" >
					<view class="flex margin-top-10" style="justify-content: space-between;">
						<view style="color: #666666;font-size: 5px;">{{$lang.LEVEL_SELF_HOLD_MONEY+` > `+setInfo.holdMoney}}</view>
						<view class="flex">
							<view style="color: #666666;font-size: 5px;color: #00AA98;">{{setInfo.curHoldMoney}}</view>
							<image :src="`/static/level_${setInfo.holdMoneyPass?'ok':'info'}.png`" mode="widthFix" style="width: 15px;margin-left: 10px;">
							</image>
						</view>
					</view>

					<view class="flex margin-top-10" style="justify-content: space-between;">
						<view style="color: #666666;font-size: 5px;">{{$lang.LEVEL_L1_TEAM_USERS+` > `+setInfo.l1TeamNum}}</view>
						<view class="flex">
							<view style="color: #666666;font-size: 5px;color: #00AA98;">{{setInfo.curL1TeanNum}}</view>
							<image :src="`/static/level_${setInfo.l1Pass?'ok':'info'}.png`" mode="widthFix" style="width: 15px;margin-left: 10px;">
							</image>
						</view>
					</view>
					<view class="flex margin-top-10" style="justify-content: space-between;">
						<view style="color: #666666;font-size: 5px;">{{$lang.LEVEL_L1_TEAM_MONEY+` > `+setInfo.l1Money}}</view>
						<view class="flex">
							<view style="color: #666666;font-size: 5px;">{{setInfo.curL1Money}}</view>
							<image :src="`/static/level_${setInfo.l1PassMoney?'ok':'info'}.png`" mode="widthFix" style="width: 15px;margin-left: 10px;">
							</image>
						</view>
					</view>

					<view class="flex margin-top-10" style="justify-content: space-between;">
						<view style="color: #666666;font-size: 5px;">{{$lang.LEVEL_L2_TEAM_USERS+` > `+setInfo.l2TeamNum}}</view>
						<view class="flex">
							<view style="color: #666666;font-size: 5px;color: #00AA98;">{{setInfo.curL2TeanNum}}</view>
							<image :src="`/static/level_${setInfo.l2Pass?'ok':'info'}.png`" mode="widthFix" style="width: 15px;margin-left: 10px;">
							</image>
						</view>
					</view>

					</text>
				</u-collapse-item>
			</u-collapse>
		</template>


		<view style="margin:0 10px;padding:10rpx;">
			<template v-if="list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="padding:30rpx;background-color: #FFFFFF;margin:30rpx 0;border-radius:24rpx;"
						@click="handleInfo(item)">
						<view style="display: flex;align-items: center;">
							<view style="flex:1 0 70%;color:#121212;font-size: 36rpx;">
								{{item.name}}
							</view>
							<template v-if="item.is_new==1">
								<view style="margin-left: auto;">
									<view
										style="background-color:#00B45A4D;color:#00B45A;border-radius:12rpx;padding:4rpx 10rpx;font-size:24rpx;text-align:center;">
										{{$lang.TRADE_WEALTH_NEW_USERS}}
									</view>
								</view>
							</template>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">{{$lang.LICAI_YUGUSHOUYILV}}</view>
							<view style="color:#00AA98;font-size: 28rpx;">{{item.syl}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">{{$lang.LICAI_ZHOUQI}}</view>
							<view style="color:#333333;font-size: 28rpx;">{{item.zhouqi +$lang.TRADE_WEALTH_CYCLE_UNIT}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">{{$lang.LICAI_ZUIDIMAIRU}}</view>
							<view style="color:#333333;font-size: 28rpx;">{{item.min_price}}</view>
						</view>
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<WealthBuy :info="infos" @action="handleClose"></WealthBuy>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import WealthBuy from './components/WealthBuy.vue';
	export default {
		components: {
			EmptyData,
			WealthBuy,
		},
		data() {
			return {
				list: [],
				isShow: false,
				info: {}, // 选中一条数据
			};
		},
		computed: {
			setInfo() {
				
				if (this.info && this.info.userinfo) {
					console.log(this.info, this.info.userinfo);
					return {
						teamNum: this.info.team_num, // 团队人数
						// level_mx 后端直接返回是否达标结果
						l1Pass: this.info.level_mx.if_l1, // L1团队人数是否达标
						l1PassMoney: this.info.level_mx.if_l1_licai_money, // L1理财金额是否达标
						l2Pass: this.info.level_mx.if_l2, // L2团队人数是否达标						
						holdMoneyPass: this.info.level_mx.if_licai_money, // 自身持有金额是否达标
						// 距 下一等级
						// 自身持有金额(目标)
						holdMoney: this.$util.formatMoney(this.info.level_mx.level_up_info.licai_money, 0),
						l1TeamNum: this.info.level_mx.level_up_info.l1, // L1 团队人数(目标)
						// L1 理财金额(目标)
						l1Money: this.$util.formatMoney(this.info.level_mx.level_up_info.l1_licai_money, 0),
						l2TeamNum: this.info.level_mx.level_up_info.l2, // L2 团队人数(目标)
						// L2 理财金额(目标)
						l2Money: this.$util.formatMoney(this.info.level_mx.level_up_info.l2_licai_money, 0),
						// 用户的当前等级数据
						// 当前自身持有金额
						curHoldMoney: this.$util.formatMoney(this.info.level_mx.licai_money, 0),
						curL1TeanNum: this.info.level_mx.l1, // 当前L1团队人数
						// 当前L1团队总金额
						curL1Money: this.$util.formatMoney(this.info.level_mx.l1_licai_money, 0),
						curL2TeanNum: this.info.level_mx.l2, // 当前L2团队人数
						// 当前L2团队总金额					
						curL2Money: this.$util.formatMoney(this.info.level_mx.l2_licai_money, 0),
						curLevel: this.info.userinfo.level, // 用户的当前等级
					}
				}
			}
		},
		onShow() {
			this.getList();
		},
		onLoad() {
			this.getLevelInfo();
		},
		
		onHide() {},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1,
				})
			},
			linkDesc() {
				uni.navigateTo({
					url: this.$paths.LEVEL_DESC
				})
			},
			home(){
				uni.navigateTo({
					url:'/pages/account/level',
				})
			},
			// 跳转到记录
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_WEALTH_RECORD
				})
			},
			// 购买弹层关闭
			handleClose(val) {
				this.isShow = false;
			},
			// 选中一条数据
			handleInfo(item) {
				console.log(item);
				this.infos = item;
				this.isShow = true;
			},
			//用户信息
			async getLevelInfo() {
				const result = await this.$http.get(`api/user/tuandui`);
				console.log('info result：', result);
				if (!result) return false;
				this.info = result;
				
			},
			open(e) {
				// console.log('open', e)
			},

			// 获取列表数据
			async getList() {
				const result = await this.$http.get(`api/jijin/list`);
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result;
			}
		}
	}
</script>

<style>
</style>