<template>
	<view style="background-color: #FFFFFF;min-height: 100vh;">

		<view style="background-image: linear-gradient(180deg, #00aa99, transparent);">
			<HeaderSecond :title="$lang.ACCOUNT_CHANGE_PWD"></HeaderSecond>
		</view>

		<view style="margin: 20px;padding: 20px;">
			<view class="common_input_wrapper" style="background-color: #F8F8F8;margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/old_pwd.png" :style="$util.setImageSize(32)">
				</image>
				<input v-model="value" type="password" :placeholder="$lang.TIP_OLD_PWD"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<view class="common_input_wrapper" style="background-color: #F8F8F8;margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$util.setImageSize(32)">
				</image>
				<template v-if="isShow">
					<input v-model="value2" type="text" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="value2" type="password" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$util.setImageSize(40)" @click="toggleShow">
				</image>
			</view>

			<view class="common_input_wrapper" style="background-color: #F8F8F8;margin-bottom: 30px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$util.setImageSize(32)">
				</image>
				<template v-if="isShow">
					<input v-model="value3" type="text" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="value3" type="password" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$util.setImageSize(40)" @click="toggleShow">
				</image>
			</view>
			<view class="access_btn" style="margin:20px auto; width: 90%;" @click="changePassword()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isShow: false, // 密码显隐
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			//修改登录密码
			async changePassword() {
				const result = await this.$http.post(`api/user/updateLoginPassword`, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				});
				if (!result) return false;
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000);
			},
		},
	}
</script>