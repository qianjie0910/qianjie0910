<template>
	<view :style="$theme.setBGSize(`480rpx`)">
		<HeaderPrimary :title="$lang.TABBAR_ACCOUNT"></HeaderPrimary>

		<Profile :info="userInfo"></Profile>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="center_card">
				<view style="display: flex;padding:20rpx 40rpx;color:#222;font-size: 32rpx;">
					{{$lang.ACCOUNT_AMOUNT_TOTAL}}
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
					</image>
					<view style="margin-left: auto;" @click="linkTradRecord()">
						<view
							style="background-color: #FFFFFF;color:#333333;border-radius: 12rpx;padding:6rpx 12rpx;font-size: 20rpx;">
							{{$lang.TRADE_RECORD_TITLE}}
						</view>
					</view>
				</view>
				<template v-if="showAmount">
					<view style="color:#222;padding:0 40rpx;display: flex;align-items: center;">
						<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(userInfo.totalZichan)}}
						</view>
						<view style="padding-left: 30rpx;">USDT</view>
					</view>
				</template>
				<template v-else>
					<view style="color:#222;padding:0 40rpx;">{{hideAmount}} </view>
				</template>
				<view style="color: #222;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
				</view>
				<template v-if="showAmount">
					<view style="color:#222;padding:0 40rpx;display: flex;align-items: center;">
						<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(userInfo.money)}}
						</view>
						<view style="padding-left: 30rpx;">USDT</view>
					</view>
				</template>
				<template v-else>
					<view style="color:#222;padding: 40rpx;">{{hideAmount}} </view>
				</template>
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;padding: 40rpx;">
			<view style="flex:1 0 25%; text-align: center;" @click="linkWithdraw()">
				<image src="/static/icon_center_withdraw.png" mode="aspectFit" :style="$theme.setImageSize(80)"
					style="margin:auto"></image>
				<view style="text-align: center;">{{$lang.PAGE_TITLE_WITHDRAW}}</view>
			</view>
			<view style="flex:1 0 25%; text-align: center;" @click="linkDeposit()">
				<image src="/static/icon_center_deposit.png" mode="aspectFit" :style="$theme.setImageSize(80)"
					style="margin:auto"></image>
				<view style="text-align: center;">{{$lang.PAGE_TITLE_DEPOSIT}}</view>
			</view>
			<!-- <view style="flex:1 0 25%; text-align: center;" @click="linkExchange()">
				<image src="/static/icon_center_coin_exchange.png" mode="aspectFit" :style="$theme.setImageSize(80)"
					style="margin:auto"></image>
				<view style="text-align: center;">{{$lang.PAGE_TITLE_DE}}</view>
			</view> -->
			<!-- <view style="flex:1 0 25%; text-align: center;" @click="linkService()">
				<image src="/static/icon_center_service.png" mode="aspectFit" :style="$theme.setImageSize(80)"
					style="margin:auto"></image>
				<view style="text-align: center;">Service</view>
			</view> -->
		</view>

		<view style="padding:0 10px;">
			<CustomTitle :title="$lang.ACCOUNT_MORE_FEATURES"></CustomTitle>
		</view>

		<NavList :code="userInfo.code"> </NavList>

		<view class="access_btn" style="margin:20px auto; width: 90%;" @click="handleSignOut()">
			{{$lang.SIMGN_OUT}}
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			NavList,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
			}
		},
		onShow() {
			this.getAccountInfo()
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},

			linkExchange() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_BING_BANK,
				})
			},

			linkService() {
				this.$util.linkCustomerService();
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},

			// 登出
			handleSignOut() {
				uni.removeStorageSync('token');
				try {
					let version = uni.getStorageSync('version')
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_ACCESS
					});
				}, 500)
			},
			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				console.log(this.userInfo.userlevel);
			}
		},
	}
</script>