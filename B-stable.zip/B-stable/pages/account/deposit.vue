<!-- 银转证  存款 -->
<template>
	<view style="background-color: #FFFFFF;">
		<HeaderSecond :title="$lang.PAGE_TITLE_DEPOSIT"></HeaderSecond>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="center_card">
				<view style="display: flex;padding:20rpx 40rpx;color:#222;font-size: 32rpx;">
					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
					</image>
					<view style="margin-left: auto;" @click="linkTradRecord()">
						<view
							style="background-color: #FFFFFF;color:#333333;border-radius: 12rpx;padding:6rpx 12rpx;font-size: 20rpx;">
							{{$lang.TRADE_RECORD_TITLE}}
						</view>
					</view>
				</view>
				<template v-if="showAmount">
					<view style="color:#222;padding:0 40rpx;display: flex;align-items: center;">
						<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(info.money )}}
						</view>
						<view style="padding-left: 30rpx;">USDT</view>
					</view>
				</template>
				<template v-else>
					<view style="color:#222;padding:0 40rpx;">{{hideAmount}} </view>
				</template>
				<view style="color: #222;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
					{{$lang.ACCOUNT_AMOUNT_TOTAL}}
				</view>
				<template v-if="showAmount">
					<view style="color:#222;padding:0 40rpx;display: flex;align-items: center;">
						<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(info.total)}}
						</view>
						<view style="padding-left: 30rpx;">USDT</view>
					</view>
				</template>
				<template v-else>
					<view style="color:#222;padding: 40rpx;">{{hideAmount}} </view>
				</template>
			</view>
		</view>

		
		<view style="padding: 20px 10px;">
			
			<CustomTitle title="Choose"></CustomTitle>
			
			<view class="margin-10">
				<u-radio-group
				    v-model="type"
					
				    placement="row">
					<!-- <u-radio  label="Bank" name="5" ></u-radio> -->
					<u-radio  label="USDT"  name="4"></u-radio>
				</u-radio-group>
				
			</view>
			<view class="margin-10" v-if="type==5&&bank">
				<view class="flex flex-b" @click="copy(bank.BankName)">
					<view>Bank Name</view>
					<view>{{bank.BankName}}
					<image src="/static/trade_active.png" mode="widthFix" style="width: 15px;height: 15px;margin-left: 5px;" ></image>
					</view>
				</view>
				<view class="flex flex-b margin-top-10" @click="copy(bank.BankNo)">
					<view>Bank No</view>
					<view>{{bank.BankNo}}
					<image src="/static/trade_active.png" mode="widthFix" style="width: 15px;height: 15px;margin-left: 5px;" ></image>
					</view>
				</view>
				<view class="flex flex-b margin-top-10" @click="copy(bank.BankUser)">
					<view>Bank User</view>
					<view>{{bank.BankUser}}
					<image src="/static/trade_active.png" mode="widthFix" style="width: 15px;height: 15px;margin-left: 5px;" ></image>
					</view>
				</view>
			</view>
			<view class="margin-10" v-if="type==4&&bank">
				<view class="flex flex-b" @click="copy(bank.erc20)">
					<view>ERC20 Address</view>
					<view class="flex">
						<view class="example">{{bank.erc20}}</view>
						<image src="/static/trade_active.png" mode="widthFix" style="width: 15px;height: 15px;margin-left: 5px;" ></image>
					</view>
				</view>
				<view class="flex flex-b margin-top-10" @click="copy(bank.trc20)">
					<view>TRC20 Address</view>
					<view class="flex">
						<view class="example">{{bank.trc20}}</view>
						<image src="/static/trade_active.png" mode="widthFix" style="width: 15px;height: 15px;margin-left: 5px;" ></image>
					</view>
				</view>
				
			</view>
			
			<CustomTitle :title="$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT" style="margin-top: 20px;"></CustomTitle>
			<view class="common_input_wrapper" style="background-color: #FFFFFF;border: 1px solid #E8EAF3;margin:10px;">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view>

			<view
				style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:10px;">
				<block v-for="(item,index) in amountList" :key="index">
					<view style="padding:10px;border-radius: 6px;"
						:style="{backgroundColor:curPos==index?'#00aa99':'#F6F8FC',color:curPos==index? '#FFFFFF':'#666666' }"
						@click="quantity(item,index)">
						{{item}}
					</view>
				</block>
			</view>

			<CustomTitle :title="$lang.DEPOSIT_UPLOAD_TITLE"></CustomTitle>
			<view
				style="display: flex;align-items: center;justify-content: center;padding: 32rpx;background-color: #00B45A1A;border-radius: 8rpx;margin: 30rpx;">
				<image :src="!formData.obverseUrl?`/static/card_f.png`:formData.obverseUrl" @click="selectImg()"
					style="margin: 10px;width: 480rpx;height: 240rpx;"></image>
			</view>


			<view class="access_btn" style="margin:20px auto; width: 90%;" @click="to_recharge()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>

		<view style="padding: 10px 20px;">
			<view style="font-size: 14px;font-weight: 700;text-align: center;" :style="{color:$theme.TITLE}">
				{{$lang.DEPOSIT_TIP_TITLE}}
			</view>
			<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
				<view style="padding-bottom:6px;color: #999;">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import md5 from 'js-md5';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				info: {}, // 基本信息
				obverseUrl: '',
				formData: {
					obverseUrl: '',
				},
				type:"4",
				bank:{}
			};
		},
		computed: {
			amountList() {
				// 充值预置额
				return [1000000, 3000000, 5000000, 10000000];

			}
		},
		onLoad(option) {
			this.getAccountInfo()
			this.amount = this.amountList[0];
			this.getconfig();
		},
		methods: {
			// 点击复制邀请链接
			async copy(text) {
				// 获取域名
				const temp =text;
			
				const result = await uni.setClipboardData({
					data: temp , //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.TIP_COPY_SUCCESS,
						duration: 2000,
						icon: 'success'
					})
				}
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				
				console.log(7777,temp.get('BankName'));

				this.bank.BankName = temp.get('BankName') || this.bank.BankName;
				this.bank.BankNo = temp.get('BankNo') || this.bank.BankNo;
				this.bank.BankUser = temp.get('BankUser') || this.bank.BankUser;
				
				this.bank.erc20 = temp.get('erc20') || this.bank.erc20;
				this.bank.trc20 = temp.get('trc20') || this.bank.trc20;
				
				console.log(this.bank);

				this.$forceUpdate()
			},
			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 点击上传
			async selectImg() {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);

				this.upimg(imageFile.path)
			},
			// 上传图片
			async upimg(tempFilePath) {
				uni.showLoading({
					title: this.$lang.STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: this.$http.BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					this.formData.obverseUrl = temp[0].url;
				}
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_TIP_LOW_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'none'
				});
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: this.type,
					image: this.formData.obverseUrl || '',
					desc: '',
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title:this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				});
				// setTimeout(() => {
				// 	this.$util.linkCustomerService();
				// }, 1000)
			},

			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.info = {
					total: result.totalZichan || 0,
					money: result.money || 0,
				};
			}
		},
	}
</script>
<style>
	.example {
		width: 150px; 
		white-space: nowrap; 
		overflow: hidden; 
		text-overflow: ellipsis;
	}
</style>