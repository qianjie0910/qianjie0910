<!-- 登入 注册 -->
<template>
	<view class="access_bg">
		<view class="access_header"></view>
		<template>
			<view class="access_signin">
			</view>
		</template>

		<view style="position: fixed;right:3vw;top:1vh;z-index: 11115;">
			<Translate></Translate>
		</view>

		<view class="access_wrapper">
			<h3 style="font-size: 40rpx;text-align: center;padding-bottom:20px;" :style="{color:'#333333'}">
				{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
			</h3>
			<view style="padding:0px 30px 10px 30px;">
				<view class="access_input_wrapper" style="">
					<image src="/static/account_name.png" mode="aspectFit" :style="$util.setImageSize(40)"></image>
					<input v-model="user" type="text" :placeholder="$lang.ENTER_USER_NAME" 
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</view>
			</view>
			
			<view style="padding:0 30px 10px 30px;" v-if="!isSignIn">
				<view class="access_input_wrapper" style="">
					<image src="/static/account_code.png" mode="aspectFit" :style="$util.setImageSize(40)">
					</image>
					<input v-model="email_code" type="text" :placeholder="$lang.INVITATION_CODE" maxlength="11" :placeholder-style="$util.setPlaceholder()" style="width: 80%;">
						<view class="padding-10 radius10 color-white" style="background-color: #00aa99;" @tap="getCode">{{tips}}</view>
						<u-code :seconds="seconds" @end="end" @start="start" ref="uCode" @change="codeChange" startText="Send" changeText="X" endText='Send' ></u-code>
					</input>
					
				</view>
			</view>
			
			<view style="padding:0 30px 10px 30px;">
				<view class="access_input_wrapper" style="">
					<image src="/static/account_password.png" mode="aspectFit" :style="$util.setImageSize(40)">
					</image>
					<template v-if="isShow">
						<input v-model="password" type="text" :placeholder="$lang.ENTER_PASSWORD"
							:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
					</template>
					<template v-else>
						<input v-model="password" type="password" :placeholder="$lang.ENTER_PASSWORD"
							:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
					</template>

					<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
						:style="$util.setImageSize(40)" @click="toggleShow">
					</image>
				</view>
				
			</view>

			<template v-if="!isSignIn">
				
				<view style="padding:0 30px 10px 30px;">
					<view class="access_input_wrapper" style="">
						<image src="/static/account_password.png" mode="aspectFit" :style="$util.setImageSize(40)">
						</image>
						
						
							
							
						<template v-if="isShow">
							<input v-model="verifyPassword" type="text" :placeholder="$lang.VERIFY_PASSWORD"
								:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
						</template>
						<template v-else>
							<input v-model="verifyPassword" type="password" :placeholder="$lang.VERIFY_PASSWORD"
								:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
						</template>

						<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
							:style="$util.setImageSize(40)" @click="toggleShow">
						</image>
					</view>
					
						
					
				</view>
				<view style="padding:0 30px 20px 30px;">
					<view class="access_input_wrapper" style="">
						<image src="/static/account_code.png" mode="aspectFit" :style="$util.setImageSize(40)">
						</image>
						<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE" maxlength="11"
							:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
					</view>
				</view>
			</template>

			<view class="access_btn" @click="handleConfirm()">
				{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
			</view>

			<template v-if="isSignIn">
				<view
					style="padding:20px 30px 10px 30px;display: flex;align-items: center;justify-content: space-between;">

					<u-checkbox-group>
						<u-checkbox shape="" :activeColor="$theme.PRIMARY" :label="$lang.TIP_REMEMBER_PWD"
							v-model="isRemember" :labelColor="$theme.PRIMARY" labelSize="24rpx" @change="changeRemember"
							:checked="isRemember"></u-checkbox>
					</u-checkbox-group>

					<view style="font-size: 28rpx;margin-right: 4px;" :style="{color:$theme.PRIMARY}"
						@click="handleChange()">
						{{isSignIn?$lang.SIGN_UP:$lang.GO_TO_SIGN_IN}}
					</view>
				</view>
			</template>

			<template v-else>
				<view class="access_btn" @click="handleChange()" style="background-color: transparent;border-radius: 0;"
					:style="{color:$theme.PRIMARY}">
					{{$lang.SIGN_IN}}
				</view>
			</template>

			<view style="padding:20px 30px 10px 30px;display: flex;align-items: center;justify-content: center;">
				<u-checkbox-group>
					<u-checkbox shape="" :activeColor="$theme.PRIMARY" :label="$lang.TIP_AGREE" v-model="isAgree"
						labelColor="#666666" labelSize="24rpx" @change="changeAgree" :checked="isAgree"></u-checkbox>
				</u-checkbox-group>
				<view style="font-size:24rpx;margin-left: 8px;" :style="{color:$theme.PRIMARY}" @click="linkPact()">
					{{$lang.TIP_PRVITE_PACT}}
				</view>
			</view>
		</view>

		<!-- <view class="access_wrapper">
			<view style="width: 100%;height: 100vh; border-radius: 30px 30px 0px 0px;padding-top: 20px;">
				<h3 style="font-size: 40rpx;text-align: center;padding-bottom:20px;" :style="{color:'#333333'}">
					{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
				</h3>

				
			</view> -->
	</view>
	</view>
</template>

<script>
	import Translate from '@/components/Translate.vue';
	import CustomDivider from '@/components/CustomDivider.vue';
	import {
		getSmsCode
	} from '@/common/api.js';
	
	export default {
		components: {
			Translate,
			CustomDivider
		},
		data() {
			return {
				isShow: false, // 密码显隐
				user: "",
				password: '',
				verifyPassword: '',
				code: '',
				isSignIn: true,
				isRemember: false, // 记住密码
				isAgree: false, // 同意隐私协议
				shareCode: '', // 分享链接携带的邀请码
				seconds: 60,
				tips: 'Send',
				email_code:""
			};
		},
		onLoad(opt) {
			console.log(`opt:`, opt);
			if (opt.code && opt.code.length > 0) {
				this.isSignIn = false; // 设置到注册状态
				this.shareCode = opt.code || '';
			}
		},
		onShow() {
			// 读取缓存中的页面信息
			this.getStorageData();
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
		},
		onHide() {
			// 缓存页面信息
			this.setStorageData();
		},
		mounted() {
			// 页面渲染完成，将邀请码复制到邀请码输入框
			this.code = this.shareCode;
		},
		methods: {
			codeChange(text) {
				this.tips = text;
			},
			checkEmail(val) {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				return !emailPattern.test(val)
			},
			async getCode() {
				if (this.checkEmail(this.user)) {
					uni.$u.toast(this.$lang.ENTER_USER_NAME);
					return false;
				}
				if (!this.user || this.user == '') {
					uni.$u.toast(this.$lang.ENTER_USER_NAME);
					return false;
				}
				
				if(this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: 'Getting verification code'
					})
					
					const result = await this.$http.post(`api/app/sendSmsCode`, {
						mobile: this.user,
					})
					
			
					uni.hideLoading()
					console.log('result:', result);
					// 通知验证码组件内部开始倒计时
					this.$refs.uCode.start();
				} else {
					uni.$u.toast('Send after the countdown ends');
				}
			},
			end() {
				// uni.$u.toast('倒计时结束');
			},
			start() {
				// uni.$u.toast('倒计时开始');
			},
			// 设置页面缓存信息
			setStorageData() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.setStorageSync('pwd1', this.verifyPassword);
				uni.setStorageSync('code', this.code);
				uni.setStorageSync('remember', this.isRemember);
				uni.setStorageSync('agree', this.isAgree);
			},
			// 获取页面缓存信息
			getStorageData() {
				this.user = uni.getStorageSync('user') || '';
				this.password = uni.getStorageSync('pwd') || '';
				this.verifyPassword = uni.getStorageSync('pwd1') || '';
				this.code = uni.getStorageSync('code') || '';
				this.isRemember = uni.getStorageSync('remember') || false;
				this.isAgree = uni.getStorageSync('agree') || false;
			},
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 勾选记住密码
			changeRemember(e) {
				this.isRemember = e;
				uni.setStorageSync('remember', this.isRemember);
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
				uni.setStorageSync('agree', this.isAgree);
			},

			// 用户隐私协议
			linkPact() {
				this.setStorageData();
				uni.navigateTo({
					url: this.$paths.ACCOUNT_PRVITE_PACT
				})
			},

			handleChange() {
				this.isSignIn = !this.isSignIn;
				this.setStorageData();
				this.getStorageData();
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast(this.$lang.ENTER_USER_NAME);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.ENTER_PASSWORD);
					return false;
				}
				if (!this.isSignIn &&this.email_code == '') {
					uni.$u.toast("Please fill in the email verification code");
					return false;
				}
				
				
				if (!this.isSignIn && this.verifyPassword == '') {
					uni.$u.toast(this.$lang.ENTER_VERIFY_PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && (!this.code || this.code.length <= 0)) {
					uni.$u.toast(this.$lang.ENTER_INVITATION_CODE);
					return false;
				}
				if (this.isAgree != true) {
					uni.$u.toast(this.$lang.TIP_CHECK_AGREE);
					return false;
				}
				return true;
			},

			async signIn() {
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				})
				if (!result) return false;
				const token = result.token.access_token
				uni.setStorageSync('token', token);
				uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
				this.setStorageData();
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.HOME,
					});
				}, 1000);
			},
			async register() {
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: this.email_code,
					
				})
				if (!result) return false;
				uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
				this.setStorageData();
				this.signIn();
			},
		}
	}
</script>