<template>
	<view :style="$theme.setBGSize(`280rpx`)">
		<HeaderPrimary :title="$lang.TABBAR_TRADE"></HeaderPrimary>

		<view style="display: flex;align-items: center;justify-content: center;margin: 40rpx 0;">
			<view class="center_card">
				<view style="display: flex;padding:20rpx 40rpx;color:#222;font-size: 32rpx;">
					{{$lang.ACCOUNT_AMOUNT_TOTAL}}
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
					</image>
					<view style="margin-left: auto;" @click="linkTradRecord()">
						<view
							style="background-color: #FFFFFF;color:#333333;border-radius: 12rpx;padding:6rpx 12rpx;font-size: 20rpx;">
							{{$lang.TRADE_RECORD_TITLE}}
						</view>
					</view>
				</view>
				<template v-if="showAmount">
					<view style="color:#222;padding:0 40rpx;display: flex;align-items: center;">
						<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(userInfo.totalZichan)}}
						</view>
						<view style="padding-left: 30rpx;">USDT</view>
					</view>
				</template>
				<template v-else>
					<view style="color:#222;padding:0 40rpx;">{{hideAmount}} </view>
				</template>
				<view style="color: #222;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
				</view>
				<template v-if="showAmount">
					<view style="color:#555;padding:0 40rpx;display: flex;align-items: center;">
						<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(userInfo.money)}}
						</view>
						<view style="padding-left: 30rpx;">USDT</view>
					</view>
				</template>
				<template v-else>
					<view style="color:#222;padding: 40rpx;">{{hideAmount}} </view>
				</template>
			</view>
		</view>


		<CustomTitle :title="$lang.TRADE_TITLE">
			<view style="margin-left: auto;color:#666666;">
			</view>
		</CustomTitle>

		<TabsFourth :tabs="$lang.TRADE_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsFourth>

		<template v-if="curTab==0">
			<TradeHoldList></TradeHoldList>
		</template>
		<template v-else>
			<TradeSellList></TradeSellList>
		</template>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
					<view class="popup_header">
						<text :style="{color:$theme.ACCESS_TEXT}"
							style="text-align: center;font-size: 16px;">{{$lang.TRADE_MOADL_TITLE}}</text>
						<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[0]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">{{info.goods_info.name}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[1]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.order_buy.created_at}}
						</view>
					</view>
					<template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[2]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[3]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(
							isHold?info.order_buy.float_yingkui*1
							:!info.order_sell?0:info.order_sell.float_yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[5]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[6]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[7]}}
						</view>
						<view style="flex: 30%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 20%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[4]}}
						</view>
						<view style="flex: 20%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.order_buy.double}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[8]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[9]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[10]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
						v-if="isHold">
						<view class="trade_modal_btn" style="background-color: #FF6700;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.BTN_DETAIL}}
						</view>
						<view class="trade_modal_btn" style="background-color:#00aa99;" @tap="handleSell(info.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import CustomTitle from '@/components/CustomTitle.vue';

	import TradeHoldList from "@/components/trade/TradeHoldList.vue";
	import TradeSellList from "@/components/trade/TradeSellList.vue";

	export default {
		components: {
			HeaderPrimary,
			TradeInfo,
			EmptyData,
			TabsFourth,
			CustomTitle,
			TradeHoldList,
			TradeSellList,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				curTab: 0, // 

				radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				list: [],
				info: {},
				isShow: false, // 买卖弹出
				curPage: 1, // 当前页码	
				maxPage: 1, // 最大页码
				flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题
			}
		},
		computed: {
			locationList() {
				return [{
					name: this.$lang.STOCK_COUNTRY_SELF,
				}, {
					name: this.$lang.STOCK_COUNTRY_OTHER
				}]
			}
		},

		onShow() {
			this.getAccountInfo();
			// this.getList();
		},
		//下拉刷新
		onPullDownRefresh() {
			// this.curPage = 1; // 从第一页重新开始
			// this.list = []; // 清空所有翻页后内中数据
			// this.getList();
			uni.stopPullDownRefresh();
		},

		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				// if (this.curTab == 1) {
				// 	this.isHold = false;
				// } else {
				// 	this.isHold = true;
				// }
				// this.getList();
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},

			// handleShowModal(item) {
			// 	this.isShow = true;
			// 	this.info = item
			// },

			// // 平仓/卖出
			// handleSell(id) {
			// 	const _this = this;
			// 	uni.showModal({
			// 		title: this.$lang.SELL_TIP,
			// 		cancelText: this.$lang.BTN_CANCEL,
			// 		confirmText: this.$lang.BTN_CONFIRM,
			// 		success: function(res) {
			// 			this.isShow = false;
			// 			if (res.confirm) {
			// 				_this.confirmSell(id);
			// 			} else if (res.cancel) {}
			// 		}
			// 	})
			// },


			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
			},

			// // 平仓功能
			// async confirmSell(id) {
			// 	const result = await this.$http.post(`api/user/sell`, {
			// 		id
			// 	});
			// 	if (!result) return false;
			// 	this.getData();
			// },

			// handleStockDetail(code) {
			// 	uni.navigateTo({
			// 		url: `${this.$paths.COIN_OVERVIEW}?code=${code}`
			// 	});
			// },


		},
	}
</script>