<!-- 绑定银行卡 -->
<template>
	<view style="background-color: #FFFFFF;min-height: 100vh;">
		<view style="background-image: linear-gradient(180deg, #00aa99, transparent);">
			<HeaderSecond :title="`Add account`"></HeaderSecond>
		</view>

		<view class="bankInfo-box margin-top-20">
			<view class="bold font-size-16">
				Select Currency </view>
			<view class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;"
				@click="show=true">
				<view class="font-size-16">{{huobi}}</view>
				<image src="/static/xiajiantou.png" mode="widthFix" style="width: 15px;"></image>
			</view>
		</view>

		<view style="padding: 10px 20px;" v-if="type==2">
			<view class="bold font-size-16">Wallet Address </view>
			<input placeholder="Enter Address" class="flex flex-b padding-10 margin-top-10 radius10"
				style="border: 1px #E8EAF3 solid;" v-model="address" />
		</view>
		<view v-if="type==1">
			<view style="padding: 10px 20px;">
				<view class="bold font-size-16">
					Bank Card account </view>
				<input placeholder="Please add bank card account" class="flex flex-b padding-10 margin-top-10 radius10"
					style="border: 1px #E8EAF3 solid;" v-model="address" />
			</view>

			<view style="padding: 10px 20px;">
				<view class="bold font-size-16">
					Bank Name </view>
				<input placeholder="Enter Bank Name" class="flex flex-b padding-10 margin-top-10 radius10"
					style="border: 1px #E8EAF3 solid;" v-model="bank_name" />
			</view>

			<view style="padding: 10px 20px;">
				<view class="bold font-size-16">Bank Code</view>
				<input placeholder="Enter Bank Code" class="flex flex-b padding-10 margin-top-10 radius10"
					style="border: 1px #E8EAF3 solid;" v-model="bank_code" />
			</view>

			<!-- <view  style="padding: 10px 20px;">
				<view class="bold font-size-16">银行地址</view>
				<input placeholder="请输入银行代码" class="flex flex-b padding-10 margin-top-10 radius10" style="border: 1px #E8EAF3 solid;" v-model="bank_sub_name_address"/>
			</view> -->

			<view style="padding: 10px 20px;">
				<view class="bold font-size-16">Payee Name </view>
				<input placeholder="Enter Payee Name" class="flex flex-b padding-10 margin-top-10 radius10"
					style="border: 1px #E8EAF3 solid;" v-model="realname" />
			</view>
		</view>

		<view class="access_btn" style="margin:20px auto; width: 90%;" @click="replaceBank()">
			Confirm
		</view>

		<u-picker :show="show" :columns="columns" @confirm="confirm" @cancel="show=false" confirmText="confim"
			cancelText="cancel"></u-picker>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				show: false,
				type: 2,
				huobi: "ERC20-USDT",
				columns: [
					['ERC20-USDT', 'TRC20-USDT'],
					// 'Card'
				],
				realname: "",
				address: "",
				bank_name: "",
				bank_code: "",
				card_sn: "",
				bank_sub_name_address: ""
			};
		},
		methods: {
			confirm(e) {
				console.log('confirm', e)
				this.show = false
				this.huobi = e.value[0]
				if (e.indexs[0] == 2) {
					this.type = 1
				} else {
					this.type = 2
				}

			},
			home() {
				uni.switchTab({
					url: this.$paths.ACCOUNT_CENTER
				});
			},
			//跟换银行卡
			async replaceBank() {
				uni.showLoading({
					title: 'Submitting'
				});
				const result = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.realname,
					bank_name: this.bank_name,
					bank_sub_name_address: this.bank_sub_name_address,
					// card_sn: this.card_sn,
					bank_code: this.bank_code,
					address: this.address,
					type: this.type,
					huobi: this.huobi
				})
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: 'Successfly',
					icon: 'success'
				})
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000);
			},
		},
	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		padding: 50px 0 0;
	}

	.header {
		height: 55px;
		background: #fff;
		box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, .1);
		padding: 0 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			position: absolute;
			top: 18px;
			left: 16px;
			width: 10px;
			height: 18px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #333;
			text-align: center;
		}
	}

	.bankInfo-box {
		padding: 16px;
		background: #fff;
	}

	.list {
		padding: 0 22px;
		margin-bottom: 16px;
		height: 48px;
		background: #f6f6f6;
		border-radius: 24px;
	}

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #1c4199;
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
		// background: #f5f5f5;

		.bank-name {
			padding: 0 22px;
			margin-bottom: 16px;
			height: 48px;
			background: #f6f6f6;
			border-radius: 24px;

			view {
				width: 22%;
			}

			input {
				margin-left: 60rpx;
				font-weight: 400;
				font-size: 28rpx;
			}
		}

		.xian {
			height: 2rpx;
			width: 100%;
			background: #fff;
		}
	}

	.purchase {
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color: #1c4199;
		margin: 100rpx 30rpx;
		border-radius: 24px;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		// font-weight: 600;
		font-size: 28rpx;
	}
</style>