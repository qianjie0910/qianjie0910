<!-- 실시간 이체 -->
<template>
	<view style="background-color: #FFFFFF;min-height: 100vh;">
		<view style="background-color: #FF6700;border-radius: 0 0 12px 12px;">
			<HeaderSecond :title="$lang.PAGE_TITLE_WITHDRAW" color="#FFFFFF"></HeaderSecond>

			<view style="display: flex;align-items: center;justify-content: center;line-height: 1.8;">
				<view style="padding-left: 10px;color:#FFFFFF;font-size: 32rpx;">{{$lang.TIP_AMOUNT_AVAIL}}</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: 10px;">
				</image>
			</view>
			<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;text-align: center;line-height: 1.8;">
				{{showAmount?$util.formatMoney(userInfo.money):hideAmount}}
			</view>

			<view :style="{backgroundColor:$util.RGBConvertToRGBA('#FFFFFF',80)}"
				style="display: flex;align-items: center;justify-content: space-between;padding:10px 40px;line-height: 2.4;color:#FF6700;font-size: 28rpx;">
				<view>{{$lang.WITHDRAW_AMOUNT}}</view>
				<view>{{showAmount?$util.formatMoney(userInfo.totalZichan) :hideAmount}}</view>
			</view>

		</view>


		<view style="padding:20px;margin-top: 10px;margin-bottom: 20px;">
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.WITHDRAW_WITH_AMOUNT}}
			</view>
			<view class="common_input_wrapper"
				style="background-color: #FFFFFF;border: 1px solid #E8EAF3;padding-left: 30px;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;"></input>
				<!-- <view @click="handleAllAmount(userInfo.money)" class="btn_small">{{$lang.TIP_AMOUNT_ALL}}</view> -->
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.WITHDRAW_PAY_PWD}}
			</view>
			<view class="common_input_wrapper"
				style="background-color: #FFFFFF;border: 1px solid #E8EAF3;margin-bottom: 30px;padding-left: 30px;">
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
					:placeholder-style="$util.setPlaceholder()" style=""></input>
			</view>

			<view class="access_btn" style="margin:20px auto; width: 90%;background-color: #FF6700;"
				@click="handleWithdraw()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>


		<view style="margin:10px; padding: 20px;" :style="{color:$theme.TITLE}">
			<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;" :style="{color:index==5?'#FF6700' :$theme.TITLE}">
					{{item}}
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getAccountInfo()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			async handleWithdraw() {
				const result = await this.$http.post(`api/app/withdraw`, {
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				})
				if (!result) return false;
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 500)
			},
			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
			}
		},
	}
</script>