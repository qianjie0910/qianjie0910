<template>
	<view :style="$theme.setBGSize(`480rpx`)">
		<HeaderPrimary :title="$lang.TABBAR_HOME" isLang></HeaderPrimary>

		<view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/home_banner.png" mode="aspectFit" :style="$theme.setImageSize(800,300)"></image>
		</view>

		<view class="common_block">
			<ButtonGroup></ButtonGroup>
		</view>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view class="center_card">
				<view class="padding-10">
					<view class="flex">
						<view class="flex-3">
							<view class="flex gap5">
								<view class="bold font-size-16">Experience</view>
							</view>
							<view class="flex margin-top-10 gap5">
								<view class="bold font-size-18">13.12%～15.06%</view>
								<view class="bold font-size-12">Estimated</view>
							</view>
						</view>
						<view class="flex justify-end flex-1" style="width: 100%;">
							<image src="/static/home_top3.png" mode="widthFix" style="width: 60px;height: 60px;">
							</image>
						</view>
					</view>

					<view style="color: #00AA98;" class="margin-top-5">New User Benefits</view>
					<view
						style="color: #fff;background-color: #00AA98;width: 60%;margin-left: 20%;height: 30px;line-height: 30px;"
						class="margin-top-20 radius30 text-center" @click="licai()">Invest Now</view>
				</view>
			</view>
		</view> -->
		<view style="padding:10rpx 20rpx;">
			<CustomTitle title="Financial Management">
				<view style="font-size: 14px;margin-left: auto;" @click="linkMarket()" :style="{color:$theme.PRIMARY}">
					{{$lang.MORE}}
				</view>
			</CustomTitle>


			<!-- 本示例未包含完整css，获取外链css请参考上文，在hello uni-app项目中查看 -->
			<template>
				<view>
					<view>
						<scroll-view class="scroll-view_H " scroll-x="false" @scroll="scroll()" @click="home()">
							<block v-for="(item,index) in list.slice(1,4)" :key="index">
								<view id="demo1" class="scroll-view-item_H uni-bg-red"
									style="background-image: url(/static/home_licai.png);margin: 15px;background-size: cover;
		background-position: center;
		background-repeat: no-repeat;">
									<view class="flex">
										<view class="flex-2 bold" style="padding: 5px;margin: 10px;font-size: 18px;">
											{{item.name}}
										</view>
										<template v-if="item.is_new==1">
											<view class="flex-1 text-center"
												style="background-color: #ccf0de;padding: 2px;margin: 5px 15px;border-radius: 5px;">
												{{$lang.TRADE_WEALTH_NEW_USERS}}
											</view>
										</template>
									</view>
									<view class="flex">
										<view class="flex-2" style="padding: 0px 15px;color: #666666;">
											{{$lang.LICAI_YUGUSHOUYILV}}</view>
										<view class="flex-1" style="color: #00AA98;margin: 0px 15px;">{{item.syl}}
										</view>
									</view>
									<view class="flex">
										<view class="flex-2" style="padding: 0px 15px;color: #666666;">
											{{$lang.LICAI_ZHOUQI}}</view>
										<view class="flex-1" style="margin: 5px -60px;">
											{{item.zhouqi +$lang.TRADE_WEALTH_CYCLE_UNIT}}</view>
									</view>
									<view class="flex">
										<view class="flex-2" style="padding: 0px 15px;color: #666666;">
											{{$lang.LICAI_ZUIDIMAIRU}}</view>
										<view class="flex-1" style="margin: 5px -60px;">{{item.min_price}}</view>
									</view>
								</view>
							</block>
						</scroll-view>
					</view>
				</view>

			</template>

		</view>

		<view style="padding:10rpx 40rpx;">
			<CustomTitle :title="$lang.COIN_LIST_TITLE">
				<view style="font-size: 14px;margin-left: auto;" @click="home0()" :style="{color:$theme.PRIMARY}">
					{{$lang.MORE}}
				</view>
			</CustomTitle>
		</view>

		<view style="background-color:#FFFFFF;border-radius: 30px 30px 0 0;padding-top: 20px;">
			<GoodsList ref="goods"></GoodsList>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderPrimary,
			ButtonGroup,
			GoodsList,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				info: {}, // 基本信息
				scrollTop: 0,
				list: [],
				old: {
					scrollTop: 0
				}
			}
		},
		computed: {
			setInfo() {

				if (this.info && this.info.userinfo) {
					console.log(this.info, this.info.userinfo);
					return {
						teamNum: this.info.team_num, // 团队人数
						// level_mx 后端直接返回是否达标结果
						l1Pass: this.info.level_mx.if_l1, // L1团队人数是否达标
						l1PassMoney: this.info.level_mx.if_l1_licai_money, // L1理财金额是否达标
						l2Pass: this.info.level_mx.if_l2, // L2团队人数是否达标						
						holdMoneyPass: this.info.level_mx.if_licai_money, // 自身持有金额是否达标
						// 距 下一等级
						// 自身持有金额(目标)
						holdMoney: this.$util.formatMoney(this.info.level_mx.level_up_info.licai_money, 0),
						l1TeamNum: this.info.level_mx.level_up_info.l1, // L1 团队人数(目标)
						// L1 理财金额(目标)
						l1Money: this.$util.formatMoney(this.info.level_mx.level_up_info.l1_licai_money, 0),
						l2TeamNum: this.info.level_mx.level_up_info.l2, // L2 团队人数(目标)
						// L2 理财金额(目标)
						l2Money: this.$util.formatMoney(this.info.level_mx.level_up_info.l2_licai_money, 0),
						// 用户的当前等级数据
						// 当前自身持有金额
						curHoldMoney: this.$util.formatMoney(this.info.level_mx.licai_money, 0),
						curL1TeanNum: this.info.level_mx.l1, // 当前L1团队人数
						// 当前L1团队总金额
						curL1Money: this.$util.formatMoney(this.info.level_mx.l1_licai_money, 0),
						curL2TeanNum: this.info.level_mx.l2, // 当前L2团队人数
						// 当前L2团队总金额					
						curL2Money: this.$util.formatMoney(this.info.level_mx.l2_licai_money, 0),
						curLevel: this.info.userinfo.level, // 用户的当前等级
					}
				}
			}
		},

		onShow() {
			this.getAccountInfo();
			setTimeout(function() {
				this.$refs.goods.getList();
			}, 2000);

		},
		onLoad() {
			this.getLevelInfo();
			this.getList();
		},

		onHide() {
			this.closeAll();
		},
		onUnload() {
			this.closeAll();
		},
		deactivated() {
			this.closeAll();
		},
		methods: {
			licai() {
				uni.switchTab({
					url: "/pages/trade/wealth/index"
				})
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleInfo(item) {
				console.log(item);
				this.infos = item;
				this.isShow = true;
			},
			// 跳转到市场
			linkMarket() {

				uni.switchTab({
					url: '/pages/trade/wealth/index',
				})
			},
			home() {

				uni.switchTab({
					url: '/pages/trade/wealth/index',
				})
			},
			home0() {

				uni.switchTab({
					url: '/pages/market/index',
				})
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},
			async getLevelInfo() {
				const result = await this.$http.get(`api/user/tuandui`);
				if (!result) return false;
				this.info = result;

			},
			// 关闭所有 。websocket 与 http
			closeAll() {
				if (this.$refs.goods) this.$refs.goods.disconnect();
			},
			upper: function(e) {
				console.log(e)
			},
			lower: function(e) {
				console.log(e)
			},
			scroll: function(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			goTop: function(e) {
				// 解决view层不同步的问题
				this.scrollTop = this.old.scrollTop
				this.$nextTick(function() {
					this.scrollTop = 0
				});
				uni.showToast({
					icon: "none",
					title: "纵向滚动 scrollTop 值已被修改为 0"
				})
			},
			//获取EA列表
			async getList() {
				const result = await this.$http.get(`api/jijin/list`);
				if (!result) return false;
				this.list = result;
			},
			async getLevelInfo() {
				const result = await this.$http.get(`api/user/tuandui`);
				if (!result) return false;
				this.info = result;

			},
			// 
			async getAccountInfo() {

				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.info = {
					total: result.totalZichan || 0,
					money: result.money || 0,
				};
			}

		},



	}
</script>

<style>
	.scroll-Y {
		height: 300rpx;
	}

	.scroll-view_H {
		white-space: nowrap;
		width: 100%;
	}

	.scroll-view-item {
		height: 300rpx;
		line-height: 300rpx;
		text-align: center;
		font-size: 36rpx;
	}

	.scroll-view-item_H {
		display: inline-block;
		border-radius: 10px;
		width: 80%;
		/* height: 300rpx; */
		/* line-height: 60rpx; */
		/* text-align: center; */
		font-size: 36rpx;
	}
</style>