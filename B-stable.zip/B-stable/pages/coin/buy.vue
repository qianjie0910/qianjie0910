<template>
	<view>
		<view style="background-image: linear-gradient(180deg, #00aa99, transparent);">
			<HeaderSecond :title="info.name"></HeaderSecond>
		</view>
		<view style="background-color: #00aa99;border-radius: 12px;margin:0 16px;">
			<view style="display: flex;padding:10px;">
				<view style="padding-left: 10px;color:#FFFFFF;font-size: 32rpx;">{{$lang.TIP_AMOUNT_AVAIL}}</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="font-size: 64rpx;font-weight: 700;color:#FFFFFF;padding-left: 20px;line-height: 2">
				{{showAmount?$util.formatMoney(userInfo.money):hideAmount}}
			</view>
		</view>

		<view class="common_block" style="padding:20px 10px;margin-top: 0;">
			<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8">
				<view style="margin-left: 10px;" :style="{color:$theme.TEXT}">{{info.name}}</view>
				<view style="font-size: 32rpx;" :style="{color:$theme.TEXT}">
					{{$util.formatCoin(info.current_price)}}
				</view>
				<view :style="$util.setStockRiseFall(info.rate>0)">{{info.rate}}%</view>
			</view>

			<CustomTitle :title="$lang.STOCK_BUY_QUANTITY"></CustomTitle>

			<view class="btns">
				<block v-for="(item,index) in quantityList" :key="index">
					<view class="item"
						style="flex:30%;margin:4px;font-weight: 700;line-height: 60rpx;text-align: center;margin-bottom: 20rpx;border-radius: 6px;"
						:style="$util.setTabSecondActive(curQuantity==item,'#F6F8FC')" @click="chooseQTY(item)">
						{{item}}
					</view>
				</block>
			</view>

			<view class="common_input_wrapper" style="background-color:#FFFFFF;border: 1px solid #E8EAF3;">
				<view style="width: 20px;"></view>
				<input v-model="quantity" type="number" :placeholder="$lang.STOCK_BUY_TIP_QUANTITY" @input="handleInput"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<!-- 杠杆数组大于1，视为开启杠杆功能 -->
			<template v-if="leverList.length>1 && isBuy">
				<CustomTitle :title="$lang.LEVER"></CustomTitle>
				<view class="btns">
					<block v-for="(item,index) in leverList" :key="index">
						<view class="item"
							style="flex:10%;margin:4px;font-weight: 700;line-height: 60rpx;text-align: center;margin-bottom: 20rpx;border-radius: 6px;"
							:style="$util.setTabSecondActive(curLever==item,'#F6F8FC')" @click="chooseLever(item)">
							{{item}}
						</view>
					</block>
				</view>
			</template>

			<CustomTitle :title="$lang.COIN_BAY_SELECT_PRICE_TYPE"></CustomTitle>
			<view class="common_input_wrapper" style="border:none;margin:0 20rpx;">
				<u-radio-group v-model=" radiovalue1" placement="row" @change="groupChange">
					<u-radio :customStyle="{marginRight: '48rpx'}" v-for="(item, index) in radioList" :key="index"
						:label="item.name" :name="item.name" @change="radioChange" :activeColor="$theme.PRIMARY"
						labelSize="28rpx" :labelColor="item.name==radiovalue1?$theme.PRIMARY:'#CFCFCF' ">
					</u-radio>
				</u-radio-group>
			</view>

			<!-- 限价模式，输入金额 -->
			<template v-if="isShowAmountInput">
				<view class="common_input_wrapper" style="background-color:#FFFFFF;border: 1px solid #E8EAF3;">
					<view style="width: 20px;"></view>
					<input v-model="amount" type="decimal" :placeholder="$lang.COIN_BAY_ENTER_AMOUNT"
						@input="handleInputAmount" :placeholder-style="$util.setPlaceholder()"></input>
				</view>
			</template>

			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				:style="{color:$theme.TEXT}">
				<view>{{$lang.STOCK_BUY_QUANTITY}}</view>
				<view :style="{color:$theme.PRIMARY}">
					{{$util.formatNumber(quantity,0)}}
				</view>
			</view>

			<template v-if="leverList.length>1 && isBuy">
				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
					:style="{color:$theme.TEXT}">
					<view>{{$lang.LEVER}}</view>
					<view :style="{color:$theme.PRIMARY}">
						{{curLever}}
					</view>
				</view>
			</template>

			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				:style="{color:$theme.TEXT}">
				<view>{{$lang.STOCK_BUY_AMOUNT}}</view>
				<view :style="{color:$theme.PRIMARY}">
					{{$util.formatCoin(total)}}
				</view>
			</view>
			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				:style="{color:$theme.TEXT}">
				<view>{{$lang.STOCK_BUY_FEE}}</view>
				<view :style="{color:$theme.PRIMARY}">
					{{$util.formatCoin(total*fee,2)}}
				</view>
			</view>

			<view class="access_btn" style="margin:20px auto; width: 90%;" @click="placeOrder()">
				{{isBuy?$lang.BTN_BUY:$lang.BTN_SELL}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
		},
		data() {
			return {
				showAmount: true, // 显示金额
				hideAmount: '****', // 隐藏金额
				quantityList: [100, 300, 500, 1000, 3000, 5000], // 预置数量
				curQuantity: 100, // 当前选中预置数量
				quantity: 100, // 数量输入框 
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前选中杠杆值
				show: false,
				info: {},
				userInfo: {},
				fee: 1, // 手续费
				// u-radio-group的v-model绑定的值如果设置为某个radio的name，就会被默认选中
				radiovalue1: 'Market Price',
				amount: 1, // 限价模式 输入金额
				socket: null,
				total: 0, // 购买总价
				isBuy: true, // 当前页面是买还是卖
			};
		},
		computed: {
			// 单选项的选项组
			radioList() {
				return [{
					name: 'Market Price',
					disabled: false
				}, {
					name: 'Limit Price',
					disabled: false
				}];
			},
			// 当前交易模式
			isShowAmountInput() {
				return this.radiovalue1 == this.radioList[1].name;
			},
		},
		onLoad(option) {
			console.log(option);
			this.getStockDetail(option.code);
			this.isBuy = option.tag == 0;
			console.log(this.isBuy);
			this.getconfig();
			this.getUserInfo()
		},
		onShow() {},
		onHide() {
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			if (this.socket) this.disconnect();
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 计算总价
			totalAmount() {
				if (this.info) {
					// console.log(this.info.current_price);
					const temp = this.isShowAmountInput ? this.amount : this.info.current_price;
					const temmTotal = temp * 1 * this.curQuantity / this.curLever;
					const result = temmTotal.toString().split('.')[1]?.length || 0;
					this.total = result < 3 ? temmTotal : Number(temmTotal.toFixed(4));
				}
			},
			// 选择数量
			chooseQTY(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
				this.totalAmount();
			},
			// 选择杠杆
			chooseLever(val) {
				this.curLever = val;
				this.totalAmount();
			},
			groupChange(n) {
				console.log('groupChange', n);
				this.radiovalue1 = n;
			},
			radioChange(n) {
				console.log('radioChange', n);
				this.radiovalue1 = n;
			},
			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
	
				this.fee = temp.get('TransRate') || this.fee;
			},

			// 数量输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value);
				this.totalAmount();
			},
			// 限价模式，金额输入值
			handleInputAmount(e) {
				this.amount = Number(e.detail.value);
				this.totalAmount();
			},

			// 产品详情
			async getStockDetail(code) {
				const result = await this.$http.get(`api/product/info`, {
					code: code,
				})
				this.info = result[0];
				this.connect();
				this.amount = this.info.current_price;
				this.totalAmount();
			},

			checkFrom() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.$u.toast(this.$lang.STOCK_BUY_TIP_QUANTITY);
					return false;
				}
				if (this.isShowAmountInput) {
					if (this.amount == '' || this.amount <= 0) {
						uni.$u.toast(this.$lang.COIN_BAY_ENTER_AMOUNT);
						return false;
					}
				}
				return true;
			},

			//购买
			async placeOrder() {
				if (this.checkFrom()) {
					let money = this.$util.formatMoney(this.info.current_price * this.curQuantity * 1)
					const result = await uni.showModal({
						title: this.$lang.STOCK_BUY_CONFIRM,
						content: `${this.info.name} Quantity ${this.$util.formatNumber(this.curQuantity,0)}, ${this.$lang.STOCK_BUY_AMOUNT} ${money}`,
						cancelText: this.$lang.BTN_CANCEL,
						confirmText: this.$lang.BTN_CONFIRM,
						showCancel: true, // 是否显示取消按钮，默认为 true
						confirmColor: this.$theme.PRIMARY,
						cancelColor: '#999999',
					});
					if (result[1].confirm) {
						this.buy();
					}
				}
			},
			async buy() {
				let formData = {
					num: this.quantity,
					gid: this.info.gid,

					// 1市价 2限价
					fx: this.isShowAmountInput ? 2 : 1,
				}
				if (this.isShowAmountInput) {
					formData.price = this.amount;
				}
				if (this.isBuy) {
					// 只有买入需要杠杆
					formData.ganggan = this.curLever;
				}

				const result = await this.$http.post(`api/product/purchase`, formData);
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_TRADE,
					});
				}, 1000)
			},
			// 获取账户信息
			async getUserInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log(result);
				if (!result) return false;
				this.userInfo = result;
				const temp = result.ganggan.map(item => Number(item));
				this.leverList = temp;
			},

			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// check websocket返回的数据，符合当前coin数据时，更新。
					if (this.info.code == data.market && data.lastPrice > 0) {
						// console.log('data:', data);
						this.info.current_price = data.lastPrice || 0;
						this.info.rate = data.rate || 0;
						this.info.rate_num = data.rate_num || 0;
						this.info.vol = data.vol || 0;
						// 如果是市价，跟着websocket 实时计算总价
						if (this.isShowAmountInput)
							this.totalAmount();
					}
				});
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},
		},
	}
</script>

<style>
</style>