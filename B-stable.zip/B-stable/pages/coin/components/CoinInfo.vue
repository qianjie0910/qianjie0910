<template>
	<view class="common_block" style="padding-bottom: 10px;">
		<view style="display: flex;align-items: center;padding: 20px;padding-bottom: 0;">
			<template v-if="info.logo">
				<view style="width: 80rpx;margin:auto 0;">
					<CustomLogo :logo="info.logo" :name="info.name"></CustomLogo>
				</view>
			</template>
			<view style="flex:72%">
				<view style="margin-bottom: 2px;padding:1px 6px;">
					<text style="font-weight: 700;font-size: 32rpx;border-radius: 4px;">{{info.name}}</text>
					<view class="hui"> {{info.ct_name}}</view>
				</view>
			</view>
			<view style="flex:10%;text-align: right;" @click="handleUnFollow(info.gid)">
				<image :src="`/static/${info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
					:style="$util.setImageSize(40)"></image>
			</view>
		</view>

		<view
			style="display: flex;align-items: center;padding: 10px 20px;padding-bottom: 0;justify-content:space-between;"
			:style="$util.setStockRiseFall(info.rate>0)">
			<view style="font-size: 20px; font-weight: 700;">
				{{$util.formatCoin(info.info.lastPrice) }}
			</view>
			<view style="text-align: right; font-size: 20px; font-weight: 700;">
				{{info.info.rate_num}}
			</view>
			<view style="text-align: right; font-size: 20px; font-weight: 700;">
				<image :src="`/static/arrow_${info.info.rate>0?'rise':'fall'}.png`" mode="aspectFit"
					:style="$util.setImageSize(32)" style="margin-right: 10px;"></image>
				{{info.info.rate}}%
			</view>
		</view>

		<!-- 股票信息一些数值的布局方式 之  一行一项 -->
		<view style="background-color: #F8F8F8;padding: 0;margin:10px;">
			<template v-if="info.info && info.info.open">
				<view
					style="display: flex;align-items: center;justify-content: space-between; background-color: #FFF9EB;border-top-left-radius: 10px;border-top-right-radius: 10px;line-height: 30px;padding:0 10px;">
					<view style="color: #666666;">Open</view>
					<view style="color: #333333;font-size: 14px;font-weight: 700;">
						{{$util.formatCoin(info.info.open)}}
					</view>
				</view>
			</template>
			<template v-if="info.info && info.info.close">
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 30px;padding:0 10px;">
					<view style="color: #666666;">Close</view>
					<view style="color: #333333;font-size: 14px;font-weight: 700;">
						{{$util.formatCoin(info.info.close)}}
					</view>
				</view>
			</template>
			<template v-if="info.info && info.info.high">
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 30px;padding:0 10px;">
					<view style="color: #666666;">High</view>
					<view style="color: #333333;font-size: 14px;font-weight: 700;">
						{{$util.formatCoin(info.info.high)}}
					</view>
				</view>
			</template>
			<template v-if="info.info && info.info.low">
				<view
					style="display: flex;align-items: center;justify-content: space-between;background-color: #FFF9EB;line-height: 30px;padding:0 10px;">
					<view style="color: #666666;">Low</view>
					<view style="color: #333333;font-size: 14px;font-weight: 700;">
						{{$util.formatCoin(info.info.low)}}
					</view>
				</view>
			</template>


			<template v-if="info.info && info.info.amount">
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 30px;padding:0 10px;">
					<view style="color: #666666;">Trade Amount</view>
					<view style="color: #333333;font-size: 14px;font-weight: 700;">
						{{$util.formatCoin(info.info.amount)}}
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'CoinInfo',
		components: {
			CustomLogo
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},

		computed: {},
		created() {
			// console.log(`stock info:`, this.info);
		},
		methods: {
			// 取关
			async handleUnFollow(id) {
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				})
				this.info.is_collected = this.info.is_collected == 1 ? 0 : 1;
			},
		}
	}
</script>

<style>
</style>