<template>
	<view>
		<view class="common_mask" @click="actionEvent()"></view>
		<view class="common_popup" style="min-height:35vh;margin:auto">
			<view class="popup_header" :style="{backgroundColor:$theme.PRIMARY}">
				{{info.title}}
				<image src="/static/close_light.png" mode="aspectFit" :style="$theme.setImageSize(40)"
					style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);" @click="actionEvent()">
				</image>
			</view>
			<view style="padding-bottom: 30rpx;">
				<view style="display: flex;align-items: center;justify-content: space-around;line-height: 3;">
					<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">24H:
						{{$util.formatNumber(info.vol,0)}}
					</view>
					<view style="font-size: 32rpx;font-weight: 700;color:#157EFB;"
						:style="$theme.setStockRiseFall(info.rate*1>0)">
						{{$util.formatCoin(info.price)}}
					</view>
					<view style="font-size: 28rpx;color:#157EFB;" :style="$theme.setStockRiseFall(info.rate*1>0)">
						{{info.rate}}%
					</view>
				</view>

				<view class="common_input_wrapper" style="margin:30rpx 40rpx;border: 1px solid #CFCFCF;">
					<view style="width: 40rpx;"></view>
					<input v-model="quantity" :placeholder="$lang.COIN_VIEW_ENTER_QUANTITY" type="number"
						style="width: 80%;" :placeholder-style="$theme.setPlaceholder()"></input>
					<view style="padding:0 4px;color: #999;">{{$lang.COIN_VIEW_UNIT}}</view>
				</view>

				<view
					style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:20rpx 50rpx;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_VIEW_PAYMENT_AMOUNT}}</view>
					<view style="color:#157EFB;"> {{$util.formatMoney(payAmount,4) }} </view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between; padding:20rpx 50rpx;">
					<view style="padding-right: 10px;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.COIN_VIEW_AVAILABLE_AMOUNT}}
					</view>
					<view :style="{color:$theme.LOG_LABEL}">{{available }}</view>
				</view>

				<view class="access_btn" @tap.stop="handleConfirm()" style="margin:60rpx auto;width: 80%;">
					{{curBtn}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		postStockBuy,
		userFastInfo,
	} from '@/common/api.js';
	export default {
		name: 'CoinTradeModal',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: true,
				quantity: "", // 金额
				available: 0,
			}
		},
		computed: {
			// 买卖 当前按钮明文
			curBtn() {
				console.log([this.$lang.BTN_BUY,
					this.$lang.BTN_SELL
				])
				return [this.$lang.BTN_BUY,
					this.$lang.BTN_SELL
				][this.info.type]
			},
			// 金额计算
			payAmount() {
				return this.info.price * this.quantity;
			},
			// 二次弹层确认的内容
			setContent() {
				const total = (this.info.price * this.quantity).toFixed(4);
				return `${this.$lang.COIN_MODAL_COMFIRM} ${this.info.name}, ${this.quantity} ${this.$lang.COIN_VIEW_UNIT}, ${this.$lang.COIN_VIEW_PAYMENT_AMOUNT} ${this.$util.formatMoney(total)}, ${this.$lang.COIN_MODAL_WANT_TO} ${this.curBtn} ?`;
			}
		},
		created() {
			console.log(`modal:`, this.info);
			console.log(`modal:`, this.info.type);
			this.gerUserInfo();
		},
		methods: {
			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);
			},
			// 买卖事件
			async handleConfirm() {
				if (this.checkForm()) {
					const result = await uni.showModal({
						title: '',
						content: this.setContent,
						cancelText: this.$lang.COIN_MODAL_CANCEL,
						confirmText: this.$lang.COIN_MODAL_COMFIRM,
						confirmColor: this.$theme.PRIMARY,
						cancelColor: '#999999',
					});
					console.log('异步弹层:', result);
					if (result[1].confirm) {
						this.trade();
					}
				}
			},
			checkForm() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.showToast({
						title: this.$lang.COIN_VIEW_ENTER_QUANTITY,
						icon: 'none',
					});
					return false;
				}
				return true;
			},
			// 二次确认后，执行的买卖事件
			async trade() {
				const result = await postStockBuy({
					num: this.quantity,
					gid: this.info.gid,
				});
				console.log('result:', result);
				// if (!result) return false;
				if (result && result.code == 0) {
					uni.$u.toast(result.data.message);
					this.actionEvent();
					setTimeout(() => {
						// 买卖成功，跳转到个人交易中心
						uni.reLaunch({
							url: this.$paths.ACCOUNT_TRADE
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			// 获取可用余额
			async gerUserInfo() {
				const result = await userFastInfo();
				console.log(result);
				if (result && result.code == 0) {
					this.available = this.$util.formatMoney(result.data.money || 0);
					console.log('available:', this.available);
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>