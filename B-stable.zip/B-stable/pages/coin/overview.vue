<template>
	<view>
		<view style="background-image: linear-gradient(180deg, #00aa99, transparent);">
			<HeaderSecond :title="setTitle"></HeaderSecond>
		</view>
		<view style="padding-top: 1vh;padding-bottom: 20px;">
			<template v-if="info">
				<CoinInfo :info="info"></CoinInfo>

				<view class="common_block" style="padding:15px;">

					<view :style="{display:curTab==0?'block':'none' }">
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px;">
							<block v-for="(item,index) in tabs" :key="index">
								<view
									style="flex:25%;text-align: center;font-size: 30rpx;margin:4px;padding:10px 20px;border-radius: 10px;"
									:style="{color:curKLine==index? '#FFFFFF':'#666666', backgroundColor:curKLine==index?'#00aa99':'#F6F8FC'}"
									@click="handleShowKLine(index)">
									{{item}}
								</view>
							</block>
						</view>
						<view class="chart" id="chart-type-k-line" style="width: 103%;height: 500rpx;">
						</view>
					</view>

					<view style="display: flex; align-items: center;justify-content: space-around;">
						<view class="access_btn" style="margin:20px auto; width:40%;" @click="purchase(0)">
							{{$lang.BTN_BUY}}
						</view>
						<view class="access_btn" style="margin:20px auto; width: 40%;" @click="purchase(1)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CoinInfo from './components/CoinInfo.vue';
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts';

	export default {
		components: {
			HeaderSecond,
			CoinInfo,
			// CoinTradeModal,
		},
		data() {
			return {
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				info: null, // 单股信息，
				kLineChart: null, // Kline实例化
				curKLine: 0, // 当前显示的Kline数据图标
				timer: null,
				socket: null,
				isShow: false, // 是否显示弹层(买卖共用弹层)
				curType: 0, // 当前弹层模式[0买|1卖]
				modalInfo: {}, // 弹层中的数据
				temp: {}
			};
		},
		computed: {
			// header title
			setTitle() {
				if (this.info) {
					return this.info.name || 'Detail';
				}
			},
			tabs() {
				return [this.$lang.COIN_VIEW_TAB_MINUTE,
					this.$lang.COIN_VIEW_TAB_DAILY,
					this.$lang.COIN_VIEW_TAB_MONTHLY
				];
			}
		},

		onLoad(option) {
			console.log(option);
			this.code = option.code || '';
			// this.lastPrice();
		},
		onShow() {
			console.log('stock onShow:', this.curTab)
			this.getData();
		},
		onHide() {
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			if (this.timer) this.clearTimer();
			if (this.socket) this.disconnect();
		},
		methods: {
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
			},
			xau_connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Xau_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// 
					// check websocket返回的数据，符合当前coin数据时，更新。
					// console.log('data:', data);
					let xau_data = [];
					xau_data.lastPrice = data.last;
					xau_data.rate = data.pcp;
					xau_data.rate_num = data.pc;

					this.info.info = xau_data;

					const now = new Date();
					// 将秒数和毫秒数设为0，获取当前分钟的时间
					now.setSeconds(0);
					now.setMilliseconds(0);

					// 获取当前分钟的毫秒值
					let currentMinuteMilliseconds = now.getTime();

					const temp = {
						close: data.last*1,
						high: this.temp.high,
						low: this.temp.low,
						open: this.temp.open,
						timestamp: currentMinuteMilliseconds,
						turnover: 0
					};
					console.log(temp);

					this.temp = temp;
					this.kLineChart.updateData(temp);

				});
			},
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// 
					// check websocket返回的数据，符合当前coin数据时，更新。
					if (this.info.code == data.market && data.lastPrice > 0) {
						// console.log('data:', data);
						this.info.info = data;

						// 	当前k线在分钟走势图，且当前回执数据type='kline'时， 执行以下逻辑		
						if (this.curTab == 0 && data.type == "kline") {
							// 创建一个Date对象，使用该时间戳创建
							let date = new Date(data.time);
							// 获取当前分钟的起始毫秒时间戳
							let currentMinuteStart = new Date(date.getFullYear(), date.getMonth(), date.getDate(),
								date.getHours(), date.getMinutes(), 0, 0).getTime();
							console.log(currentMinuteStart);

							const temp = {
								close: data.close,
								high: data.high,
								low: data.low,
								open: data.open,
							};
							this.temp = temp;
							this.kLineChart.updateData(temp);
						} else {
							this.temp.close = data.lastPrice;
							this.kLineChart.updateData(this.temp);
						}
					}
				});
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			handleShowKLine(val) {
				this.disconnect();
				this.curKLine = val;
				this.getData();
			},

			kLineInit() {
				this.kLineChart.setStyles({
					"candle": {
						"type": "candle_solid",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: this.$theme.PRIMARY,
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#ffbfb9'
							}, {
								offset: 1,
								color: this.$theme.PRIMARY,
							}]
						},
						bar: {
							upColor: '#00aa99',
							downColor: '#F92855',
							noChangeColor: '#888888',
							upBorderColor: '#00aa99',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#888888',
							upWickColor: '#00aa99',
							downWickColor: '#F92855',
							noChangeWickColor: '#888888'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);
			},

			// 买入 卖出
			purchase(val) {
				// 0:币买入 1:币卖出
				console.log(`val:`, val);
				this.curType = val;
				// 如果是 isCoin 且操作卖出
				uni.navigateTo({
					url: `${ this.$paths.COIN_BUY}?code=${this.code}&type=${this.info.project_type_id}&tag=${this.curType}`
				});
			},

			// 产品详情
			async getData() {
				const result = await this.$http.get(`api/product/info`, {
					code: this.code,
					time_index: this.curKLine
				});
				console.log(result);
				if (!result) return false;
				this.info = result[0];
				console.log(`info:`, this.info);
				console.log(this.info.project_type_id);

				// 当前实时更新模式
				if( result[0].project_type_id==1){
					this.connect();
				}else{
					this.xau_connect();
				}

				// 延时,等DOM渲染
				setTimeout(() => {
					if (!this.kLineChart) {
						this.kLineChart = init('chart-type-k-line');
						this.kLineInit(); // 初始化Kline
					}
					this.genKLineData(); // 获取并生成KLine数据	
				}, 50);
			},

			// 获取并生成KLine数据
			async genKLineData() {
				const result = await this.$http.get(`api/product/lishi`, {
					ac_time: this.curKLine,
					project_type_id: this.info.project_type_id,
					code: this.info.code
				})
				console.log('k data:', result);
				if (!result) return false;
				this.kLineChart.setStyles({
					"candle": {
						"type": this.curKLine == 0 ? "candle_solid" : "candle_solid",
					},
				});
				const temp = {
					close: result[result.length-1].close,
					high: result[result.length-1].high,
					low: result[result.length-1].low,
					open: result[result.length-1].open,
					timestamp: result[result.length-1].timestamp,
					turnover: result[result.length-1].turnover,
				};

				this.temp = temp;
				this.kLineChart.setPriceVolumePrecision(this.info.shudian, 0)
				this.kLineChart.applyNewData(result)
			},
		},
	}
</script>

<style>
</style>