import Vue from 'vue';

// 客服跳转
const linkService = async () => {
	const result = await Vue.prototype.$http.get(`api/app/config`);
	console.log('reslut:', result);
	console.log('window:', window);
	console.log('navigator:', navigator);
	// "CustomerLink"
	if (result.code == 0) {
		const temp = result.data.reduce((map, item) => {
			map.set(item.key, item.value);
			return map;
		}, new Map());

		let url = temp.get('CustomerLink');

		if (window.android) {
			window.android.callAndroid("open," + url)
			return false;
		}
		if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
			.nativeExt) {
			window.webkit.messageHandlers.nativeExt.postMessage({
				msg: 'open,' + url
			})
			return false;
		}
		let u = navigator.userAgent;
		let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
		if (isiOS) {
			window.location.href = url;
			return false;
		}
		window.open(url)
	}
}

/*
跳转到客服，内部分为两种方式：
1. 直接跳转到软件内客服页面
2. 调用客服跳转函数，用于上架
*/
const linkCustomerService = () => {
	// 1. 直接跳转到软件内客服页面
	// uni.navigateTo({
	// 	url: Vue.prototype.$paths.SERVICE
	// });

	// 2.调用客服跳转函数，用于上架
	linkService();
}

// 计算设计图上带有透明度的值输出为RGBA
const RGBConvertToRGBA = (hexColor, opacity) => {
	const r = parseInt(hexColor.slice(1, 3), 16);
	const g = parseInt(hexColor.slice(3, 5), 16);
	const b = parseInt(hexColor.slice(5, 7), 16);
	const a = opacity / 100;
	return `rgba(${r},${g},${b},${a})`;
};

// 是否为小数
const hasDecimalPoint = (val) => {
	return val % 1 !== 0;
};

// 数字值格式化
const formatNumber = (value, fixed = 4) => {
	if (isNaN(value)) return '0';
	let result = Number(value).toFixed(fixed);
	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return result;
};

// 涨跌值样式设置
const setStockRiseFall = (val, isbg = false) => {
	return {
		color: isbg ? '#FFFFFF' : val ? Vue.prototype.$theme.RISE : Vue.prototype.$theme.FALL,
		backgroundColor: !isbg ? '' : val ? Vue.prototype.$theme.RISE : Vue.prototype.$theme.FALL,
	}
};

// 负数取绝对值
const formatMathABS = (val) => {
	return Math.abs(val);
}

// 对象嵌套转数组对象。当前用于市场指标返回数据，将其从对象转为数组对象
const ObjectConvertArray = (obj) => {
	return Object.values(obj);
};

// Coin格式化，数据无损输出
const formatCoin = (coin, decimal = '') => {
	coin = isNaN(coin) ? 0 : Number(coin);
	// console.log(`coin:`, coin);
	// 计算小数点后面的位数
	const temp = coin.toString().split('.')[1]?.length || 0;

	const curLocale = 'en-US';
	const result = new Intl.NumberFormat(curLocale, {
		// 如果传入数字包含小数。则启用小数位数
		minimumFractionDigits: decimal > 0 ? decimal : temp, // 小数位数
		maximumFractionDigits: decimal > 0 ? decimal : temp, // 小数位数
	}).format(coin);
	// console.log('格式化：', result);
	return result;
};

// 金额值格式化(参数：金额，小数位数)
const formatMoney = (amount, decimal = 2) => {
	// 处理传入值为数字类型
	amount = isNaN(amount) ? 0 : Number(amount);
	// console.log(amount);
	const curLocale = 'en-US';
	const result = new Intl.NumberFormat(curLocale, {
		style: 'decimal', // 不包含货币符号。currency:包含货币符号
		// 如果传入数字包含小数。则启用小数位数
		minimumFractionDigits: hasDecimalPoint(amount) ? decimal : 0, // 小数位数
		maximumFractionDigits: hasDecimalPoint(amount) ? decimal : 0, // 小数位数
		currency: Vue.prototype.$CURRENCY
	}).format(amount);
	// console.log('格式化：', result);
	return result;
}

export default {
	linkService,
	linkCustomerService,
	RGBConvertToRGBA,
	ObjectConvertArray,
	formatNumber,
	setStockRiseFall,
	formatMathABS,
	formatCoin,
	formatMoney,

	// 切换底部导航文字多语言
	switchTabBar: () => {
		const TABBAR = [
			Vue.prototype.$lang.TABBAR_HOME,
			Vue.prototype.$lang.TABBAR_FOLLOW,
			Vue.prototype.$lang.TABBAR_MARKET,
			Vue.prototype.$lang.TABBAR_TRADE,
			Vue.prototype.$lang.TABBAR_ACCOUNT
		];
		// 遍历底部导航，逐一换成当前语言
		for (let i = 0; i <= 5; i++) {
			uni.setTabBarItem({
				index: i,
				text: TABBAR[i],
			})
		}
	},

	// 设置input的placeholder样式
	setPlaceholder: (color = '', fontsize = '') => {
		return `color:${color == '' ? Vue.prototype.$theme.PLACEHOLDER : color};font-size:${fontsize==''?24:fontsize}rpx`;
	},

	// 设置图片尺寸（自定义size）
	setImageSize: (w = 0, h = 0) => {
		const _w = w > 0 ? w : 20;
		const _h = h > 0 ? h : _w;
		return {
			width: `${_w}rpx`,
			// 若为设置h值，则视为高=宽
			height: `${_h}rpx`,
		};
	},
	// 设置页面背景,返回style对象，动态替换页面背景图
	setPageBG: (url) => {
		return {
			backgroundImage: `url(/static/${url}.png)`,
			backgroundSize: '100% auto',
			backgroundRepeat: 'no-repeat',
			backgroundPosition: '0 -32rpx',
		}
	},

	// 根据传入值，求出进度条元素宽度
	setProgress: (val, max) => {
		// 模拟数据所需，实际数据不会出现
		const result = max - val < 0 ? 0 : (val / max) * 100;
		console.log(result);
		return {
			// backgroundImage: `url(/static/progress.png)`,
			// backgroundSize: 'auto',
			// backgroundRepeat: 'repeat',
			// backgroundPosition: '0 -7px',
			backgroundImage: 'linear-gradient(-90deg, #00aa99, rgba(255,255,255,0.8))',
			width: `${result}%`,
			height: '100%',
			borderRadius: `12px`,
		}
	},

	formatDate: (timeString) => {
		console.log('原值:', timeString);
		const curLang = uni.getStorageSync('lang');
		console.log('当前语言', curLang);
		const opt = {
			year: 'numeric',
			month: 'numeric',
			day: 'numeric',
			hour: 'numeric',
			minute: 'numeric',
			second: 'numeric',
			hour12: false, // 以24小时制处理
		};
		const result = new Intl.DateTimeFormat(curLang, opt).format(timeString);
		console.log('格式化：', result);
		return result;
	},

	// 部分页面需要拼接股票完整LOGO的url
	setLogo: (url) => {
		// console.log('url:', url);
		return url.includes('http') ? url : Vue.prototype.$http.BASE_URL + url;
	},
	// 设置TAB激活状态
	setTabActive: (active = true) => {
		return {
			color: active ? Vue.prototype.$theme.PRIMARY : Vue.prototype.$theme.TIP,
			borderBottom: active ? `3px solid ${ Vue.prototype.$theme.PRIMARY}` : '',
			// backgroundColor: active ? '#03327857' : '',
		}
	},
	setTabSecondActive: (active = true, bg = '') => {
		return {
			color: active ? '#FFFFFF' : '#666',
			backgroundColor: active ? '#00aa99' : bg,
		}
	},
	setTabThird: (active = true) => {
		return {
			color: active ? Vue.prototype.$theme.PRIMARY : Vue.prototype.$theme.TEXT,
			borderBottom: `3px solid ${active ? Vue.prototype.$theme.PRIMARY:'transparent'}`,
		}
	},

	// 设置交易记录中， 提现记录，每条数据状态明文
	setWithdrawLogStatus: (code = 0) => {
		const temp = [{
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[0],
			icon: '/static/audit.png',
			color: '#FF6700'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[1],
			icon: '/static/success.png',
			color: '#00B45A'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[2],
			icon: '/static/failed.png',
			color: '#A400DE'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[3],
			icon: '/static/refuse.png',
			color: '#f56a6a'
		}];
		return temp[code];
	},
}