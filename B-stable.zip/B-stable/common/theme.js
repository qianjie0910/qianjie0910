/* change theme 挂在全局，方便后期做主题切换 */
const PRIMARY = '#00aa99'; //
const RISE = '#00B45A'; // 股票涨
const FALL = '#FF533B'; // 股票跌		
const LABEL = '#666666'; // 列表的标题		
const ACCESS_TEXT = '#FFFFFF'; // 标题文字	
const TITLE = '#666666'; // 		
const STOCK_NAME = '#121212';
const FG = ' #AFAFAF';
const SECONDARY = '#FF8C00';
//const  LABEL= '#F7F7F7';
const TEXT = '#333333'; // D3D3D3
const TIP = '#333333';
const PLACEHOLDER = '#66666652'; // 输入框占位符

// 涨跌值样式设置
const setStockRiseFall = (val, isbg = false) => {
	return {
		color: isbg ? '#FFFFFF' : val ? RISE : FALL,
		backgroundColor: !isbg ? '' : val ? RISE : FALL,
	}
};
// 设置input的placeholder样式
const setPlaceholder = (color = '', fontsize = '') => {
	return `color:${color == '' ? PLACEHOLDER : color};font-size:${fontsize==''?24:fontsize}rpx`;
};

// 设置图片尺寸（自定义size）
const setImageSize = (w = 0, h = 0) => {
	const _w = w > 0 ? w : 20;
	const _h = h > 0 ? h : _w;
	return {
		width: `${_w}rpx`,
		// 若为设置h值，则视为高=宽
		height: `${_h}rpx`,
	};
};

// 渐变设置
const linerGradient = (deg, from, to) => {
	return {
		backgroundImage: `linear-gradient(${deg}deg, ${from} ,${to})`
	}
};


// 设置页面背景,返回style对象，动态替换页面背景图
const setBGCover = (url) => {
	return {
		backgroundImage: `url(/static/${url}.png)`,
		backgroundRepeat: 'no-repeat',
		backgroundPosition: '0 0',
		backgroundSize: 'cover',
		width: '100%',
		height: '100vh',
	}
};


// 另外一种，使用渐变，动态改变background-size的值。
// val:外部设置该值，可以改变背景的size。 
const setBGSize = (val) => {
	return {
		...linerGradient(180, '#00AA98', 'transparent'),
		backgroundRepeat: 'no-repeat',
		backgroundPosition: '0 0',
		backgroundSize: `100% ${val}`,
		width: '100%',
		minHeight: '100vh',
	}
};
// 主题，一些通用的颜色值 硬编码
export default {
	PRIMARY, //
	RISE, // 股票涨
	FALL, // 股票跌		
	LABEL, // 列表的标题		
	ACCESS_TEXT, // 标题文字	
	TITLE, // 		
	STOCK_NAME,
	FG,
	SECONDARY,
	// LABEL: '#F7F7F7',
	TEXT, // D3D3D3
	TIP,
	PLACEHOLDER, // 输入框占位符

	setStockRiseFall,
	setPlaceholder,
	setImageSize,
	setBGCover,
	setBGSize,
};