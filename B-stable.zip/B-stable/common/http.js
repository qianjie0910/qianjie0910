import Vue from 'vue';
import md5 from 'js-md5';

export const HOST = `api.b-stable.top`;
export const BASE_URL = `https://${HOST}`;

// 部分项目使用websocket
export const WS_COIN_URL = `wss://${HOST}/ws`; // 币

export const WS_Xau_URL = `wss://${HOST}/xau`; // 币


// export const BASE_URL = `https://api.b-stable.top`;

// export const wsbiUrl = `wss://api.b-stable.top/ws`;

const CODE = "Qwd3N5yp";


// 统一处理网络状态 在onShow 及 api请求时调用
export const checkNetwork = async () => {
	try {
		const result = await uni.getNetworkType();
		// 返回：[null,{errMsg: 'getNetworkType:ok', networkType: 'unknown'}]
		let [err, res] = result;
		if (!res || res.networkType === 'none') return false;

		return true;
	} catch (err) {
		console.log('err:' + err)
		throw err
	}
}

async function http(url, params = {}) {
	// 发送请求前，检查网络状态
	const result = await checkNetwork();

	if (!result) {
		return {
			message: Vue.prototype.$lang.TIP_NETWORK_TYPE_NONE
		};
	} else {
		const token = uni.getStorageSync("token") || '';
		const headers = {
			"Content-Type": "application/x-www-form-urlencoded",
			// 处理携带token
			"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
			"language": uni.getStorageSync('lang') || 'en', // 'zh-Hans'
		};
		const time = parseInt(new Date().getTime() / 1000);
		const str_url = `/${url}`.toLowerCase();

		const mdd = md5(`XPFXMedS${CODE + str_url + time}`);

		const fmtAPIURL = url.includes('http') ? url : `${BASE_URL}/${url}`;

		try {
			const response = await uni.request({
				url: `${fmtAPIURL}?sign=${mdd}&t=${time}`,
				method: params.method || 'GET',
				data: params.data || {},
				header: headers
			});

			const [err, res] = response;

			if (res && res.statusCode == 200) {
				if (res.data.code === 999) {
					uni.clearStorageSync();
					setTimeout(() => {
						uni.navigateTo({
							url: Vue.prototype.$paths.ACCOUNT_ACCESS
						});
					}, 1000);
					return {
						message: Vue.prototype.$lang.API_TOKEN_EXPIRES
					};
				}
				if (res.data && res.data.code == 0) {
					return res.data.data || null;
				}
				if (!res.data.code) {
					console.log('url:', url);
					uni.showToast({
						title: `status code is undefined`,
						icon: 'none'
					});
				} else {
					uni.showToast({
						title: res.data.message || Vue.prototype.$lang.API_HTTP_ERROR,
						icon: 'none'
					});
					return null;
				}
			} else {
				console.log('err:', err);
				uni.showToast({
					title: res.message || Vue.prototype.$lang.API_HTTP_ERROR,
					icon: 'none'
				})
			}
		} catch (error) {
			console.log('error:', error);
			throw error;
		}
	}
};

// 外部调用，模拟整理前写法。
const get = (url, data = {}) => {
	const params = {
		method: 'GET',
		data,
	}
	return http(url, params)
}

const post = (url, data = {}) => {
	const params = {
		method: 'POST',
		data,
	}
	return http(url, params)
}

export default {
	BASE_URL,
	WS_COIN_URL,
	WS_Xau_URL,
	http,
	get,
	post,
	checkNetwork,
};


// export default async function http(url, params = {}) {
// 	console.log('url:', url, 'params:', params);
// 	const token = uni.getStorageSync("token") || '';
// 	const headers = {
// 		"Content-Type": "application/x-www-form-urlencoded",
// 		// 处理携带token
// 		"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
// 		"language": uni.getStorageSync('lang') || 'en', // 'zh-Hans'
// 	};
// 	const time = parseInt(new Date().getTime() / 1000);
// 	const str_url = `/${url}`.toLowerCase();
// 	const mdd = md5(`XPFXMedS${CODE + str_url + time}`);

// 	try {
// 		if (!params.hide) {
// 			// 默认显示状态
// 			uni.showLoading({
// 				title: params.title || Vue.prototype.$lang.STATUS_REQUEST,
// 			})
// 		}
// 		const response = await uni.request({
// 			url: `${BASE_URL}/api/${url}?sign=${mdd}&t=${time}`,
// 			method: params.method || 'GET',
// 			data: params.data || {},
// 			header: headers
// 		});
// 		if (!params.hide) {
// 			uni.hideLoading();
// 		}
// 		// console.log('response:', response);
// 		let [err, res] = response;
// 		if (res && res.statusCode == 200) {
// 			if (res.data.code === 999) {
// 				uni.clearStorageSync();
// 				uni.$u.toast(Vue.prototype.$lang.API_TOKEN_EXPIRES);
// 				uni.$u.sleep(1000).then(() => {
// 					uni.navigateTo({
// 						url: Vue.prototype.$paths.ACCOUNT_ACCESS
// 					});
// 				})
// 				return false;
// 			}
// 			return res.data;
// 		} else {
// 			uni.$u.toast(Vue.prototype.$lang.STATUS_HTTP_ERROR);
// 		}
// 	} catch (error) {
// 		// console.log(error);
// 		throw error;
// 	}
// };

uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('请求拦截', requestConfig);
	}
})