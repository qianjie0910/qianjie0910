export default {
	TRANSLATE_TITLE: '請選擇語言',
	  // 底部導航
	  TABBAR_HOME: "首頁",
	  TABBAR_FOLLOW: "財務",
	  TABBAR_MARKET: '市場',
	  TABBAR_TRADE: '貿易',
	  TABBAR_ACCOUNT: '帳戶',

	// 账户管理相关 登入、注册
	 SIGN_IN: "登入",
	  SIGN_UP:'建立帳戶',
	  SIMGN_OUT: "退出",
	  GO_TO_SIGN_IN: '前往登入',
	  USER_NAME: '帳戶',
	  ENTER_USER_NAME:'輸入您的電子郵件帳戶',
	  密碼:'密碼',
	  ENTER_PASSWORD: '輸入您的密碼',
	  VERIFY_PASSWORD: '驗證密碼',
	  ENTER_VERIFY_PASSWORD: '輸入您的密碼',
	  INVITATION_CODE: '邀請碼',
	  INT_ATIN_CODE: '關於我們',
	  ENTER_INVITATION_CODE: '輸入您的程式碼',
	  TIP_PWD_NOEQUAL: '兩次輸入的密碼不一致',
	  TIP_SUCCESS_SIGNIN: '登入成功',
	  TIP_SUCCESS_REGISTER: '註冊已完成，請登入',
	  TIP_SIGNIN_ING: '正在登入',
	  TIP_SIGNUP_ING: '正在註冊',
	  TIP_REMEMBER_PWD: '記住密碼',
	  API_TOKEN_EXPIRES: '令牌過期。請重新登入',
	  TIP_SIGN_OUT_SUCCESS: '註銷成功',
	  TIP_AGREE: '我同意',
	  TIP_PRVITE_PACT: '私人與契約',
	  TIP_CHECK_AGREE: '請勾選同意',

	// 变更登入密码、变更支付密码、变更账户信息
	TIP_OLD_PWD: '請輸入原密碼',
	  TIP_NEW_PWD: '輸入新密碼',
	  TIP_NEW_PWD_VERIFY: '再次輸入新密碼',


	// 提款页面
	PAGE_TITLE_WITHDRAW: '撤回',
	  WITHDRAW_AMOUNT: '我的資產',
	  WITHDRAW_TITLE: "提取資金",
	  TIP_AMOUNT_AVAIL: '可用金額',
	  WITHDRAW_WITH_AMOUNT: '提現金額',
	  TIP_AMOUNT_WITHDRAW: '輸入提現金額',
	  WITHDRAW_PAY_PWD: '提幣密碼',
	  TIP_WITHDRAW_PWD: '請輸入付款密碼',
	  WITHDRAWING_POST_TIP: '正在處理......',
	// 提款说明
	WITHDRAW_TIP_TEXT: [`1. 在出售目前持有的股份之前不能撤回。`, `
2. 為了提款，您提款前需要驗證您的實名並驗證您的帳戶。`,
		`3. 提幣交易時間：平日09:00-15:00（週末及公眾假期不允許提幣）。`,
		`4. 請求提款的最低金額為 10,000 。`,
		`5. 申請提款後，原則上當日存入指定提款帳戶。`,
		`※ 付款最多會在2個工作天（48小時）內完成。`
	],

	// 入金页面
	PAGE_TITLE_DEPOSIT: '存款',
	  PAGE_TITLE_DE: '綁定帳戶',
	  DEPOSIT_TIP_DEPOSIT_AMOUNT: '輸入儲值金額',
	  DEPOSIT_TIP_LOW_AMOUNT: '最低 1,000,000',
	  DEPOSIT_POST_TIP: '正在處理......',
	  DEPOSIT_TIP_TITLE: '友誼提醒',
	  DEPOSIT_UPLOAD_TITLE:'上傳圖片',
	DEPOSIT_TIP_TEXT: ['1. 儲值時間：平日09:00~18:00，假日休息。',
		'感謝您選擇我們。為確保您的資金安全，請確保您要轉帳的帳戶是我們平台即時顯示的帳戶，並且每次從非銀行帳戶轉帳時請與我們的工作人員核實。帳戶即時顯示在我們的平台上，您應對因存款而產生的任何損失負責。'
	],

	// 个人中心页面
	ACCOUNT_CHANGE_PWD: '更改登入密碼',
	  ACCOUNT_TRADE_LOG: '資金流向',
	  ACCOUNT_SERVICE: '服務',
	  ACCOUNT_AMOUNT_TOTAL: '總資產',
	  ACCOUNT_AMOUNT_AVAILABLE: '可用資金',
	  ACCOUNT_MORE_FEATURES: '更多功能',

	// 交易记录页面
	TRADE_LOG_BTNS: ['詳情', '儲值', '提款'],
	  TRADE_LOG_TIP_MODAL_TITLE: '您確定要取消提款要求嗎？',
	  TRADE_LOG_WITHDRAW_STATUS: ['審核中', '提現成功',
	  '提現失敗，請聯絡客服', '拒絕'
	  ],
	LOG_TRADE_AMOUNT_BEFORE: '交易前餘額',
	  LOG_TRADE_AMOUNT_AFTER: '交易後餘額',
	  LOG_TRADE_DW: '交易金額',
	  LOG_TRADE_CREATE_TIME: '時間',
	  LOG_TRADE_DESC: '詳細資料',
	  LOG_TRADE_ORDER_SN: '訂單SN',
	  LOG_TRADE_DW_DESC: '交易描述',
	  LOG_WITHDRAW_AMOUNT: '提現金額',
	  LOG_STATUS: '狀態',


	// 交易页面
	TRADE_TITLE: '投資結果',
	  TRADE_TABS: ['持有記錄', '賣出記錄'],
	  TRADE_TOTAL_BUY_AMOUNT: '總購買量',
	  TRADE_VALUATION_GAIN_LOSS: '利潤與損失',
	  TRADE_VALUATION_GAIN_LOSS_AMOUNT: '評估金額',
	  TRADE_RATE_RESPONSE: '回應率',
	  TRADE_TOTAL_GAIN: '總利潤',
	  //持倉和賣出的記錄表頭
	  TRADE_LIST_THEAD: ['名稱', '收益', '持有數量', '評估', '價格', '價格'],
	  TRADE_MOADL_TITLE: '訂單',
	  // 訂單的標籤組
	  TRADE_MODAL_LABELS: ['名稱', '買入時間', '賣出時間', '利潤', '槓桿', '總利潤', '價格', '數量', '費用',
	  '總金額', '代碼'
	  ],
	// 卖出的二次确认
	SELL_TIP: 'Confirm sale?',


	// IPO 交易
	SELL_TIP: '確認出售？ ',
	
	
	  // 首次公開發行交易
	  PAGE_TITLE_TRADE_IPO:'首次公開發行',
	  TRADE_IPO_TABS: ['商品', '記錄', '成功'],
	  TRADE_IPO_MODAL_TITLE: '公開發行股票認購申請',
	  TRADE_IPO_MODAL_CONTENT: '如果您要申請認購，請點選確認',
	  TADE_IPO_SUB_PRICE: '認購',
	  TRADE_IPO_PE_RATE: '本益比',
	  TRADE_IPO_SUB_CT: '申購時間',
	  TRADE_IPO_POST_QTY: '流通量',
	  TRADE_IPO_RAISE_MONEY: '籌資',
	  TRADE_IPO_LOG_LABELS: ['申購價','市盈率','申購時間','週期'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO申購成功記錄',
	  TRADE_IPO_SUCCESS_APPLY_AMOUNT: '認購數量',
	  TRADE_IPO_SUCCESS_AMOUNT: '獲勝',
	  TRADE_IPO_SUCCESS_NUM_AMOUNT: '金額',
	  TRADE_IPO_SUCCESS_ORDER_SN: '訂單編號',
	  TRADE_IPO_SUCCESS_CT: '日期時間',


	// 单股详情页面
	PAGE_TITLE_STOCK_OVERVIEW: '庫存詳情',
	  // 股票最新數值
	  STOCK_INFO_TITLES: ['市價', '收盤價', '最高價', '最低價', '交易量',
	  '交易金額'
	  ],
	  // 股票K線TABS
	  STOCK_OVERVIEW_KLINE_TABS: ['分鐘', '日', '月亮'],
	  // 單股購買頁面
	  STOCK_BUY_QUANTITY: '數量',
	  STOCK_BUY_TIP_QUANTITY: '輸入數量',
	  STOCK_BUY_AMOUNT: '付款金額',
	  STOCK_BUY_FEE: '費用',
	  STOCK_BUY_CONFIRM: '購買',

	槓桿:'槓桿',
	  STOCK_ALL: '庫存清單',
	  STOCK_FOLLOW: '關注列表',
	  // 首頁股票清單表頭
	  STOCK_THEAD: ['名稱', '價格', '費率'],
	  PAGE_TITLE_NOTIFICATION: '通知',
	  PAGE_TITLE_SEARCH: '搜尋',
	  TIP_SEARCH: '輸入關鍵字',
	  SEARCH_HISTORY: '搜尋紀錄',
	  // 折價交易
	  PAGE_TITLE_TRADE_DISCOUNT: '以舊換新',
	  TIP_POST_SUCCESS: '成功',
	  ABOUT_US:'關於我們',
	  CURRENCY_UNIT:'',
	  QUANTITY_UNIT:'',
	  UNIT_BILION: '十億',
	  UNIT_POS: '位置',
	  UNIT_DAY: '日',
	  更多:'更多',
	  簡介:'簡介',
	EMPTY_NOTIFIY: '空通知',
	  EMPTY_DATA: '空資料',
	  BTN_CONFIRM: '確認',
	  BTN_CANCEL: '取消',
	  BTN_SEND_SERVICE: '聯絡客戶服務',
	  BTN_DETAIL: '詳細資料',
	  BTN_BUY: '購買',
	  BTN_SELL: '賣出',
	  STATUS_LOADING: "正在載入",
	  STATUS_SUBMIT: '正在提交',
	  STATUS_REQUEST: '取得新資料',
	  STATUS_HTTP_ERROR: '請求異常，正在重試',
	  STATUS_UPLOAD: "正在上傳",

	// =============================
	// 网络检查及网络状态
	TIP_NETWORK_TYPE_NONE: '無網路或網路狀態較差',
	
	  // API相關提示
	  API_TOKEN_EXPIRES: '您的登入狀態已過期，請重新登入',
	  API_HTTP_ERROR: '請求異常。請檢查您的網路',
	  REQUEST_DATA: '請求資料',
	  API_EMPTY_DATA: '空資料',
	  API_EMPTY_CONTENT: '空內容',
	  API_SIGN_IN_NOW: '正在登入',
	  API_SIGN_UP_NOW: '正在註冊',
	  API_DATA_SUBMIT: '正在提交',
	  API_POST_SUCCESS: '成功',
	// 复制成功
	TIP_COPY_SUCCESS: '複製成功',
	
	
	COIN_LIST_TITLE: '硬幣列表', // Coin 清單 標題
	
	TRADE_RECORD_TITLE: '記錄', // 交易記錄
	
	MARKET_TAB_COIN: '硬幣', // 市場 coin
	MARKET_TAB_TRACK: '收藏', // 市場 收藏
	
	// Coin OverView 幣 詳情頁面 [分 日 月]
	COIN_VIEW_TAB_MINUTE: '分鐘',
	  COIN_VIEW_TAB_DAILY: '每日',
	  COIN_VIEW_TAB_MONTHLY: '每月',
	// COIN_VIEW_BTN_BUY: 'Buy',
	// COIN_VIEW_BTN_SELL: 'Sell',
	// Coin Buy and  Sell
	COIN_VIEW_QUANTITY: '數量',
	  COIN_VIEW_AVAILABLE_AMOUNT: '可用金額',
	  COIN_VIEW_PAYMENT_AMOUNT: '付款金額',
	  COIN_VIEW_UNIT: '單位',
	  COIN_VIEW_ENTER_QUANTITY: '請輸入數量',
	  COIN_MODAL_COMFIRM: '確認',
	  COIN_MODAL_CANCEL: '取消',
	  COIN_MODAL_WANT_TO: `想要`,
	
	  COIN_BAY_SELECT_PRICE_TYPE: '選擇價格模式',
	  COIN_BAY_ENTER_AMOUNT: '請輸入金額',
	// Wealth 交易
	TRADE_WEALTH_TITLE: '財富',
	  TRADE_WEALTH_RECORD_TITLE: '財富記錄',
	  TRADE_WEALTH_HOLD_RECORD: '保留記錄',
	  TRADE_WEALTH_HISTORY: '歷史',
	  TRADE_WEALTH_NEW_USERS: '新使用者',
	  TRADE_WEALTH_BUY_DETAIL: '購買詳情',
	  TRADE_WEALTH_RATE: '費率',
	  TRADE_WEALTH_CYCLE: '循環',
	  TRADE_WEALTH_CYCLE_UNIT:'天',
	  TEADE_WEALTH_MIN_PRICE: '最低價格',
	// 买入弹层
	TRADE_WEALTH_BUY_AMOUNT: '請輸入金額',
	  TRADE_WEALTH_BUY_AMOUNT_TIP: '金額必須大於最低價格',
	// 持有列表
	TRADE_WEALTH_HOLD_RATE: '利率',
	  TRADE_WEALTH_HOLD_CYCLE: '循環',
	  TRADE_WEALTH_HOLD_PRICE: '價格',
	
	  TRADE_WEALTH_HOLD_NUM: '數量',
	  TRADE_WEALTH_HOLD_PROFIT: '卡維札拉',
	
	  TRADE_WEALTH_HOLD_PAY_PRICE: '支付價格',
	// TRADE_WEALTH_HOLD_PROFIT: 'Profit',
	TRADE_WEALTH_HOLD_SN: 'SN',
	  TRADE_WEALTH_HOLD_CRETIME: '建立時間',
	  TRADE_WEALTH_HOLD_ENDTIME: '結束時間',


	// 汇款
	ACCOUNT_LIST_REMITTANCE: '匯款',
	// 汇款页面
	REMITTANCE_TITLE: '匯款',


	// 等级 团队页面
	ACCOUNT_LEVEL_TITLE: '等級',
	  LEVEL_CURRENT_LEVEL: '目前等級',
	  LEVEL_CURRENT_TEAM: '目前團隊',
	  LEVEL_DESC_TITLE: '關卡描述',
	  LEVEL_NEXT_LEVEL: '下一個等級',
	  LEVEL_SELF_HOLD_MONEY: '自行持有款項',
	  LEVEL_L1_TEAM_USERS: 'L1 團隊使用者',
	  LEVEL_L1_TEAM_MONEY: 'L1 團隊經費',
	  LEVEL_L2_TEAM_USERS: 'L2 團隊使用者',
	  LEVEL_L2_TEAM_MONEY: 'L2 團隊資金',
	  LEVEL_TEAM_LIST_HEAD_MOBILE: '移動',
	  LEVEL_TEAM_LIST_HEAD_AMOUNT: '財富數量',
	  LEVEL_L1_TEAM: 'L1 團隊',
	  LEVEL_L2_TEAM: 'L2 團隊',


	// Trade  持仓页面 持有卖出的总页面
	
	// Trade Detail 持仓，单条数据详情
	TRADE_HOLD_DETAIL_TITLE:'交易保留詳情',
	
	//理财
	LICAI_LICAI:'金融',
	LICAI_REN:'人',
	LICAI_YUGUSHOUYILV:'預計產量',
	LICAI_ZHOUQI:'週期',
	LICAI_ZUIDIMAIRU:'最低購買量',
	LICAI_MINGCHENG:'名稱',
	LICAI_LEIXING:'類型',
	LICAI_FAFANGRIQI:'發布日期',
	LICAI_QINGSHURUMEIRUJINE:'請輸入購買金額',
	LICAI_CHICANG:'持有',
	LICAI_YISHUHUI:'已贖回',
	LICAI_KEFU:'聯絡客服',
	
}