export default {
	TRANSLATE_TITLE: 'Please select language',
	// 底部导航
	TABBAR_HOME: "Home",
	TABBAR_FOLLOW: "Finance",
	TABBAR_MARKET: 'Market',
	TABBAR_TRADE: 'Trade',
	TABBAR_ACCOUNT: 'Account',

	// 账户管理相关 登入、注册
	SIGN_IN: "Sign In",
	SIGN_UP: "Create Account",
	SIMGN_OUT: "Sign Out",
	GO_TO_SIGN_IN: 'Go To The Sign In',
	USER_NAME: 'Account',
	ENTER_USER_NAME: 'Enter your email account',
	PASSWORD: 'Password',
	ENTER_PASSWORD: 'Enter Your Password',
	VERIFY_PASSWORD: 'Verify Password',
	ENTER_VERIFY_PASSWORD: 'Enter Your Password',
	INVITATION_CODE: 'Invitation Code',
	INT_ATIN_CODE: 'About Us',
	ENTER_INVITATION_CODE: 'Enter Your Code',
	TIP_PWD_NOEQUAL: 'The password entered twice is inconsistent',
	TIP_SUCCESS_SIGNIN: 'sign in suceesfully',
	TIP_SUCCESS_REGISTER: 'Registration has been completed, please log in',
	TIP_SIGNIN_ING: 'Logging in',
	TIP_SIGNUP_ING: 'Registering',
	TIP_REMEMBER_PWD: 'Remember password',
	API_TOKEN_EXPIRES: 'Token Expires. Please Sign In Again',
	TIP_SIGN_OUT_SUCCESS: 'Logout successful',
	TIP_AGREE: 'I agree',
	TIP_PRVITE_PACT: 'Privte and pact',
	TIP_CHECK_AGREE: 'Please checked agree',

	// 变更登入密码、变更支付密码、变更账户信息
	TIP_OLD_PWD: 'Enter the original password',
	TIP_NEW_PWD: 'Enter a new password',
	TIP_NEW_PWD_VERIFY: 'Enter new password again',


	// 提款页面
	PAGE_TITLE_WITHDRAW: 'Withdraw',
	WITHDRAW_AMOUNT: 'my assets',
	WITHDRAW_TITLE: "Withdraw funds",
	TIP_AMOUNT_AVAIL: 'Amount Available',
	WITHDRAW_WITH_AMOUNT: 'Withdraw amount',
	TIP_AMOUNT_WITHDRAW: 'Enter the withdrawal amount',
	WITHDRAW_PAY_PWD: 'Withdrawal password',
	TIP_WITHDRAW_PWD: 'Enter payment password',
	WITHDRAWING_POST_TIP: 'Processing....',
	// 提款说明
	WITHDRAW_TIP_TEXT: [`1. Cannot be withdrawn until the currently held shares are sold.`, `
2. In order to withdraw money, you need to verify your real name and verify your account before withdrawing money.`,
		`3. Withdrawal trading hours: 09:00-15:00 on weekdays (withdrawals are not allowed on weekends and public holidays).`,
		`4. The minimum amount to request a withdrawal is 3 USDT .`,
		`5. After applying for withdrawal, in principle, it will be deposited into the designated withdrawal account on the same day.`,
		`※ Payment will be completed within 2 working days (48 hours) at most.`
	],

	// 入金页面
	PAGE_TITLE_DEPOSIT: 'Deposit',
	PAGE_TITLE_DE: 'Bind account',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: 'Enter Recharge Amount',
	DEPOSIT_TIP_LOW_AMOUNT: 'Minimum 1,000,000',
	DEPOSIT_POST_TIP: 'Processing....',
	DEPOSIT_TIP_TITLE: 'Friendly reminder',
	DEPOSIT_UPLOAD_TITLE:'Upload Image',
	DEPOSIT_TIP_TEXT: ['1. Recharge time: 09:00~18:00 on weekdays, closed on holidays.',
		'Thank you for choosing us. To ensure the safety of your funds, please ensure that the account you want to transfer to is the account displayed in real time on our platform, and please verify with our staff each time you transfer funds from a non-bank account. Accounts are displayed live on our platform and you are responsible for any losses incurred as a result of your deposits.'
	],

	// 个人中心页面
	ACCOUNT_CHANGE_PWD: 'Change Sign In Password',
	ACCOUNT_TRADE_LOG: 'Capital flow',
	ACCOUNT_SERVICE: 'Service',
	ACCOUNT_AMOUNT_TOTAL: 'Total assets',
	ACCOUNT_AMOUNT_AVAILABLE: 'Available funds',
	ACCOUNT_MORE_FEATURES: 'More Features',

	// 交易记录页面
	TRADE_LOG_BTNS: ['Details', 'Deposit', 'Withdraw'],
	TRADE_LOG_TIP_MODAL_TITLE: 'Are you sure you want to cancel the withdrawal request?',
	TRADE_LOG_WITHDRAW_STATUS: ['Under review', 'Withdraw successfully',
		'Withdrawal failed, please contact customer service', 'Reject'
	],
	LOG_TRADE_AMOUNT_BEFORE: 'Balance before trade',
	LOG_TRADE_AMOUNT_AFTER: 'Balance after trade',
	LOG_TRADE_DW: 'Trade Amount',
	LOG_TRADE_CREATE_TIME: 'Time',
	LOG_TRADE_DESC: 'Detail',
	LOG_TRADE_ORDER_SN: 'Order Sn',
	LOG_TRADE_DW_DESC: 'Trade desc',
	LOG_WITHDRAW_AMOUNT: 'Withdrawal amount',
	LOG_STATUS: 'Status',


	// 交易页面
	TRADE_TITLE: 'Investment results',
	TRADE_TABS: ['Hold record', 'Sell record'],
	TRADE_TOTAL_BUY_AMOUNT: 'Total purchase',
	TRADE_VALUATION_GAIN_LOSS: 'Profit and loss',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: 'Evaluation amount',
	TRADE_RATE_RESPONSE: 'Response rate',
	TRADE_TOTAL_GAIN: 'Total profit',
	// 持仓和卖出的记录 表头
	TRADE_LIST_THEAD: ['name', 'gains', 'QTY Hold', 'Eval', 'Price', 'Price'],
	TRADE_MOADL_TITLE: 'Order',
	// 订单的label组
	TRADE_MODAL_LABELS: ['name', 'Buy time', 'Sales time', 'Profit', 'Lever', 'Total profit', 'Price', 'QTY', 'Fee',
		'Total amount', 'Code'
	],
	// 卖出的二次确认
	SELL_TIP: 'Confirm sale?',


	// IPO 交易
	PAGE_TITLE_TRADE_IPO: 'IPO',
	TRADE_IPO_TABS: ['Goods', 'Record', 'Success'],
	TRADE_IPO_MODAL_TITLE: 'Public offering stock subscription application',
	TRADE_IPO_MODAL_CONTENT: 'If you want to apply for a subscription, please click Confirm',
	TADE_IPO_SUB_PRICE: 'Subscription',
	TRADE_IPO_PE_RATE: 'P/E ratio',
	TRADE_IPO_SUB_CT: 'Subscription time',
	TRADE_IPO_POST_QTY: 'Circulation',
	TRADE_IPO_RAISE_MONEY: 'Fund raising',
	TRADE_IPO_LOG_LABELS: ['Subscription price', 'P/E ratio', 'Subscription time', 'cycle'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO Subscription success record',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: 'Subscription QTY',
	TRADE_IPO_SUCCESS_AMOUNT: 'Winning',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: 'amount',
	TRADE_IPO_SUCCESS_ORDER_SN: 'Order sn',
	TRADE_IPO_SUCCESS_CT: 'Date time',


	// 单股详情页面
	PAGE_TITLE_STOCK_OVERVIEW: 'Stock details',
	// 股票最新数值
	STOCK_INFO_TITLES: ['market price', 'Closing price', 'high price', 'low price', 'Trading volume',
		'Trading amount'
	],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['minute', 'day', 'moon'],
	// 单股购买页面
	STOCK_BUY_QUANTITY: 'quantity',
	STOCK_BUY_TIP_QUANTITY: 'Enter quantity',
	STOCK_BUY_AMOUNT: 'Payment amount',
	STOCK_BUY_FEE: 'Fee',
	STOCK_BUY_CONFIRM: 'Purchase',

	LEVER: 'Lever',
	STOCK_ALL: 'Stock List',
	STOCK_FOLLOW: 'Follow List',
	// 首页股票列表表头
	STOCK_THEAD: ['Name', 'Price', 'Rate'],
	PAGE_TITLE_NOTIFICATION: 'Notify',
	PAGE_TITLE_SEARCH: 'Search',
	TIP_SEARCH: 'Enter keywords',
	SEARCH_HISTORY: 'Search History',
	// 折价交易
	PAGE_TITLE_TRADE_DISCOUNT: 'trade-in',
	TIP_POST_SUCCESS: 'Success',
	ABOUT_US: 'About Us',
	CURRENCY_UNIT: '',
	QUANTITY_UNIT: '',
	UNIT_BILION: 'Bilion',
	UNIT_POS: 'Position',
	UNIT_DAY: 'Day',
	MORE: 'More',
	BRIEF: 'Brief',
	EMPTY_NOTIFIY: 'Empty Notifiy',
	EMPTY_DATA: 'Empty Data',
	BTN_CONFIRM: 'Confirm',
	BTN_CANCEL: 'Cancel',
	BTN_SEND_SERVICE: 'Contact Customer Service',
	BTN_DETAIL: 'Details',
	BTN_BUY: 'Buy',
	BTN_SELL: 'Sell',
	STATUS_LOADING: "loading",
	STATUS_SUBMIT: 'Submitting',
	STATUS_REQUEST: 'Get new data',
	STATUS_HTTP_ERROR: 'Request exception, retrying',
	STATUS_UPLOAD: "Uploading",

	// =============================
	// 网络检查及网络状态
	TIP_NETWORK_TYPE_NONE: 'There is no network or the network status is poor.',

	// API 相关提示
	API_TOKEN_EXPIRES: 'Your login status has expired, please log in again',
	API_HTTP_ERROR: 'The request is abnormal. Please check your network.',
	REQUEST_DATA: 'Request data',
	API_EMPTY_DATA: 'Empty Data',
	API_EMPTY_CONTENT: 'Empty Content',
	API_SIGN_IN_NOW: 'Logging in',
	API_SIGN_UP_NOW: 'Registering',
	API_DATA_SUBMIT: 'Submitting',
	API_POST_SUCCESS: 'Success',

	// 复制成功
	TIP_COPY_SUCCESS: 'Copy Success',


	COIN_LIST_TITLE: 'Coin List', // Coin 列表 标题

	TRADE_RECORD_TITLE: 'Record', // 交易记录

	MARKET_TAB_COIN: 'Coin', // 市场 coin
	MARKET_TAB_TRACK: 'Track', // 市场 收藏

	// Coin OverView 币 详情页面 [分 日 月]
	COIN_VIEW_TAB_MINUTE: 'Minute',
	COIN_VIEW_TAB_DAILY: 'Daily',
	COIN_VIEW_TAB_MONTHLY: 'Monthly',
	// COIN_VIEW_BTN_BUY: 'Buy',
	// COIN_VIEW_BTN_SELL: 'Sell',
	// Coin Buy and  Sell
	COIN_VIEW_QUANTITY: 'Quantity',
	COIN_VIEW_AVAILABLE_AMOUNT: 'Available Amount',
	COIN_VIEW_PAYMENT_AMOUNT: 'Payment Amount',
	COIN_VIEW_UNIT: 'Unit',
	COIN_VIEW_ENTER_QUANTITY: 'Please Enter Quantity',
	COIN_MODAL_COMFIRM: 'Confirm',
	COIN_MODAL_CANCEL: 'Cancel',
	COIN_MODAL_WANT_TO: `Want to`,

	COIN_BAY_SELECT_PRICE_TYPE: 'Select Price Mode',
	COIN_BAY_ENTER_AMOUNT: 'Please Enter Amount',

	// Wealth 交易
	TRADE_WEALTH_TITLE: 'Wealth',
	TRADE_WEALTH_RECORD_TITLE: 'Wealth Record',
	TRADE_WEALTH_HOLD_RECORD: 'Hold Record',
	TRADE_WEALTH_HISTORY: 'History',
	TRADE_WEALTH_NEW_USERS: 'New Users',
	TRADE_WEALTH_BUY_DETAIL: 'Buy Detail',
	TRADE_WEALTH_RATE: 'Rate',
	TRADE_WEALTH_CYCLE: 'Cycle',
	TRADE_WEALTH_CYCLE_UNIT: 'Day',
	TEADE_WEALTH_MIN_PRICE: 'Min Price',
	// 买入弹层
	TRADE_WEALTH_BUY_AMOUNT: 'Please Enter Amount',
	TRADE_WEALTH_BUY_AMOUNT_TIP: 'Amount Must Bigger Min Price',
	// 持有列表
	TRADE_WEALTH_HOLD_RATE: 'Rate',
	TRADE_WEALTH_HOLD_CYCLE: 'Cycle',
	TRADE_WEALTH_HOLD_PRICE: 'Price',
	
	TRADE_WEALTH_HOLD_NUM: 'Num',
	TRADE_WEALTH_HOLD_PROFIT: 'Kar ve zarar',
	
	TRADE_WEALTH_HOLD_PAY_PRICE: 'Pay Price',
	// TRADE_WEALTH_HOLD_PROFIT: 'Profit',
	TRADE_WEALTH_HOLD_SN: 'SN',
	TRADE_WEALTH_HOLD_CRETIME: 'Create Time',
	TRADE_WEALTH_HOLD_ENDTIME: 'End Time',


	// 汇款
	ACCOUNT_LIST_REMITTANCE: 'Remittance',
	// 汇款页面
	REMITTANCE_TITLE: 'Remittance',


	// 等级 团队页面
	ACCOUNT_LEVEL_TITLE: 'Level',
	LEVEL_CURRENT_LEVEL: 'Current Level',
	LEVEL_CURRENT_TEAM: 'Current Team',
	LEVEL_DESC_TITLE: 'Level Description',
	LEVEL_NEXT_LEVEL: 'Next Level',
	LEVEL_SELF_HOLD_MONEY: 'Self Hold Money',
	LEVEL_L1_TEAM_USERS: 'L1 Team Users',
	LEVEL_L1_TEAM_MONEY: 'L1 Team Money',
	LEVEL_L2_TEAM_USERS: 'L2 Team Users',
	LEVEL_L2_TEAM_MONEY: 'L2 Team Money',
	LEVEL_TEAM_LIST_HEAD_MOBILE: 'Mobile',
	LEVEL_TEAM_LIST_HEAD_AMOUNT: 'Weathl Amount',
	LEVEL_L1_TEAM: 'L1 Team',
	LEVEL_L2_TEAM: 'L2 Team',


	// Trade  持仓页面 持有卖出的总页面
	
	// Trade Detail 持仓，单条数据详情
	TRADE_HOLD_DETAIL_TITLE:'Trade Hold Detail',
	
	//理财
	LICAI_LICAI:'Finance',
	LICAI_REN:'Person',
	LICAI_YUGUSHOUYILV:'Estimated yield',
	LICAI_ZHOUQI:'cycle',
	LICAI_ZUIDIMAIRU:'Minimum buy',
	LICAI_MINGCHENG:'Name',
	LICAI_LEIXING:'Type',
	LICAI_FAFANGRIQI:'Release Date',
	LICAI_QINGSHURUMEIRUJINE:'Please enter the purchase amount',
	LICAI_CHICANG:'Position',
	LICAI_YISHUHUI:'Redeemed',
	LICAI_KEFU:'Contact Customer Service',
}