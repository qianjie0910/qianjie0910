export default {
	TRANSLATE_TITLE: 'Lütfen dili seçin',
	// devamı
	TABBAR_HOME: "Ev",
	TABBAR_FOLLOW: "Finans",
	TABBAR_MARKET: 'Pazar',
	TABBAR_TRADE: 'Ticaret',
	TABBAR_ACCOUNT: 'Hesap',

	// 账户管理相关 登入、注册
	SIGN_IN: "Oturum Aç",
	SIGN_UP: "Hesap Oluştur",
	SIMGN_OUT: "Oturumu Kapat",
	GO_TO_SIGN_IN: 'Oturum Açmaya Git',
	USER_NAME: 'Hesap',
	ENTER_USER_NAME: 'E-posta hesabınızı girin ',
	ŞİFRE: 'Şifre',
	ENTER_PASSWORD: 'Şifrenizi Girin',
	VERIFY_PASSWORD: 'Şifreyi Doğrula',
	ENTER_VERIFY_PASSWORD: 'Şifrenizi Girin',
	INVITATION_CODE: 'Davetiye Kodu',
	ENTER_INVITATION_CODE: 'Kodunuzu Girin',
	TIP_PWD_NOEQUAL: 'İki kez girilen şifre tutarsız',
	TIP_SUCCESS_SIGNIN: 'başarıyla oturum açın',
	TIP_SUCCESS_REGISTER: 'Kayıt tamamlandı, lütfen giriş yapın',
	TIP_SIGNIN_ING: 'Giriş Yap',
	TIP_SIGNUP_ING: 'Kayıt olunuyor',
	TIP_REMEMBER_PWD: 'Şifreyi hatırla',
	API_TOKEN_EXPIRES: 'Jetonun Süresi Doluyor. Lütfen Tekrar Oturum Açın',
	TIP_SIGN_OUT_SUCCESS: 'Oturum kapatma başarılı',
	TIP_AGREE: 'Kabul ediyorum',
	TIP_PRVITE_PACT: 'Gizlilik ve anlaşma',
	TIP_CHECK_AGREE: 'Lütfen kabul ediyorum seçeneğini işaretleyin',

	// 变更登入密码、变支付密码、变更账户信息
	TIP_OLD_PWD: 'Orijinal şifreyi girin',
	TIP_NEW_PWD: 'Yeni bir şifre girin',
	TIP_NEW_PWD_VERIFY: 'Yeni şifreyi tekrar girin',


	// 提款页面
	PAGE_TITLE_WITHDRAW: 'Çekilme',
	YOURDRAW_AMOUNT: 'varlıklarım',
	WDRAW_TITLE: "Para çek",
	TIP_AMOUNT_AVAIL: 'Mevcut Tutar',
	WithDRAW_WITH_AMOUNT: 'Çekilen tutar',
	TIP_AMOUNT_WITHDRAW: 'Para çekme tutarını girin',
	WithDRAW_PAY_PWD: 'Para çekme şifresi',
	TIP_WITHDRAW_PWD: 'Ödeme şifresini girin',
	WithDRAWING_POST_TIP: 'İşleniyor....',
	// 提款说明
	YOURDRAW_TIP_TEXT: [`1. Mevcut hisseler satılıncaya kadar geri çekilemez.`, `
2. Para çekebilmeniz için para çekmeden önce gerçek isminizi doğrulamanız ve hesabınızı doğrulamanız gerekmektedir.`,
		`3. Para çekme işlem saatleri: Hafta içi 09:00-15:00 (hafta sonları ve resmi tatil günlerinde para çekme işlemlerine izin verilmemektedir).`,
		`4. Para çekme talebi için minimum tutar 10.000. dir`,
		`5. Para çekme başvurusu yapıldıktan sonra prensip olarak aynı gün içerisinde belirlenen para çekme hesabına yatırılacaktır.`,
		`※ Ödeme en fazla 2 iş günü (48 saat) içerisinde tamamlanacaktır.`
	],

	// devamı
	PAGE_TITLE_DEPOSIT: 'Para Yatır',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: 'Yükleme Tutarını Girin',
	DEPOSIT_TIP_LOW_AMOUNT: 'Minimum 1.000.000',
	DEPOSIT_POST_TIP: 'İşleniyor....',
	DEPOSIT_TIP_TITLE: 'Dostça hatırlatma',
	DEPOSIT_UPLOAD_TITLE: 'Resim Yükle',
	DEPOSIT_TIP_TEXT: ['1. Şarj süresi: Hafta içi 09:00~18:00, tatil günlerinde kapalıdır.',
		'Bizi tercih ettiğiniz için teşekkürler. Paranızın güvenliğini sağlamak için, lütfen transfer etmek istediğiniz hesabın platformumuzda gerçek zamanlı olarak görüntülenen hesap olduğundan emin olun ve lütfen banka dışı bir hesaptan her para transferi yaptığınızda personelimizle doğrulayın. Hesaplar platformumuzda canlı olarak gösterilmektedir ve para yatırma işlemleriniz sonucunda doğabilecek her türlü zarardan siz sorumlusunuz.'
	],

	// 个人中心页面
	ACCOUNT_CHANGE_PWD: 'Oturum Açma Şifresini Değiştir',
	ACCOUNT_TRADE_LOG: 'Sermaye akışı',
	ACCOUNT_SERVICE: 'Hizmet',
	ACCOUNT_AMOUNT_TOTAL: 'Toplam varlıklar',
	ACCOUNT_AMOUNT_AVAILABLE: 'Kullanılabilir fon',
	ACCOUNT_MORE_FEATURES: 'Diğer Özellikler',

	// 交易记录页面
	TRADE_LOG_BTNS: ['Detay', 'Para Yatırma', 'Çekme'],
	TRADE_LOG_TIP_MODAL_TITLE: 'Para çekme isteğini iptal etmek istediğinizden emin misiniz?',
	TRADE_LOG_WITHDRAW_STATUS: ['İnceleniyor', 'Başarıyla geri çekildi',
		'Para çekme işlemi başarısız oldu, lütfen müşteri hizmetleriyle iletişime geçin', 'Reddet'
	],
	LOG_TRADE_AMOUNT_BEFORE: 'Ticaret öncesi bakiye',
	LOG_TRADE_AMOUNT_AFTER: 'Ticaret sonrası bakiye',
	LOG_TRADE_DW: 'İşlem Tutarı',
	LOG_TRADE_CREATE_TIME: 'İşlem Tarih Saati',
	LOG_TRADE_DESC: 'Ayrıntı',
	LOG_TRADE_ORDER_SN: 'İşlem emri sn',
	LOG_TRADE_DW_DESC: 'Ticaret açıklaması',
	LOG_WITHDRAW_AMOUNT: 'Çekim tutarı',
	LOG_STATUS: 'Durum',


	// bir şey
	TRADE_TITLE: 'Yatırım sonuçları',
	TRADE_TABS: ['Kaydı tut', 'Kaydı sat'],
	TRADE_TOTAL_BUY_AMOUNT: 'Toplam satın alma',
	TRADE_VALUATION_GAIN_LOSS: 'Kar ve zarar',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: 'Değerlendirme tutarı',
	TRADE_RATE_RESPONSE: 'Yanıt oranı',
	TRADE_TOTAL_GAIN: 'Toplam kâr',
	// 持仓和卖出的记录 表头
	TRADE_LIST_THEAD: ['isim', 'kazançlar', 'Miktar Tutma', 'Değerlendirme', 'Fiyat', 'Fiyat'],
	TRADE_MOADL_TITLE: 'Sipariş',
	// etiket etiketi
	TRADE_MODAL_LABELS: ['isim', 'Satın alma süresi', 'Satış süresi', 'Kar', 'Kol', 'Toplam kar', 'Fiyat', 'Miktar',
		'Ücret',
		'Toplam tutar', 'Kod'
	],
	// Bir sonraki adım
	SELL_TIP: 'Satış onaylansın mı?',


	// halka arz
	PAGE_TITLE_TRADE_IPO: 'halka arz',
	TRADE_IPO_TABS: ['Mallar', 'Kayıt', 'Başarı'],
	TRADE_IPO_MODAL_TITLE: 'Halka arz hisse senedi aboneliği başvurusu',
	TRADE_IPO_MODAL_CONTENT: "Abonelik başvurusunda bulunmak istiyorsanız lütfen Onayla' ya tıklayın ",
	TADE_IPO_SUB_PRICE: 'Abonelik',
	TRADE_IPO_PE_RATE: 'F/K oranı',
	TRADE_IPO_SUB_CT: 'Abonelik süresi',
	TRADE_IPO_POST_QTY: 'Dolaşım',
	TRADE_IPO_RAISE_MONEY: 'Fon toplama',
	TRADE_IPO_LOG_LABELS: ['Abonelik fiyatı', 'F/K oranı', 'Abonelik süresi', 'döngü'],
	TRADE_IPO_SUCCESS_TITLE: 'Halka Arz Aboneliği başarı kaydı',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: 'Abonelik MİKTARI',
	TRADE_IPO_SUCCESS_AMOUNT: 'Kazanıyor',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: 'tutar',
	TRADE_IPO_SUCCESS_ORDER_SN: 'Sipariş sn',
	TRADE_IPO_SUCCESS_CT: 'Tarih saat',


	// 单股详情页面
	PAGE_TITLE_STOCK_OVERVIEW: 'Stok ayrıntıları',
	// 股票最新数值
	STOCK_INFO_TITLES: ['piyasa fiyatı', 'Kapanış fiyatı', 'yüksek fiyat', 'düşük fiyat', 'İşlem hacmi',
		'İşlem tutarı'
	],
	// KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['dakika', 'gün', 'ay'],
	// 单股购买页面
	STOK_BUY_QUANTITY: 'miktar',
	STOCK_BUY_TIP_QUANTITY: 'Miktarını girin',
	STOCK_BUY_AMOUNT: 'Ödeme tutarı',
	STOCK_BUY_FEE: 'Ücret',
	STOCK_BUY_CONFIRM: 'Satın Al',

	KOL: 'Kol',
	STOK_ALL: 'Stok Listesi',
	STOCK_FOLLOW: 'Takip Listesi',
	// 首页股票列表表头
	STOK_THEAD: ['İsim', 'Fiyat', 'Oran'],
	PAGE_TITLE_NOTIFICATION: 'Bildir',
	PAGE_TITLE_SEARCH: 'Ara',
	TIP_SEARCH: 'Anahtar kelimeleri girin',
	SEARCH_HISTORY: 'Arama Geçmişi',
	// Bir sonraki adım
	PAGE_TITLE_TRADE_DISCOUNT: 'takas',
	TIP_POST_SUCCESS: 'Başarılı',
	HAKKIMIZDA: 'Hakkımızda',
	CURRENCY_UNIT: '',
	QUANTITY_UNIT: '',
	UNIT_BILION: 'Milyar',
	UNIT_POS: 'Konum',
	UNIT_DAY: 'Gün',
	MORE: 'Daha',
	BRIEF: 'Kısa bilgi',
	EMPTY_NOTIFIY: 'Boş Bildirim',
	EMPTY_DATA: 'Verileri Boşalt',
	BTN_CONFIRM: 'Onayla',
	BTN_CANCEL: 'İptal',
	BTN_SEND_SERVICE: 'Müşteri Hizmetleriyle İletişime Geçin',
	BTN_DETAIL: 'Ayrıntılar',
	BTN_BUY: 'Satın Al',
	BTN_SELL: 'Sat',
	STATUS_LOADING: "yükleniyor",
	STATUS_SUBMIT: 'Gönderiliyor',
	STATUS_REQUEST: 'Yeni veriler al',
	STATUS_HTTP_ERROR: 'İstisna iste, yeniden deneniyor',
	STATUS_UPLOAD: "Yükleniyor",

	// ==============================
	// 网络检查及网络状态
	TIP_NETWORK_TYPE_NONE: 'Ağ yok veya ağ durumu zayıf.',

	// API kodu
	API_TOKEN_EXPIRES: 'Giriş durumunuzun süresi doldu, lütfen tekrar giriş yapın',
	API_HTTP_ERROR: 'İstek anormal. Lütfen ağınızı kontrol edin.',
	REQUEST_DATA: 'Veri iste',
	API_EMPTY_DATA: 'Verileri Boşalt',
	API_EMPTY_CONTENT: 'Boş İçerik',
	API_SIGN_IN_NOW: 'Giriş Yap',
	API_SIGN_UP_NOW: 'Kayıt Ediliyor',
	API_DATA_SUBMIT: 'Gönderiliyor',
	API_POST_SUCCESS: 'Başarılı',

	// bir dahaki sefere
	TIP_COPY_SUCCESS: 'Kopyalama Başarılı',


	COIN_LIST_TITLE: 'Coin Listesi', // Coin 列表 标题

	TRADE_RECORD_TITLE: 'Kayıt', // Kayıt

	MARKET_TAB_COIN: 'Para', // madeni para
	MARKET_TAB_TRACK: 'Takip', // Takip et

	// Coin'e Genel Bakış 币 详情页面 [分 日 月]
	COIN_VIEW_TAB_MINUTE: 'Dakika',
	COIN_VIEW_TAB_DAILY: 'Günlük',
	COIN_VIEW_TAB_MONTHLY: 'Aylık',
	// COIN_VIEW_BTN_BUY: 'Satın Al',
	// COIN_VIEW_BTN_SELL: 'Sat',
	// Coin Alım Satım
	COIN_VIEW_QUANTITY: 'Miktar',
	COIN_VIEW_AVAILABLE_AMOUNT: 'Kullanılabilir Tutar',
	COIN_VIEW_PAYMENT_AMOUNT: 'Ödeme Tutarı',
	COIN_VIEW_UNIT: 'Birim',
	COIN_VIEW_ENTER_QUANTITY: 'Lütfen Miktarı Girin',
	COIN_MODAL_COMFIRM: 'Onayla',
	COIN_MODAL_CANCEL: 'İptal',
	COIN_MODAL_WANT_TO: 'İstiyorum',

	COIN_BAY_SELECT_PRICE_TYPE: 'Fiyat Modunu Seçin',
	COIN_BAY_ENTER_AMOUNT: 'Lütfen Tutarı Girin',

	// Zenginlik
	TRADE_WEALTH_TITLE: 'Zenginlik',
	TRADE_WEALTH_RECORD_TITLE: 'Servet Rekoru',
	TRADE_WEALTH_HOLD_RECORD: 'Kayıt Tut',
	TRADE_WEALTH_HISTORY: 'Geçmiş',
	TRADE_WEALTH_NEW_USERS: 'Yeni Kullanıcılar',
	TRADE_WEALTH_BUY_DETAIL: 'Satın Alma Detayı',
	TRADE_WEALTH_RATE: 'Oran',
	TRADE_WEALTH_CYCLE: 'Döngü',
	TRADE_WEALTH_CYCLE_UNIT: 'Gün',
	TEADE_WEALTH_MIN_PRICE: 'Minimum Fiyat',
	// 买入弹层
	TRADE_WEALTH_BUY_AMOUNT: 'Lütfen Tutarı Giriniz',
	TRADE_WEALTH_BUY_AMOUNT_TIP: 'Tutar Minimum Fiyattan Büyük Olmalı',
	// 持有列表
	TRADE_WEALTH_HOLD_RATE: 'Oran',
	TRADE_WEALTH_HOLD_CYCLE: 'Döngü',
	TRADE_WEALTH_HOLD_PRICE: 'Fiyat',
	TRADE_WEALTH_HOLD_PAY_PRICE: 'Fiyatı Öde',
	TRADE_WEALTH_HOLD_NUM: 'Birde',
	TRADE_WEALTH_HOLD_PROFIT: 'Kar',
	TRADE_WEALTH_HOLD_SN: 'SN',
	TRADE_WEALTH_HOLD_CRETIME: 'Zaman Yarat',
	TRADE_WEALTH_HOLD_ENDTIME: 'Bitiş Zamanı',


	//
	ACCOUNT_LIST_REMITTANCE: 'Havale',
	// 汇款页面
	REMITTANCE_TITLE: 'Havale',


	// 等级 团队页面
	ACCOUNT_LEVEL_TITLE: 'Seviye',
	LEVEL_CURRENT_LEVEL: 'Geçerli Seviye',
	LEVEL_CURRENT_TEAM: 'Mevcut Takım',
	LEVEL_DESC_TITLE: 'Seviye Açıklaması',
	LEVEL_NEXT_LEVEL: 'Sonraki Seviye',
	LEVEL_SELF_HOLD_MONEY: 'Kendi Parasını Tut',
	LEVEL_L1_TEAM_USERS: 'L1 Takım Kullanıcıları',
	LEVEL_L1_TEAM_MONEY: 'L1 Takım Parası',
	LEVEL_L2_TEAM_USERS: 'L2 Ekip Kullanıcıları',
	LEVEL_L2_TEAM_MONEY: 'L2 Takım Parası',
	LEVEL_TEAM_LIST_HEAD_MOBILE: 'Mobil',
	LEVEL_TEAM_LIST_HEAD_AMOUNT: 'Havale Tutarı',
	LEVEL_L1_TEAM: 'L1 Takımı',
	LEVEL_L2_TEAM: 'L2 Takımı',


	// Ticaret 持仓页面 持有卖出的总页面

	// Ticaret Detayı 持仓，单条数据详情
	TRADE_HOLD_DETAIL_TITLE: 'Ticaret Bekletme Detayı',

	//理财
	LICAI_LICAI: 'Finans',
	LICAI_REN: 'Kişi',
	LICAI_YUGUSHOUYILV: 'Tahmini verim',
	LICAI_ZHOUQI: 'döngü',
	LICAI_ZUIDIMAIRU: 'Minimum satın alma',
	LICAI_MINGCHENG: 'Ad',
	LICAI_LEIXING: 'Tür',
	LICAI_FAFANGRIQI: 'Yayın Tarihi',
	LICAI_QINGSHURUMEIRUJINE: 'Lütfen satın alma tutarını girin',
	
	LICAI_CHICANG:'Konum',
	LICAI_YISHUHUI:'Kullanıldı',
	LICAI_KEFU:'Müşteri hizmetlerine başvurun',
	WITHDRAW_TIP_TEXT: [`1. Mevcut hisseler satılıncaya kadar geri çekilemez.`, `
	2. Para çekebilmek için para çekmeden önce gerçek isminizi doğrulamanız ve hesabınızı doğrulamanız gerekmektedir.`,
			`3. Para çekme işlem saatleri: Hafta içi 09:00-15:00 (hafta sonları ve resmi tatil günlerinde para çekme işlemlerine izin verilmemektedir).`,
			`4. Para çekme talebi için minimum tutar 10.000'dir.`,
			`5. Para çekme başvurusu yapıldıktan sonra prensip olarak aynı gün belirlenen para çekme hesabına yatırılacaktır.`,
			`※ Ödeme en fazla 2 iş günü (48 saat) içerisinde tamamlanacaktır.`
		],
		ABOUT_US: 'Hakkımızda',
		PAGE_TITLE_DE: 'Hesabı bağla',
		INT_ATIN_CODE: 'Hakkımızda',
	
	
	
}