export default {
	TRANSLATE_TITLE: '언어를 선택하세요',
	  // 底부导航
	  TABBAR_HOME: "홈",
	  TABBAR_FOLLOW: "금융",
	  TABBAR_MARKET: '시장',
	  TABBAR_TRADE: '무역',
	  TABBAR_ACCOUNT: '계정',
	
	  // 账户管理注关 登入、注册
	  SIGN_IN: "로그인",
	  SIGN_UP: "계정 만들기",
	  SIMGN_OUT: "로그아웃",
	  GO_TO_SIGN_IN: '로그인으로 이동',
	  USER_NAME: '계정',
	  ENTER_USER_NAME: '이메일 계정을 입력하세요',
	  비밀번호: '비밀번호',
	  ENTER_PASSWORD: '비밀번호를 입력하세요',
	  VERIFY_PASSWORD: '비밀번호 확인',
	  ENTER_VERIFY_PASSWORD: '비밀번호를 입력하세요',
	  INVITATION_CODE: '초대 코드',
	  INT_ATIN_CODE: '회사 소개',
	  ENTER_INVITATION_CODE: '코드를 입력하세요',
	  TIP_PWD_NOEQUAL: '두 번 입력한 비밀번호가 일치하지 않습니다.',
	  TIP_SUCCESS_SIGNIN: '성공적으로 로그인',
	  TIP_SUCCESS_REGISTER: '등록이 완료되었습니다. 로그인해주세요',
	  TIP_SIGNIN_ING: '로그인 중',
	  TIP_SIGNUP_ING: '등록 중',
	  TIP_REMEMBER_PWD: '비밀번호 기억',
	  API_TOKEN_EXPIRES: '토큰이 만료됩니다. 다시 로그인하세요',
	  TIP_SIGN_OUT_SUCCESS: '로그아웃 성공',
	  TIP_AGREE: '동의합니다',
	  TIP_PRVITE_PACT: '비공개 및 계약',
	  TIP_CHECK_AGREE: '동의함을 선택해주세요',

	// 变更登入密码、变更支付密码、变更账户信息
	TIP_OLD_PWD: '원래 비밀번호를 입력하세요',
  TIP_NEW_PWD: '새 비밀번호를 입력하세요',
  TIP_NEW_PWD_VERIFY: '새 비밀번호를 다시 입력하세요',

	// 提款页面
	PAGE_TITLE_WITHDRAW: '철회',
	  WITHDRAW_AMOUNT: '내 자산',
	  WITHDRAW_TITLE: "자금 인출",
	  TIP_AMOUNT_AVAIL: '사용 가능한 금액',
	  WITHDRAW_WITH_AMOUNT: '인출 금액',
	  TIP_AMOUNT_WITHDRAW: '인출 금액을 입력하세요',
	  WITHDRAW_PAY_PWD: '출금 비밀번호',
	  TIP_WITHDRAW_PWD: '결제 비밀번호 입력',
	  WITHDRAWING_POST_TIP: '처리 중....',
	// 提款说明
	WITHDRAW_TIP_TEXT: [`1. 현재 보유 주식이 매각될 때까지 출금이 불가능합니다.`,`
	2. 출금을 위해서는 반드시 실명인증과 계좌인증을 거쳐야 출금이 가능합니다.`,
	  `3. 출금거래시간 : 평일 09:00~15:00 (주말 및 공휴일에는 출금 불가)`,
	  `4. 출금을 요청할 수 있는 최소 금액은 10,000 입니다.`,
	  `5. 출금신청 후 지정된 출금계좌로 당일 입금을 원칙으로 합니다.`,
	  `※ 결제는 영업일 기준 최대 2일(48시간) 이내에 완료됩니다.`
	  ],
	// 入金页面
	PAGE_TITLE_DEPOSIT: '입금',
	  PAGE_TITLE_DE: '계정 바인딩',
	  DEPOSIT_TIP_DEPOSIT_AMOUNT: '충전 금액 입력',
	  DEPOSIT_TIP_LOW_AMOUNT: '최소 1,000,000',
	  DEPOSIT_POST_TIP: '처리 중....',
	  DEPOSIT_TIP_TITLE: '알림',
	  DEPOSIT_UPLOAD_TITLE:'이미지 업로드',
	  DEPOSIT_TIP_TEXT: ['1. 충전시간 : 평일 09:00~18:00, 공휴일 휴무',
	  '우리를 선택해 주셔서 감사합니다. 자금의 안전을 보장하기 위해 이체하려는 계좌가 당사 플랫폼에 실시간으로 표시되는 계좌인지 확인하고, 비은행계좌에서 자금을 이체할 때마다 당사 직원에게 확인하시기 바랍니다. 계정은 우리 플랫폼에 실시간으로 표시되며 예금으로 인해 발생하는 모든 손실에 대한 책임은 귀하에게 있습니다.'
	  ],

	// 个人中心页面
	ACCOUNT_CHANGE_PWD: '로그인 비밀번호 변경',
	  ACCOUNT_TRADE_LOG: '자본 흐름',
	  ACCOUNT_SERVICE: '서비스',
	  ACCOUNT_AMOUNT_TOTAL: '총 자산',
	  ACCOUNT_AMOUNT_AVAILABLE: '사용 가능한 자금',
	  ACCOUNT_MORE_FEATURES: '추가 기능',

	// 交易记录页面
	TRADE_LOG_BTNS: ['세부정보', '입금', '출금'],
	  TRADE_LOG_TIP_MODAL_TITLE: '출금 요청을 취소하시겠습니까?',
	  TRADE_LOG_WITHDRAW_STATUS: ['검토중', '철회 성공',
	  '출금 실패, 고객센터로 연락주세요', '거부'
	  ],
	  LOG_TRADE_AMOUNT_BEFORE: '거래 전 잔액',
	  LOG_TRADE_AMOUNT_AFTER: '거래 후 잔액',
	  LOG_TRADE_DW: '거래 금액',
	  LOG_TRADE_CREATE_TIME: '시간',
	  LOG_TRADE_DESC: '세부정보',
	  LOG_TRADE_ORDER_SN: '주문 Sn',
	  LOG_TRADE_DW_DESC: '거래 설명',
	  LOG_WITHDRAW_AMOUNT: '출금 금액',
	  LOG_STATUS: '상태',


	// 交易页面
	TRADE_TITLE: '투자 결과',
	  TRADE_TABS: ['기록 보유', '기록 판매'],
	  TRADE_TOTAL_BUY_AMOUNT: '총 구매액',
	  TRADE_VALUATION_GAIN_LOSS: '손익',
	  TRADE_VALUATION_GAIN_LOSS_AMOUNT: '평가 금액',
	  TRADE_RATE_RESPONSE: '응답률',
	  TRADE_TOTAL_GAIN: '총 이익',
	// 持仓和卖出的记录 表头
	TRADE_LIST_THEAD: ['이름', '이익', '수량 보유', '평가', '가격', '가격'],
	  TRADE_MOADL_TITLE: '주문',
	// 订单的label组
	TRADE_MODAL_LABELS: ['이름', '구매 시간', '판매 시간', '이익', '레버', '총 이익', '가격', '수량', '수수료',
	  '총액', '코드'
	  ],
	// 卖出的二次确认
	SELL_TIP: '판매를 확인하시겠습니까?',


	// IPO 交易
	PAGE_TITLE_TRADE_IPO: 'IPO',
	  TRADE_IPO_TABS: ['상품', '기록', '성공'],
	  TRADE_IPO_MODAL_TITLE: '공모주식 청약신청',
	  TRADE_IPO_MODAL_CONTENT: '구독을 신청하려면 확인을 클릭하세요.',
	  TADE_IPO_SUB_PRICE: '구독',
	  TRADE_IPO_PE_RATE: 'PER 비율',
	  TRADE_IPO_SUB_CT: '구독 시간',
	  TRADE_IPO_POST_QTY: '유통',
	  TRADE_IPO_RAISE_MONEY: '자금 모금',
	  TRADE_IPO_LOG_LABELS: ['구독 가격', 'P/E 비율', '구독 시간', '주기'],
	  TRADE_IPO_SUCCESS_TITLE: 'IPO 구독 성공 기록',
	  TRADE_IPO_SUCCESS_APPLY_AMOUNT: '구독 수량',
	  TRADE_IPO_SUCCESS_AMOUNT: '승리',
	  TRADE_IPO_SUCCESS_NUM_AMOUNT: '금액',
	  TRADE_IPO_SUCCESS_ORDER_SN: '주문 번호',
	  TRADE_IPO_SUCCESS_CT: '날짜 시간',


	// 单股详情页面
	PAGE_TITLE_STOCK_OVERVIEW: '주식 세부정보',
	// 股票最新数值
	STOCK_INFO_TITLES: ['시장 가격', '종가', '고가', '저가', '거래량',
	  '거래금액'
	  ],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['분', '일', '달'],
	// 单股购买页面
	STOCK_BUY_QUANTITY: '수량',
	  STOCK_BUY_TIP_QUANTITY: '수량 입력',
	  STOCK_BUY_AMOUNT: '결제 금액',
	  STOCK_BUY_FEE: '수수료',
	  STOCK_BUY_CONFIRM: '구매',
	
	  레버: '레버',
	  STOCK_ALL: '재고 목록',
	  STOCK_FOLLOW: '팔로우 목록',
	// 首页股票列表表头
	STOCK_THEAD: ['이름', '가격', '비율'],
	  PAGE_TITLE_NOTIFICATION: '알림',
	  PAGE_TITLE_SEARCH: '검색',
	  TIP_SEARCH: '키워드 입력',
	  SEARCH_HISTORY: '검색 기록',
	// 折价交易
	PAGE_TITLE_TRADE_DISCOUNT: '보상 판매',
	  TIP_POST_SUCCESS: '성공',
	  ABOUT_US: '회사 소개',
	  CURRENCY_UNIT: '',
	  QUANTITY_UNIT: '',
	  UNIT_BILION: '십억',
	  UNIT_POS: '위치',
	  UNIT_DAY: '일',
	  더보기: '더보기',
	  간략한: '간단한',
	  EMPTY_NOTIFIY: '빈 알림',
	  EMPTY_DATA: '빈 데이터',
	  BTN_CONFIRM: '확인',
	  BTN_CANCEL: '취소',
	  BTN_SEND_SERVICE: '고객 서비스에 문의',
	  BTN_DETAIL: '세부정보',
	  BTN_BUY: '구매',
	  BTN_SELL: '매도',
	  STATUS_LOADING: "로드 중",
	  STATUS_SUBMIT: '제출 중',
	  STATUS_REQUEST: '새 데이터 가져오기',
	  STATUS_HTTP_ERROR: '예외 요청, 재시도 중',
	  STATUS_UPLOAD: "업로드 중",

	// =============================
	// 网络检查及网络状态
	TIP_NETWORK_TYPE_NONE: '네트워크가 없거나 네트워크 상태가 좋지 않습니다.',

	// API 相关提示
	API_TOKEN_EXPIRES: '로그인 상태가 만료되었습니다. 다시 로그인하세요.',
	  API_HTTP_ERROR: '요청이 비정상입니다. 네트워크를 확인하세요.',
	  REQUEST_DATA: '요청 데이터',
	  API_EMPTY_DATA: '빈 데이터',
	  API_EMPTY_CONTENT: '빈 콘텐츠',
	  API_SIGN_IN_NOW: '로그인',
	  API_SIGN_UP_NOW: '등록 중',
	  API_DATA_SUBMIT: '제출 중',
	  API_POST_SUCCESS: '성공',

	// 复制成功
	TIP_COPY_SUCCESS: '복사 성공',


	COIN_LIST_TITLE: '코인 목록',// Coin 列表 标题

	TRADE_RECORD_TITLE: '기록', // 交易记录

	MARKET_TAB_COIN: '코인',// 市场 coin
	MARKET_TAB_TRACK: '추적', // 市场 收藏

	// Coin OverView 币 详情页面 [分 日 月]
	COIN_VIEW_TAB_MINUTE: '분',
	  COIN_VIEW_TAB_DAILY: '매일',
	  COIN_VIEW_TAB_MONTHLY: '월별',
	// COIN_VIEW_BTN_BUY: '매수',
	  // COIN_VIEW_BTN_SELL: '매도',
	  // 코인 구매 및 판매
	COIN_VIEW_QUANTITY: '수량',
	  COIN_VIEW_AVAILABLE_AMOUNT: '사용 가능 금액',
	  COIN_VIEW_PAYMENT_AMOUNT: '결제 금액',
	  COIN_VIEW_UNIT: '단위',
	  COIN_VIEW_ENTER_QUANTITY: '수량을 입력하세요',
	  COIN_MODAL_COMFIRM: '확인',
	  COIN_MODAL_CANCEL: '취소',
	  COIN_MODAL_WANT_TO: '하고 싶다',
	
	  COIN_BAY_SELECT_PRICE_TYPE: '가격 모드 선택',
	  COIN_BAY_ENTER_AMOUNT: '금액을 입력하세요',

	// Wealth 交易
	TRADE_WEALTH_TITLE: '부',
	  TRADE_WEALTH_RECORD_TITLE: '자산 기록',
	  TRADE_WEALTH_HOLD_RECORD: '기록 보유',
	  TRADE_WEALTH_HISTORY: '역사',
	  TRADE_WEALTH_NEW_USERS: '신규 사용자',
	  TRADE_WEALTH_BUY_DETAIL: '구매 세부정보',
	  TRADE_WEALTH_RATE: '비율',
	  TRADE_WEALTH_CYCLE: '주기',
	  TRADE_WEALTH_CYCLE_UNIT: '일',
	  TEADE_WEALTH_MIN_PRICE: '최소 가격',
	// 买入弹层
	TRADE_WEALTH_BUY_AMOUNT: '금액을 입력하세요',
	  TRADE_WEALTH_BUY_AMOUNT_TIP: '금액은 최소 가격보다 커야 합니다',
	// 持有列表
	TRADE_WEALTH_HOLD_RATE: '요율',
	  TRADE_WEALTH_HOLD_CYCLE: '주기',
	  TRADE_WEALTH_HOLD_PRICE: '가격',
	
	TRADE_WEALTH_HOLD_NUM: '숫자',
	  TRADE_WEALTH_HOLD_PROFIT: '카베자라르',
	
	TRADE_WEALTH_HOLD_PAY_PRICE: '지불 가격',
	// TRADE_WEALTH_HOLD_PROFIT: '이익',
	TRADE_WEALTH_HOLD_SN: 'SN',
	  TRADE_WEALTH_HOLD_CRETIME: '시간 생성',
	  TRADE_WEALTH_HOLD_ENDTIME: '종료 시간',


	// 汇款
	ACCOUNT_LIST_REMITTANCE: '송금',
	// 汇款页面
	REMITTANCE_TITLE: '송금',

	// 等级 团队页面
	ACCOUNT_LEVEL_TITLE: '레벨',
	  LEVEL_CURRENT_LEVEL: '현재 레벨',
	  LEVEL_CURRENT_TEAM: '현재 팀',
	  LEVEL_DESC_TITLE: '레벨 설명',
	  LEVEL_NEXT_LEVEL: '다음 레벨',
	  LEVEL_SELF_HOLD_MONEY: '자체 보유 자금',
	  LEVEL_L1_TEAM_USERS: 'L1 팀 사용자',
	  LEVEL_L1_TEAM_MONEY: 'L1 팀 머니',
	  LEVEL_L2_TEAM_USERS: 'L2 팀 사용자',
	  LEVEL_L2_TEAM_MONEY: 'L2 팀 머니',
	  LEVEL_TEAM_LIST_HEAD_MOBILE: '모바일',
	  LEVEL_TEAM_LIST_HEAD_AMOUNT: 'Weathl 금액',
	  LEVEL_L1_TEAM: 'L1 팀',
	  LEVEL_L2_TEAM: 'L2 팀',

	// Trade  持仓页面 持有卖出的总页面
	
	// Trade Detail 持仓，单条数据详情
	TRADE_HOLD_DETAIL_TITLE:'거래 보류 세부정보',
	
	//理财
	LICAI_LICAI:'금융',
	LICAI_REN:'사람',
	LICAI_YUGUSHOUYILV:'예상 생산량',
	LICAI_ZHOUQI:'주기',
	LICAI_ZUIDIMAIRU:'최소 구매',
	LICAI_MINGCHENG:'이름',
	LICAI_LEIXING:'유형',
	LICAI_FAFANGRIQI:'출시일',
	LICAI_QINGSHURUMEIRUJINE:'구매 금액을 입력하세요',
	LICAI_CHICANG:'위치',
	LICAI_YISHUHUI:'구속됨',
	INT_ATIN_CODE: '회사 소개',
	LICAI_KEFU:'고객 서비스에 문의하세요',
}