<template>
	<view style="display: flex;align-items: center;justify-content: space-around;margin:0 10px;padding: 10px;">
		<block v-for="(item,index) in tabs" :key='index'>
			<view @click="handleChange(index)"
				style="padding: 4px 10px; width: 25%;text-align: center;border-radius: 8px;font-size: 28rpx;line-height: 1.8;"
				:style="setActiveStyle(acitve ==index)">{{item}}</view>
		</block>
	</view>
</template>

<script>
	import theme from '@/common/theme.js';
	export default {
		name: 'TabsPrimary',
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 自定义颜色
			color: {
				type: String,
				default: theme.TITLE,
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				current:this.acitve,
			};
		},
		methods: {
			handleChange(val) {
				this.current = val;
				this.$emit('action', this.current);
			},
			setActiveStyle(val) {
				return {
					backgroundColor: val ? theme.PRIMARY : '#FFFFFF',
					color: val ? '#FFF' : this.color,
				}
			},
		}
	}
</script>