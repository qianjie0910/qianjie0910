<template>
	<view style="padding:10px;">
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		
		<template v-else>
			<view style="display: flex;align-items: center;padding:10px;"  @click="linkInfo('xau')">
				<view style="width: 80rpx;margin:auto 0;">
					<image src="/static/xau.png" mode="widthFix" style="width: 40px;height: 40px;"></image>
				</view>
				<view style="flex: 0 0 40%;padding-left: 6px;font-size: 36rpx;color:#121212">
					<view>XAU</view>
					<view :style="{color:$theme.LABEL}" style="font-size: 24rpx;">xau</view>
				</view>
				<view style="margin-left: auto;text-align: right;">
					<view :style="$util.setStockRiseFall(xau.rate>0)">
						<image :src="`/static/arrow_${xau.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$util.setImageSize(24)"></image>
						{{xau.rate}}%
					</view>
					<view style="font-weight: 800;font-size: 32rpx;color: #333333;">
						{{xau.current_price}}
					</view>
			
				</view>
			</view>
			<block v-for="(item,index) in list" :key="index">
				<view style="display: flex;align-items: center;padding:10px;" @click="linkInfo(item.code)">
					<template v-if="item.logo">
						<view style="width: 80rpx;margin:auto 0;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
					</template>
					<view style="flex: 0 0 40%;padding-left: 6px;font-size: 36rpx;color:#121212">
						<view>{{item.name}}</view>
						<view :style="{color:$theme.LABEL}" style="font-size: 24rpx;">{{item.code}}</view>
					</view>
					<view style="margin-left: auto;text-align: right;">
						<view :style="$util.setStockRiseFall(item.rate>0)">
							<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$util.setImageSize(24)"></image>
							{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
						</view>
						<view style="font-weight: 800;font-size: 32rpx;color: #333333;">
							{{item.current_price}}
						</view>

					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				gpIndex: 0,
				curPage: 1, // 当前页码
				list: {},
				socket: null, // websocket
				xau:{
					rate:"",
					current_price:"",
				}
			};
		},
		created() {
			this.getList();
			this.xau_ws();
			this.xau_data()
		},
		
		deactivated() {
			this.disconnect();
			
		},
		methods: {
			// 跳转到详情
			linkInfo(code) {
				uni.navigateTo({
					url: this.$paths.COIN_OVERVIEW + `?code=${code}`
				});
			},
			// 产品详情
			async xau_data() {
				const result = await this.$http.get(`api/product/info`, {
					code: "xau",
					time_index: 1
				});
				if (!result) return false;
				this.xau = result[0];
			},
			xau_ws() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Xau_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						// console.log('成功', res);
					},
					fail: (res) => {
						// console.log('fail', res);
					}
				})
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					// console.info("监听WebSocket连接打开事件", res)
				});
			
				// 监听WebSocket错误
				uni.onSocketError((res) => {
					// console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					this.xau.current_price=data.last_numeric
					this.xau.rate=data.pcp
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					
				});
			},
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
					},
					fail: (res) => {
					}
				})
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					// console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					// console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.list[data.market] && data.market && data.lastPrice > 0) {
						this.list[data.market].current_price = data.lastPrice;
						this.list[data.market].rate = data.rate || 0;
						this.list[data.market].vol = data.vol || 0;
					}
				});
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					this.socket = null;
				}
			},

			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods/list`, {
					page: this.curPage,
					gp_index: this.gpIndex
				});
				if (!result) return false;
				this.list = result;
				this.connect(); // 启动 websocket链接
			}
		}
	}
</script>