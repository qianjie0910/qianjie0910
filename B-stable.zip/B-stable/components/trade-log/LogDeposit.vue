<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="common_block" style="margin-bottom:20px;padding:10px;border-radius: 10px;line-height: 1.6;">
				<view style="text-align: right;" :style="{color:$theme.RISE}">
					{{item.desc_type}}
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_DW}}
					</view>
					<view :style="{color:$theme.PRIMARY}"
						style="flex:70%;font-size: 18px;font-weight: 700;text-align: right;">
						{{$util.formatNumber(item.money)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_ORDER_SN}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_DW_DESC}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:6%;">
						<image :src="item.icon" :style="$util.setImageSize(24)"></image>
					</view>
					<text style="flex:97%;white-space:pre-wrap;" :style="{color:item.color}">{{item.text}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogDeposit",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/user/recharge`);
				if (!result) return false;
				this.list = result;
			},
		}
	}
</script>

<style>

</style>