<template>
	<view>
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="display: flex;align-items: center;padding:10px;" @click="linkInfo(item)">
					<template v-if="item.logo">
						<view style="width: 80rpx;margin:auto 0;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
					</template>
					<view style="flex: 0 0 40%;padding-left: 6px;font-size: 36rpx;" :style="{color:$theme.TITLE}">
						<view>{{item.name}}</view>
						<view :style="{color:$theme.LABEL}" style="font-size: 24rpx;">{{item.code}}</view>
					</view>
					<view style="margin-left: auto;text-align: right;">
						<view :style="$util.setStockRiseFall(item.rate>0)">
							<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$util.setImageSize(24)"></image>
							{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
						</view>
						<view style="font-weight: 800;font-size: 32rpx;color: #333333;">
							{{item.current_price}}
						</view>

					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import {
		STOCK_OVERVIEW
	} from '@/common/paths.js';

	import {
		wsbiUrl
	} from '@/common/http.js';

	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'ListPrimary',
		components: {
			EmptyData,
			CustomLogo,
		},
		props: {
			// 列表数据
			list: {
				type: Array,
				default: []
			},
			// 是否需要序号
			serial: {
				type: Boolean,
				default: false,
			}
		},
		mounted() {
			this.sockets();
		},
		methods: {
			sockets() {
				//创建webSocket
				this.webSocketTask = uni.connectSocket({
					url: wsbiUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
					},
				})

				this.webSocketTask.onOpen((res) => {
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
				});
				// 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data = JSON.parse(res.data);
					// console.log(data);

					if (this.list[data.market] && data.market && data.lastPrice > 0) {
						this.list[data.market].current_price = data.lastPrice
						this.list[data.market].rate = data.rate
						this.list[data.market].rate_num = data.rate_num
					}
					// console.log(data);

				});
			},
			// 跳转到股票详情
			linkInfo(item) {
				if (!item.code || item.code == '') return false;
				// 1:coin 2:stock
				const temp = item.project_type_id == 1 ?
					this.$paths.COIN_OVERVIEW : this.$paths.STOCK_OVERVIEW;
				uni.navigateTo({
					url: `${temp}?code=${item.code}`
				});
			}
		}
	}
</script>

<style>
</style>