<!-- 用户基本信息 -->
<template>
	<view>
		<view style="display: flex;align-items: center;padding-bottom: 10px;margin:0 40rpx;">
			<view style="flex:20%;text-align: center;">
				<image style="border-radius: 100px;" mode="aspectFit" :src="info.avatar?info.avatar:'/static/logo.png'"
					:style="$util.setImageSize(100)"></image>
			</view>
			<view style="flex:60%;padding-left: 10px;">
				<view style="font-size: 36rpx;text-align: left;color:#121212;">
					{{info.nick_name}}
				</view>
				<view style="font-size:26rpx;text-align: left;color:#3C1E20;">
					{{info.mobile}}
					<!-- {{info.p_mobile}} -->
				</view>
			</view>
			<view @click="linkLevel()">
				<image :src="`/static/level${info.level}.png`" mode="aspectFit" style="width: 200rpx;height: 60rpx;">
				</image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {};
		},
		methods: {
			// 进入等级页面
			linkLevel() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_LEVEL,
				})
			},
		}
	}
</script>

<style>

</style>