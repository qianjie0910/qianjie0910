<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`340rpx`,`bg_1`)">
		<HeaderPrimary isSearch :title="$lang.TABBAR_HOME" color="#FFFFFF"> </HeaderPrimary>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view> -->

		<view style="margin-top: 10rpx;">
			<ButtonGroup></ButtonGroup>
		</view>

		<view style="background-color: #FFFFFF;display: flex;align-items: center;flex-wrap: wrap;">
			<view style="margin:20rpx 10rpx 10rpx 24rpx;flex:40%;" @click="linkDeposit()">
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding:30rpx;background-color: #E8F5FE;border-radius: 24rpx;">
					<view>{{$lang.DEPOSIT_TITLE}}</view>
					<image src="/static/top4.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
			</view>
			<view style="margin:20rpx 24rpx 10rpx 10rpx;flex:40%;" @click="linkWithdraw()">
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding:30rpx;background-color: #FFF7F2;border-radius: 24rpx;">
					<view>{{$lang.WITHDRAW_TITLE}}</view>
					<image src="/static/top5.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
			</view>
			<view style="margin:10rpx 10rpx 20rpx 24rpx;flex:40%;" @click="linkAuth()">
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding:30rpx;background-color: #F2F2FE;border-radius: 24rpx;">
					<view>{{$lang.AUTH_TITLE}}</view>
					<image src="/static/top6.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
			</view>
			<view style="margin:10rpx 24rpx 20rpx 10rpx;flex:40%;" @click="linkService()">
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding:30rpx;background-color: #F1F4FE;border-radius: 24rpx;">
					<view>{{$lang.ACCOUNT_SERVICE}}</view>
					<image src="/static/top7.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
			</view>
		</view>

		<TrackList></TrackList>

		<MarketNews></MarketNews>

		<view style="padding:20rpx;background-color: #FFFFFF;">
			<view style="padding:0 20rpx;">
				<TitleSecond :title="$lang.STOCK_ALL">
					<view style="font-size: 13px;margin-left: auto;" @click="linkAllList()"
						:style="{color:$theme.SECOND}">
						{{$lang.MORE}}
						<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
					</view>
				</TitleSecond>
			</view>
			<view style="height: 1px;background-color:#E5E5E5;"></view>

			<MarketHot ref="hot"></MarketHot>
		</view>

		<!-- IPO申购成功弹层 -->
		<IPOSuccessAlert></IPOSuccessAlert>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import TrackList from './components/TrackList.vue';
	import MarketNews from './components/MarketNews.vue';
	import MarketHot from './components/MarketHot.vue';
	import IPOSuccessAlert from './components/IPOSuccessAlert.vue';
	export default {
		components: {
			HeaderPrimary,
			ButtonGroup,
			TitleSecond,
			TrackList,
			MarketNews,
			MarketHot,
			IPOSuccessAlert,
		},
		data() {
			return {
				isAnimat: false, // 页面动画	
			}
		},
		computed: {
			// 今日
			setToday() {
				return this.$util.formatToday(new Date());
			}
		},

		onLoad() {},
		onShow() {
			this.isAnimat = true;
			if (this.$refs.hot) this.$refs.hot.getList();
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
			this.closeAll();
		},
		onUnload() {
			this.closeAll();
		},
		deactivated() {
			this.closeAll();
		},

		methods: {
			// 关闭子組件 websocket 及定時器
			closeAll() {
				if (this.$refs.hot) this.$refs.hot.disconnect();
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				this.$util.linkCustomerService();
			},

			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=1`,
				})
			},
		},
	}
</script>