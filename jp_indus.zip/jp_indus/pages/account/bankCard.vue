<!-- 绑定银行卡 -->
<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`520rpx`,`bg_1`)">
		<HeaderSecond :title="$lang.BIND_BANK_CARD_TITLE" color="#FFFFFF"></HeaderSecond>
		<view style="display: flex;align-items: center;justify-content: center;margin-top: 20rpx;">
			<image src="/static/bank_card.png" mode="aspectFit" :style="$theme.setImageSize(200,220)"></image>
		</view>
		<view style="background-color: #FFFFFF;min-height: 90vh;margin-top:40rpx;padding:40rpx">
			<TitleSecond :title="$lang.BIND_BANK_CARD_REAL_NAME"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<input v-model="info.realName" type="text" :placeholder="$lang.BIND_BANK_CARD_REAL_NAME"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<TitleSecond :title="$lang.BIND_BANK_CARD_BANK_NAME"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<input v-model="info.bankName" type="text" :placeholder="$lang.BIND_BANK_CARD_BANK_NAME"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>
			<TitleSecond :title="$lang.BIND_BANK_CARD_BANK_SUB_NAME"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<input v-model="info.bank_sub_name" type="text" :placeholder="$lang.BIND_BANK_CARD_BANK_SUB_NAME"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>
			<TitleSecond :title="$lang.BIND_BANK_CARD_BANK_SUB_CODE"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<input v-model="info.zd_number" type="text" :placeholder="$lang.BIND_BANK_CARD_BANK_SUB_CODE"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>
			<TitleSecond :title="$lang.BIND_BANK_CARD_TYPE"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<input v-model="info.qy_type" type="text" :placeholder="$lang.BIND_BANK_CARD_TYPE"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<TitleSecond :title="$lang.BIND_BANK_CARD_ID"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<input v-model="info.cardSN" type="text" :placeholder="$lang.BIND_BANK_CARD_ID"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>
			<TitleSecond :title="$lang.PAY_PASSWORD"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<input v-model="info.pay_pass" type="text" :placeholder="$lang.PAY_PASSWORD"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>
		</view>
		<view style="height: 200px;"></view>
		<view style="position: fixed;bottom: 0;left: 0;right: 0;background-color: #FFFFFF;padding:40rpx">
			<view class="common_btn" style="margin:0 auto;width: 80%;" @click="handleSubmit()">
				連携
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		components: {
			HeaderSecond,
			TitleSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: {},
			};
		},
		computed: {
			isRtl() {
				return this.$util.isRtl();
			},
		},
		onLoad() {

		},
		onShow() {
			this.getAccountInfo()
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 检查表单
			checkForm() {
				if (this.info.realName == '') {
					uni.showToast({
						title: this.$lang.TIP_BIND_BANK_CARD_REAL_NAME,
						icon: 'none'
					});
					return false;
				}
				if (this.info.bankName == '') {
					uni.showToast({
						title: this.$lang.TIP_BANK_NAME,
						icon: 'none'
					});
					return false;
				}
				if (this.info.cardSN == '') {
					uni.showToast({
						title: this.$lang.TIP_BANK_CARD,
						icon: 'none'
					});
					return false;
				}
				if (this.info.bank_sub_name == '') {
					uni.showToast({
						title: this.$lang.BIND_BANK_CARD_BANK_SUB_NAME,
						icon: 'none'
					});
					return false;
				}
				if (this.info.zd_number == '') {
					uni.showToast({
						title: this.$lang.BIND_BANK_CARD_BANK_SUB_CODE,
						icon: 'none'
					});
					return false;
				}
				if (this.info.qy_type == '') {
					uni.showToast({
						title: this.$lang.BIND_BANK_CARD_TYPE,
						icon: 'none'
					});
					return false;
				}
				if (this.info.pay_pass == '') {
					uni.showToast({
						title: 'パスワードをご記入下さい',
						icon: 'none'
					});
					return false;
				}
				return true;
			},
			// 提交事件
			handleSubmit() {
				if (this.checkForm()) {
					this.bindCard();
				}
			},

			// 换绑银行卡
			async bindCard() {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'loading',
				});
				const result = await this.$http.post(`api/user/bindBankCard`, {
					realname: this.info.realName,
					bank_name: this.info.bankName,
					card_sn: this.info.cardSN,
					bank_sub_name: this.info.bank_sub_name,
					zd_number: this.info.zd_number,
					qy_type: this.info.qy_type,
					pay_pass: this.info.pay_pass,
				})
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000)
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				// 未有真实姓名，跳转到实名认证
				if (!result.real_name) {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_AUTH,
					})
				}
				if (result.bank_card_info) {
					this.info = {
						realName: result.bank_card_info.realname || '',
						bankName: result.bank_card_info.bank_name || '',
						cardSN: result.bank_card_info.card_sn || '',
						bank_sub_name: result.bank_card_info.bank_sub_name || '',
						zd_number: result.bank_card_info.zd_number || '',
						qy_type: result.bank_card_info.qy_type || '',
						pay_pass: result.bank_card_info.pay_pass || '',
					}
				}
			},
		},
	}
</script>