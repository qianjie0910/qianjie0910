<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="header_bg">
			<header class="common_header">
				<view class="left" @click="linkSearch()">
					<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(36)"></image>
				</view>
				<text class="center"> </text>
				<view class="right" @click="linkService()">
					<image src="/static/service.png" mode="aspectFit" :style="$theme.setImageSize(36)"></image>
				</view>
			</header>

			<Profile :info="userInfo"></Profile>

			<view style="position: absolute;left: 0;right: 0;bottom:0;">
				<view
					style="display: flex;justify-content: space-between;margin:30rpx 60rpx;margin:0 40rpx;background-color: #f7cb92;border-radius: 8rpx 8rpx 0 0;">
					<view
						style="width: 40%;color:#5F390B;padding: 20rpx;line-height: 1.4;text-align: center;font-size: 32rpx;font-weight: 500;"
						@click="linkDeposit()">
						{{$lang.DEPOSIT_TITLE}}
					</view>
					<view style="width: 1px;padding: 20rpx 0;line-height: 1.4;color:#5F390B;"> | </view>
					<view
						style="width: 40%;color:#5F390B;padding: 20rpx;line-height: 1.4;text-align: center;font-size: 32rpx;font-weight: 500;"
						@click="linkWithdraw()">
						{{$lang.WITHDRAW_TITLE}}
					</view>
				</view>
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;margin: 20rpx 0;">
			<view class="common_card_bg card_bg_4" style="width: 640rpx;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view style="background-color: #FFFFFF;margin:20rpx;border-radius: 32rpx 32rpx 0 0;">
			<view
				style="margin:40rpx 40rpx 0 40rpx;font-size: 36rpx;font-weight: 700;line-height: 2.4;border-bottom: 1px solid #F3F3F3;"
				:style="{color:$theme.SECOND}">
				{{$lang.ACCOUNT_MORE_FEATURES}}
			</view>
			<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

			<view style="margin-top: 120rpx;padding-bottom: 60rpx;">
				<SignOut></SignOut>
			</view>
		</view>


	</view>
</template>

<script>
	// import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			// HeaderPrimary,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemPrimary
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.freeze || 0,
				};
			},
		},
	}
</script>


<style lang="scss" scoped>
	.header_bg {
		background-image: url(/static/bg_1.png);
		background-position: center center;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		width: 100%;
		height: 400rpx;
		position: relative;
	}

	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-top: 30px;

		/* background-image: linear-gradient(180deg, #F5B71C, transparent); */
		.left {
			margin-right: auto;
		}

		.right {
			margin-left: auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 700;
			// flex: 70%;
			text-align: center;
		}
	}
</style>