<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`520rpx`,`bg_1`)">
		<HeaderThird :title="$lang.TRADE_ISSUANCE_TITLE" color="#FFFFFF">
			<view style="color:#FFFFFF;" @click="linkRecord()">{{$lang.TRADE_LARGE_RECORD}}</view>
		</HeaderThird>

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 20rpx;">
			<image src="/static/trade_issuance.png" mode="aspectFit" :style="$theme.setImageSize(240,260)"></image>
		</view>

		<view style="background-color: #FFFFFF;min-height: 80vh;margin-top:40rpx;padding:40rpx">
			<TradeIssuanceList ref="list"></TradeIssuanceList>
		</view>

	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import TradeIssuanceList from './components/TradeIssuanceList.vue';
	export default {
		components: {
			HeaderThird,
			TradeIssuanceList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			}
		},
		onShow() {
			this.isAnimat = true;
			if (this.$refs.list)
				this.$refs.list.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_ISSUANCE_RECORD
				})
			}
		},
	}
</script>

<style>
</style>