<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`520rpx`,`bg_1`)">
		<HeaderThird :title="$lang.TRADE_IPO_TITLE" color="#FFFFFF">
			<view style="color:#FFFFFF;width: 70px;" @click="linkRecord()">{{$lang.TRADE_LARGE_RECORD}}</view>
		</HeaderThird>

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 20rpx;">
			<image src="/static/trade_ipo.png" mode="aspectFit" :style="$theme.setImageSize(240,260)"></image>
		</view>

		<view style="background-color: #FFFFFF;min-height: 80vh;margin-top:40rpx;padding:40rpx">
			<TradeIPOList ref="list"></TradeIPOList>
		</view>
	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import TradeIPOList from './components/TradeIPOList.vue';
	export default {
		components: {
			HeaderThird,
			TradeIPOList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			};
		},
		onShow() {
			this.isAnimat = true;
			if (this.$refs.list)
				this.$refs.list.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_IPO_RECORD
				})
			}
		}
	}
</script>