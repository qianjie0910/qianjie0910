<template>
	<view>
		<view style="background-color: #FFFFFF;padding:20rpx 20rpx 10rpx 20rpx;border-radius: 8rpx;margin:20rpx">
			<TitleSecond :title="$lang.TRADE_TITLE"> </TitleSecond>
			<view style="margin:10rpx 0;height: 1px; background-color: #E5E5E5;"></view>

			<view style="display: flex;align-items: center;margin: 20rpx 0;line-height: 1.8;">
				<view style="flex: 1 0 48%; background-color: #F7F9FF;border-radius: 20rpx;">
					<view style="text-align: center;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.TRADE_TOTAL_BUY_AMOUNT}}
					</view>
					<view style="font-size: 32rpx;text-align: center;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatMoney(info.frozen)}}
					</view>
				</view>
				<view style="flex:1 0 4%;"></view>
				<view style="flex: 1 0 48%; background-color: #F7F9FF;border-radius:20rpx;">
					<view style="text-align: center;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.TRADE_VALUATION_GAIN_LOSS}}
					</view>
					<view style="font-size:32rpx;text-align: center;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatMoney(info.holdYingli)}}
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;margin-bottom: 20rpx;line-height: 1.8;">
				<view style="flex: 1 0 48%;background-color: #F7F9FF;border-radius: 20rpx;">
					<view style="text-align: center;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.ACCOUNT_AMOUNT_TOTAL}}
					</view>
					<view style="font-size: 32rpx;text-align: center;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatMoney(info.totalZichan)}}
					</view>
				</view>
				<view style="flex:1 0 4%;"></view>
				<view style="flex: 1 0 48%;background-color: #F7F9FF;border-radius: 20rpx;">
					<view style="text-align: center;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.TRADE_TOTAL_GAIN}}
					</view>
					<view style="font-size:32rpx;text-align: center;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatMoney(info.totalYingli)}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		name: 'AccountTradeInfo',
		components: {
			TitleSecond,
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				// userInfo: {}, // 交易信息
				// cardData: {}, // 资产相关数据
			}
		},
		created() {
			// this.getAccountInfo();
		},
		methods: {
			// 入金 提款 按钮样式
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#F8F8F8' : this.$theme.SECOND,
					borderRadius: `24rpx`,
					padding: `24rpx 0`,
					width: `280rpx`,
				}
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},

			// async getAccountInfo() {
			// 	uni.showLoading({
			// 		title: this.$lang.API_GET_ACCOUNT_INFO
			// 	});
			// 	const result = await this.$http.get(`api/user/info`);
			// 	if (!result) return false;
			// 	this.userInfo = result;
			// 	this.cardData = {
			// 		value1: this.userInfo.totalZichan * 1, // 
			// 		value2: this.userInfo.money, // 
			// 		value3: this.userInfo.freeze, // 
			// 	};
			// },
		}
	}
</script>
<style lang="scss" scoped>
	.charts {
		// width: 720rpx;
		// height: 500rpx;
		width: 680upx;
		height: 500upx;
	}
</style>