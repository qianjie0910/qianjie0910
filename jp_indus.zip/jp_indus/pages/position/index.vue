<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="header_bg">
			<header class="common_header">
				<view class="left" @click="linkSearch()">
					<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(36)"></image>
				</view>
				<text class="center">{{$lang.TRADE_TITLE}}</text>
				<view class="right" @click="linkService()">
					<image src="/static/service.png" mode="aspectFit" :style="$theme.setImageSize(36)"></image>
				</view>
			</header>

			<view style="display: flex;align-items: center;justify-content: space-between;padding:20rpx 40rpx;">
				<view>
					<view style="display: flex;align-items: center; line-height: 1.6;">
						<view style="color:#FFFFFF;font-size: 32rpx;">
							{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
						</view>
						<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`"
							@click.stop="handleShowAmount" :style="$theme.setImageSize(40)" style="margin-left: 10px;">
						</image>
					</view>
					<view style="font-size: 48rpx;font-weight: 500;color:#FFFFFF;line-height: 1.6;">
						{{showAmount?$util.formatMoney(available):hideAmount}}
					</view>
				</view>
				<view>
					<view style="display: flex;align-items: center;">
						<image src="/static/position.png" mode="aspectFit" :style="$theme.setImageSize(180,140)">
						</image>
					</view>
				</view>
			</view>

			<view style="position: absolute;left: 0;right: 0;bottom:0;">
				<view
					style="display: flex;justify-content: space-between;margin:30rpx 60rpx;margin:0 40rpx;background-color: #f7cb92;border-radius: 8rpx 8rpx 0 0;">
					<view
						style="width: 40%;color:#5F390B;padding: 20rpx;line-height: 1.4;text-align: center;font-size: 32rpx;font-weight: 500;"
						@click="linkDeposit()">
						{{$lang.DEPOSIT_TITLE}}
					</view>
					<view style="width: 1px;padding: 20rpx 0;line-height: 1.4;color:#5F390B;"> | </view>
					<view
						style="width: 40%;color:#5F390B;padding: 20rpx;line-height: 1.4;text-align: center;font-size: 32rpx;font-weight: 500;"
						@click="linkWithdraw()">
						{{$lang.WITHDRAW_TITLE}}
					</view>
				</view>
			</view>
		</view>

		<template v-if="userInfo">
			<AccountTradeInfo :info="userInfo"></AccountTradeInfo>
		</template>

		<view style="margin-top: 40rpx;background-color: #FFFFFF;border-radius:16rpx;">
			<TabsSeventh :tabs="tabs" @action="changeTab" :acitve="curTab"> </TabsSeventh>

			<template v-if="curTab==0">
				<AccountTradeHoldList ref="hold"></AccountTradeHoldList>
			</template>
			<template v-else>
				<AccountTradeSellList ref="sell"></AccountTradeSellList>
			</template>
		</view>


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsSeventh from '@/components/tabs/TabsSeventh.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import AccountTradeInfo from './components/AccountTradeInfo.vue';
	import AccountTradeHoldList from './components/AccountTradeHoldList.vue';
	import AccountTradeSellList from './components/AccountTradeSellList.vue';

	export default {
		components: {
			HeaderPrimary,
			TabsSeventh,
			TitlePrimary,
			AccountTradeInfo,
			AccountTradeHoldList,
			AccountTradeSellList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				available: '', // 可用額
				userInfo: null, //
			}
		},
		computed: {
			tabs() {
				return [
					this.$lang.TRADE_HOLD_LIST,
					this.$lang.TRADE_HISTORY_LIST,
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad() {
			console.log('load', 111);
			// this.getAccountInfo();
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
			// if (this.$refs.info) {
			// 	this.$refs.info.getAccountInfo();
			// }
			if (this.$refs.hold) {
				this.$refs.hold.curPage = 1;
				this.$refs.hold.list = [];
				this.$refs.hold.getList();
			}
			if (this.$refs.sell) {
				this.$refs.sell.curPage = 1;
				this.$refs.sell.list = [];
				this.$refs.sell.getList();
			}
		},
		onHide() {
			this.isAnimat = false;
		},
		// 觸底加載
		onReachBottom() {
			if (this.curTab == 0 && this.$refs.hold) {
				console.log(this.$refs.hold);
				if (this.$refs.hold.curPage < this.$refs.hold.maxPage) {
					this.$refs.hold.curPage++;
					this.$refs.hold.getList();
				}
			}
			if (this.curTab == 1 && this.$refs.sell) {
				console.log(this.$refs.sell);
				if (this.$refs.sell.curPage < this.$refs.sell.maxPage) {
					this.$refs.sell.curPage++;
					this.$refs.sell.getList();
				}
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			// if (this.$refs.info) {
			// 	this.$refs.info.getAccountInfo();
			// }
			this.getAccountInfo();
			if (this.$refs.hold) {
				this.$refs.hold.curPage = 1;
				this.$refs.hold.list = [];
				this.$refs.hold.getList();
			}
			if (this.$refs.sell) {
				this.$refs.sell.curPage = 1;
				this.$refs.sell.list = [];
				this.$refs.sell.getList();
			}
			uni.stopPullDownRefresh();
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkSearch() {
				uni.navigateTo({
					url: this.$paths.SEARCH
				})
			},
			linkService() {
				this.$util.linkCustomerService();
			},
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				// if (this.$refs.hold) {
				// 	this.$refs.hold.curPage = 1;
				// 	this.$refs.hold.list=[];
				// 	this.$refs.hold.getList();
				// }
				// if (this.$refs.sell) {
				// 	this.$refs.sell.curPage = 1;
				// 	this.$refs.sell.list=[];
				// 	this.$refs.sell.getList();
				// }
			},
			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `${w}rpx`,
					padding: `12rpx 32rpx`,
					color: val ? this.$theme.SECOND : '#CBCBCB',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `4rpx solid ${val? this.$theme.SECOND :this.$theme.TRANSPARENT }`
				}
			},

			// available
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO,
				})
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				console.log(`info result:`, result);
				this.available = !result.money ? 0 : result.money; // 可提
				this.userInfo = result;
			},
		},
	}
</script>


<style lang="scss" scoped>
	.header_bg {
		background-image: url(/static/bg_1.png);
		background-position: center center;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		width: 100%;
		height: 440rpx;
		position: relative;
	}

	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-top: 30px;

		/* background-image: linear-gradient(180deg, #F5B71C, transparent); */
		.left {
			margin-right: auto;
		}

		.right {
			margin-left: auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 700;
			// flex: 70%;
			text-align: center;
		}
	}
</style>