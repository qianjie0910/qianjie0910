<template>
	<view>
		<!-- <view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
			<view class="common_card_bg" style="width: 640rpx;background-color: #F8F8FA;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view> -->
		<view style="display: flex;align-items: center;justify-content: center; line-height: 1.6;">
			<view style="color:#FFFFFF;font-size: 32rpx;">
				{{cardLabels[0]}}
			</view>
			<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click.stop="handleShowAmount"
				:style="$theme.setImageSize(40)" style="margin-left: 10px;">
			</image>
		</view>
		<view style="font-size: 58rpx;font-weight: 700;color:#FFFFFF;line-height: 1.6;text-align: center;">
			{{showAmount?$util.formatMoney(cardData.value1):hideAmount}}
		</view>

		<view class="common_block" style=" padding:20rpx 24rpx;">
			<TitleSecond :title="$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT"></TitleSecond>
			<view class="common_input_wrapper">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$theme.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view>

			<view style="display: flex;align-items: center;flex-wrap: wrap;margin: 30rpx;">
				<block v-for="(item,index) in amountList" :key="index">
					<view
						style="border-radius: 8rpx;width:25%;margin:10rpx;padding:8rpx 10rpx;line-height: 1.6;text-align: center;"
						:style="setStyle(curPos==index)" @click="quantity(item,index)">
						{{$util.formatMoney(item)}}
					</view>
				</block>
			</view>
		</view>

		<view class="common_block" style="padding:24rpx;">
			<TitleSecond :title="$lang.DEPOSIT_TIP_TITLE"></TitleSecond>

			<view style="background-color: #F7F9FF;padding:16rpx;border-radius: 16rpx;margin-top: 12rpx;">
				<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
					<view style="padding-top:16rpx;line-height: 1.6;" :style="{color:$theme.LOG_LABEL}">{{item}}</view>
				</block>
			</view>

		</view>
		<view style="height: 100px;"></view>
		<view style="position: fixed;bottom: 0;left: 0;right: 0;background-color: #FFFFFF;padding:40rpx">
			<view class="common_btn" style="margin:0 auto;width: 80%;" @click="handleSubmit()">
				入金
			</view>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	export default {
		// desc:入金模式 之  带有输入项提交等
		name: 'DepositPrimary',
		components: {
			TitleSecond,
			AccountAssets,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				userInfo: {}, //
				cardData: {},
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_TOTAL_PROFIT
				];
			},
			// 入金金额预置值
			amountList() {
				return [1000000, 3000000, 5000000, 10000000];
			},
		},
		created() {
			this.getAccountInfo()
			this.amount = this.amountList[this.curPos];
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			setStyle(val) {
				return {
					...val ? this.$theme.LG_PRIMARY : this.$theme.LG_SECOND,
					color: val ? '#FFFFFF' : '#121212',
					borderRadius: `44rpx`,
					border: `1px solid ${val? this.$theme.TRANSPARENT:'#5A5A5A'}`
				}
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_TIP_LOW_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					this.$util.linkCustomerService();
				}, 1000)
			},

			//个人信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log(result);
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.money, // 可提
					value2: this.userInfo.freeze, // 冻结
					value3: this.userInfo.totalYingli, // 总盈利
				};
			},
		},
	}
</script>

<style>
</style>