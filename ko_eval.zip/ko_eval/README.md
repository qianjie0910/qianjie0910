# ko_eval
stock evaluation for  korea

# Feature Desc
- 输入股票代码，点击查询
- 弹层中显示处理过程
- 弹出输入手机号的提示
- 显示该股最新数据
- 点击领取评测结果
- 弹出输入手机号的提示


close: 7080  // 现价

extended_price: 0 // 

high: 7140 // 最高

low: 7030 // 最低

lower_limit_price: 5000 //

open: 7140  // 今日开盘

prev_close: 7140 昨日收盘

upper_limit_price: 9280 //

volume: 15552 // 成交量

volume_valued: 109816150 // 成交额