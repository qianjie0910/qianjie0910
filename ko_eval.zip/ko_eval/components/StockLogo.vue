<template>
	<view>
		<template v-if="logo && logo != ''">
			<image :src="setLogo" mode="aspectFit" :style="$theme.setImageSize(60)" style="border-radius: 8px;"></image>
		</template>
		<template v-else>
			<view :style="$theme.setImageSize(60)"
				style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;border-radius: 8px;font-size: 18px;">
				{{setLogo}}
			</view>
		</template>
	</view>
</template>

<script>
	import {
		BASE_URL
	} from '@/common/http.js';
	export default {
		name: 'StockLogo',
		props: {
			logo: {
				type: String,
				default: '',
			},
			// 股票名字，用于切出第一个字符作为LOGO
			name: {
				type: String,
				default: '',
			}
		},
		computed: {
			setLogo() {
				if (this.logo && this.logo != '') {
					return this.logo.includes('http') ? this.logo : BASE_URL + this.logo;
				} else {
					return this.name && this.name.length > 0 ? this.name[0] : '';
				}
			},
		}
	}
</script>