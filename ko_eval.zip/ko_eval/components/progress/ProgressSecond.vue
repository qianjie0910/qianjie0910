<template>
	<view>
		<view style="text-align: center;color: #121212;font-size: 32rpx;margin-top: 40rpx;">
			{{ title }}
		</view>
		<view
			style="position:relative;margin: 120rpx;margin-top: 30rpx; background-color:rgba(255,255,255,0.15);height:10px;border-radius: 20rpx;border: 1px solid #FFFFFF;padding:0 3px;">
			<view :style="setStyle"></view>
		</view>
	</view>
</template>

<script>
	// 横向进度条，带有蒙层，上部带有进度值
	export default {
		name: 'ProgressSecond',
		data() {
			return {
				percentage: 1, // 进度条初始值
				timer: null,
				curStep: 0, // 当前进度
			}
		},

		computed: {
			setStyle() {
				const temp = {
					position: 'absolute',
					bottom: 0,
					left: 0,
					height: '10px',
					width: `${this.percentage}%`,
					backgroundImage: `linear-gradient(90deg, #FBED7B ,#FF533B)`,
					borderRadius: '20rpx',
				};
				return temp;
			},

			setLabels() {
				return [`양가 거래 모델 통과 중...`,
					`VaR 시스템을 통해 위험치를 확인하고 있습니다....`,
					`OLS(최소자승법)를 통해 필요 수익률을 결정하고 있습니다....`,
				]
			},
			// 当前进度的title
			title() {
				return this.setLabels[this.curStep];
			},

		},
		mounted() {
			console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					// console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage = this.percentage + 10;
					} else if (this.percentage >= 100 && this.curStep < this.setLabels.length - 1) {
						this.percentage = 10; // 重新开始计数
						this.curStep++; // 进度+1
					} else {
						this.clearTimer(); // 进度全部走完
						this.$emit('action', this.curStep);
					}
					// console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>