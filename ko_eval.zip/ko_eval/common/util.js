import Vue from 'vue';
import {
	BASE_URL
} from '@/common/http.js';

// // 客服跳转 读取系统配置客服url，外部打开。用于上架
// const linkService = async () => {
// 	const result = Vue.prototype.$http.get(`api/app/config`);
// 	console.log('reslut:', result);
// 	console.log('window:', window);
// 	console.log('navigator:', navigator);
// 	// "CustomerLink"
// 	if (result.code == 0) {
// 		const temp = result.data.reduce((map, item) => {
// 			map.set(item.key, item.value);
// 			return map;
// 		}, new Map());

// 		let url = temp.get('CustomerLink');

// 		if (window.android) {
// 			window.android.callAndroid("open," + url)
// 			return false;
// 		}
// 		if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
// 			.nativeExt) {
// 			window.webkit.messageHandlers.nativeExt.postMessage({
// 				msg: 'open,' + url
// 			})
// 			return false;
// 		}
// 		let u = navigator.userAgent;
// 		let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
// 		if (isiOS) {
// 			window.location.href = url;
// 			return false;
// 		}
// 		window.open(url)
// 	}
// }

// /*
// 跳转到客服，内部分为两种方式：
// 1. 直接跳转到软件内客服页面
// 2. 调用客服跳转函数，用于上架
// */
// const linkCustomerService = () => {
// 	// 1. 直接跳转到软件内客服页面
// 	// uni.navigateTo({
// 	// 	url: Vue.prototype.$paths.SERVICE
// 	// });

// 	// 2.调用客服跳转函数，用于上架
// 	linkService();
// }

// // 计算设计图上带有透明度的值输出为RGBA
// const RGBConvertToRGBA = (hexColor, opacity) => {
// 	const r = parseInt(hexColor.slice(1, 3), 16);
// 	const g = parseInt(hexColor.slice(3, 5), 16);
// 	const b = parseInt(hexColor.slice(5, 7), 16);
// 	const a = opacity / 100;
// 	return `rgba(${r},${g},${b},${a})`;
// };

// 数字值格式化
const formatNumber = (value, fixed = 0) => {
	if (isNaN(value)) return '0';
	let result = Number(value).toFixed(fixed);
	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return result;
};

// 涨跌值样式设置
const setStockRiseFall = (val, isbg = false) => {
	return {
		color: isbg ? '#FFFFFF' : val ? Vue.prototype.$theme.RISE : Vue.prototype.$theme.FALL,
		backgroundColor: !isbg ? '' : val ? Vue.prototype.$theme.RISE : Vue.prototype.$theme.FALL,
	}
};

export default {
	// linkCustomerService,
	// RGBConvertToRGBA,
	// // 对象嵌套转数组对象。当前用于市场指标返回数据，将其从对象转为数组对象
	// ObjectConvertArray: (obj) => {
	// 	return Object.values(obj);
	// },
	formatNumber,
	setStockRiseFall,
	// 负数取绝对值
	formatMathABS: (val) => {
		return Math.abs(val);
	},

	// // 切换底部导航文字多语言
	// switchTabBar: () => {
	// 	const TABBAR = [
	// 		Vue.prototype.$lang.TABBAR_HOME,
	// 		Vue.prototype.$lang.TABBAR_FOLLOW,
	// 		Vue.prototype.$lang.TABBAR_MARKET,
	// 		Vue.prototype.$lang.TABBAR_TRADE,
	// 		Vue.prototype.$lang.TABBAR_ACCOUNT
	// 	];
	// 	// 遍历底部导航，逐一换成当前语言
	// 	for (let i = 0; i <= 5; i++) {
	// 		uni.setTabBarItem({
	// 			index: i,
	// 			text: TABBAR[i],
	// 		})
	// 	}
	// },

	// // 邮箱验证
	// checkEmail: (val) => {
	// 	const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
	// 	console.log('checkEmail:', !emailPattern.test(val))
	// 	return !emailPattern.test(val);
	// },

	// 设置input的placeholder样式
	setPlaceholder: (color = '', fontsize = '') => {
		return `color:${color == '' ? Vue.prototype.$theme.PLACEHOLDER : color};font-size:${fontsize==''?24:fontsize}rpx`;
	},

	// 设置图片尺寸（自定义size）
	setImageSize: (w = 0, h = 0) => {
		const _w = w > 0 ? w : 20;
		const _h = h > 0 ? h : _w;
		return {
			width: `${_w}rpx`,
			// 若为设置h值，则视为高=宽
			height: `${_h}rpx`,
		};
	},
	// 设置页面背景,返回style对象，动态替换页面背景图
	setPageBG: (url) => {
		return {
			backgroundImage: `url(/static/${url}.png)`,
			backgroundSize: '100% auto',
			backgroundRepeat: 'no-repeat',
			backgroundPosition: '0 -32rpx',
		}
	},

	// // 根据传入值，求出进度条元素宽度
	// setProgress: (val, max) => {
	// 	// 模拟数据所需，实际数据不会出现
	// 	const result = max - val < 0 ? 0 : (val / max) * 100;
	// 	console.log(result);
	// 	return {
	// 		// backgroundImage: `url(/static/progress.png)`,
	// 		// backgroundSize: 'auto',
	// 		// backgroundRepeat: 'repeat',
	// 		// backgroundPosition: '0 -7px',
	// 		backgroundImage: 'linear-gradient(-90deg, #F5B71C, rgba(255,255,255,0.8))',
	// 		width: `${result}%`,
	// 		height: '100%',
	// 		borderRadius: `12px`,
	// 	}
	// },

	formatDate: (timeString) => {
		// console.log('fmt:',fmt);
		const date = new Date(timeString);
		const year = date.getUTCFullYear();
		const month = String(date.getUTCMonth() + 1).padStart(2, '0');
		const day = String(date.getUTCDate()).padStart(2, '0');
		const h = String(date.getUTCHours()).padStart(2, '0');
		const m = String(date.getUTCMinutes()).padStart(2, '0');
		const s = String(date.getUTCSeconds()).padStart(2, '0');
		return `${year}.${month}.${day} ${h}:${m}:${s}`;
	},

	// // 部分页面需要拼接股票完整LOGO的url
	// setLogo: (url) => {
	// 	if (url.includes('http')) {
	// 		return url;
	// 	} else {
	// 		return BASE_URL + url
	// 	}
	// },
	
	// // 是否为小数
	// hasDecimalPoint: (val) => {
	// 	return val % 1 !== 0;
	// }
}