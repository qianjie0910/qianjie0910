<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
			// console.log(this.$u.config.v);
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	// @import "@/node_modules/uview-ui/index.scss";
	// @import url("common/css/rc.css");
	// @import url("common/icon.css");
	@import url("common/style.css");

	view {
		font-family: "AlphaSans";
		font-size: 14px;
	}

	@media screen and (max-device-width:375px) {
		page {
			width: 100vw;
		}

		// .rotate_auto_point {
		// 	background-size: 60%;
		// }

		.popup_body {
			width: 90%;
		}

		.popup_body_result {
			width: 90%;
		}
	}

	@media screen and (min-device-width:376px) and (max-device-width:750px) {
		page {
			width: 100vw;
			margin: 0 auto;
		}

		// .rotate_auto_point {
		// 	background-size: 60%;
		// }

		.popup_body {
			width: 90%;
		}

		.popup_body_result {
			width: 90%;
		}
	}

	@media screen and (min-device-width:751px) {
		page {
			width: 750px;
			margin: 0 auto;
		}

		.popup_body {
			width: 50%;
		}
		.popup_body_result {
			width: 50%;
		}
	}

	@font-face {
		font-family: AlphaSans;
		src: local("AlphaSans-Medium"),
			url(~@/static/ziti/AlphaSans-Medium.woff2) format("woff2"),
			url(~@/static/ziti/AlphaSans-Medium.woff) format("woff"),
			url(~@/static/ziti/AlphaSans-Medium.ttf) format("truetype");
		font-style: normal;
		font-display: swap;
		font-weight: 500;
	}
</style>