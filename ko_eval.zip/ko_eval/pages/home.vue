<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGCover(`bg`)">
		<view style="display: flex;align-items: center;justify-content: center;padding-top: 60rpx;">
			<image src="/static/title1.png" mode="aspectFit" :style="$theme.setImageSize(600,160)"></image>
		</view>
		<view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/title2.png" mode="aspectFit" :style="$theme.setImageSize(600,200)"></image>
		</view>

		<view style="position: relative;width: 360px;height: 360px; margin: auto;">
			<view class="round_bg"></view>
			<view class="rotate_auto_round"></view>
			<view class="rotate_auto_point"></view>
		</view>

		<view style="color:#315DFA;text-align: center;font-size: 40rpx;font-weight: 700;"> 주식 코드를 입력하세요<text
				style="color:#FD22B7;font-weight: 900;font-size: 48rpx;">{{ ` 무료 평가판 ` }}</text> </view>

		<view style="margin:40rpx;">
			<!-- 股票代码输入，及查询 -->
			<view class="common_input_wrapper" style="padding: 0;height: 48px;border: 0;background-color: #FFFFFF;">
				<input v-model="code" type="text" placeholder="주식코드를 입력해주세요"
					:placeholder-style="$theme.setPlaceholder()"
					style="margin-right: auto;padding-left: 40rpx;"></input>
				<view @click="handleResult"
					style="width: max-content; color:#FFFFFF;background-color:#315DFA;height: 48px;line-height: 48px;padding:0 10rpx;border-radius:0 8rpx 8rpx 0; ">
					무료 평가판 </view>
			</view>

			<!-- 提示文字 -->
			<view style="text-align: right;color:#363636;font-size: 24rpx;">고객센터에서 나중에 전화드리겠습니다</view>
			<view style="text-align: right;color:#363636;font-size: 24rpx;line-height: 1.6;">예상 결과는 참고용이므로 실제 개봉을 참고하시기
				바랍니다</view>

			<!-- 搜索结果，股票数据 -->
			<view
				style="color: #FFFFFF;text-align: center;background:rgba(0,0,0,0.5);border-radius: 12rpx;padding: 20rpx;margin-top: 20rpx;">

				<view style="font-size: 40rpx;font-weight: 700;text-align: left;color:#121212;">{{setInfo.name}}</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;line-height: 1.8;">
					<view style="font-size:32rpx;color:#cfcfcf;">{{setInfo.code}}</view>
					<view style="color:#cfcfcf;">{{ curDate}} &nbsp;&nbsp;&nbsp;&nbsp; {{ curTime}} </view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;line-height: 1.8;">
					<view>오늘 개장</view>
					<view style="font-size: 32rpx;">{{setInfo.open}}</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;line-height: 1.8;">
					<view>어제 마감</view>
					<view style="font-size: 32rpx;">{{setInfo.close}}</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;line-height: 1.8;">
					<view>제일 높은</view>
					<view style="font-size: 32rpx;">{{setInfo.high}}</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;line-height: 1.8;">
					<view>가장 낮은</view>
					<view style="font-size: 32rpx;">{{setInfo.low}}</view>
				</view>
				<!-- <view
					style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;line-height: 1.8;">
					<view style="flex:1 0 20%;text-align: left;">손 바꾸기</view>
					<view style="flex:1 0 25%;text-align: right;">{{$util.formatNumber(setInfo.turnoverRate,2)}}%</view>
					<view style="flex:1 0 5%"></view>
					<view style="flex:1 0 25%;text-align: left;">진폭</view>
					<view style="flex:1 0 25%;text-align: right;">{{$util.formatNumber(setInfo.amplitude,2)}}%</view>
				</view> -->
				<view
					style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;line-height: 1.8;">
					<view>용량</view>
					<view style="font-size: 32rpx;">{{setInfo.volume}}</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;line-height: 1.8;">
					<view>회전율</view>
					<view style="font-size: 32rpx;">{{setInfo.turnover}}</view>
				</view>
			</view>

			<!-- 领取评测结果 -->
			<view
				style="background-color: #315DFA;color:#FFFFFF;text-align: center;margin:40rpx;padding:20rpx 0;border-radius: 12rpx;font-size: 36rpx;"
				@click="handleShowPhone()">
				<text style="padding-right: 20rpx;">{{ info.name || ''}}</text> 평가 결과 얻기
			</view>


			<view style="display: flex;align-items: center;justify-content: center;">
				<image src="/static/title3.png" mode="aspectFit" :style="$theme.setImageSize(600,80)"></image>
			</view>

			<view style="display: flex;align-items: center;justify-content: center;padding: 40rpx 0;">
				<image src="/static/chart.png" mode="aspectFit" :style="$theme.setImageSize(700,360)"></image>
			</view>

			<view style="display: flex;align-items: center;justify-content: center;">
				<image src="/static/title4.png" mode="aspectFit" :style="$theme.setImageSize(480,120)"></image>
			</view>

			<!-- 领取评测结果 -->
			<view
				style="background-color: #315DFA;color:#FFFFFF;text-align: center;margin:40rpx;padding:20rpx 0;border-radius: 12rpx;font-size: 36rpx;"
				@click="handleShowPhone()">
				<text style="padding-right: 20rpx;">{{ info.name || ''}}</text> 평가 결과 얻기
			</view>
		</view>

		<!-- 底部说明 -->
		<view
			style="background-color: rgba(0,0,0,0.5);padding:20rpx;margin:0;color:#FFFFFF;line-height: 1.8;text-align: center;">
			<view style="font-size: 20rpx;">예상 결과는 참고용이므로 실제 개봉을 참고하시기 바랍니다</view>
			<view style="font-size: 20rpx;">증권투자 및 선물거래시에는 적법한 증권 및 선물거래기관을 통해 진행하시기 바랍니다.</view>
			<view style="font-size: 20rpx;">투자는 위험하므로 선택 시 위험에 대한 책임은 구매자에게 있습니다.</view>
		</view>

		<!-- 弹层 检索状态 及手机号。  -->
		<template v-if="isShow">
			<view class="common_mask"></view>
			<template v-if="isGetStatus">
				<!-- 一些带进度条的状态 -->
				<view class="common_popup">
					<view class="popup_body">
						<ProgressSecond @action="getStep"></ProgressSecond>
					</view>
				</view>
			</template>

			<template v-else>
				<view class="common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_body_result">
						<view class="popup_header">
							<text style="color:#FFFFFF;padding-right: 30rpx;">{{ `${setInfo.name} ` }}</text> 평가 결과
							<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
								style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
								@click="closeModal()">
							</image>
						</view>
						<view style="padding: 30rpx 60rpx;">
							<view style="text-align: center;font-size: 24rpx;color:#333;">SMS를 통해 휴대폰으로 전송됩니다</view>

							<view class="common_input_wrapper"
								style="padding: 0;height: 48px;border: 0;background-color: #FFFFFF;">
								<input v-model="mobile" type="number" placeholder="전화번호를 입력해주세요"
									:placeholder-style="$theme.setPlaceholder()"
									style="margin-right: auto;padding-left: 40rpx;"></input>
							</view>

							<view @click="handleMobile()"
								style="background-color: #FFB044;color:#FFFFFF;text-align: center;margin:40rpx;padding:20rpx 0;border-radius: 12rpx;font-size: 36rpx;">
								평가 결과 얻기
							</view>
							<view style="text-align: center;font-size: 24rpx;color:#333;">우리는 귀하의 개인 정보를 제3자에게 절대 공개하지
								않을 것을 엄숙히 약속합니다.</view>

						</view>
					</view>
				</view>
			</template>
		</template>

		<!-- 弹层， 检索到多条数据时，打开此弹层，让用户进一步选择具体股票 -->
		<template v-if="isList">
			<view class="common_mask" @click="closeModal()"></view>
			<view class="common_popup" style="min-height:35vh;margin:auto;">
				<view class="popup_body_result" style="height:80%;background-color: #FFFFFF;">
					<view class="popup_header">
						<text style="color:#FFFFFF;padding-right: 30rpx;">주식을 선택하세요</text>
						<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
							style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
							@click="closeModal()">
						</image>
					</view>
					<view style="padding: 30rpx;height:85%;overflow-y: auto;">
						<view style="display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between;">
							<block v-for="(item,index) in list" :key="index">
								<view style="width: 96%; padding:16rpx 10rpx;line-height: 1.6;text-align: center;"
									:style="{backgroundColor:index%2===0?'rgba(49,93,250,0.1)':'#F1F1F1'}"
									@click="handleSelected(item)">
									<view style="display: flex;align-items: center;">
										<view style="flex:1 0 6%;">
											<StockLogo :logo="item.logo" :name="item.ko_name"></StockLogo>
										</view>
										<view style="flex:1 0 90%;text-align:left;">
											<view style="display: flex;align-items: center;padding-left: 20rpx;">
												<view style="color:#121212;padding-right: 40rpx;">{{item.code}}</view>
												<view style="color:#315DFA;padding-right: 40rpx;">{{item.market}}</view>
												<view style="color:#333;padding-right: 40rpx;">{{item.country_code}}
												</view>
												<view style="color:#333;margin-left: auto;">{{item.currency}}</view>
											</view>
											<view
												style="color:#FFB044;font-size: 28rpx;font-weight: 500;padding-left: 20rpx;">
												{{item.ko_name}}
											</view>
										</view>
									</view>
								</view>
							</block>
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import ProgressSecond from '@/components/progress/ProgressSecond.vue';
	import StockLogo from '@/components/StockLogo.vue';
	export default {
		components: {
			ProgressSecond,
			StockLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				code: '', // 输入的股票代码
				timer: null, // 计时器
				curDate: '', // 当前日期时间
				curTime: '', // 当前日期时间
				isShow: false, // 是否显示弹层
				isGetStatus: false, // 获取数据中的状态和进度条
				info: {}, // 股票数据
				mobile: '', // 输入的手机号
				isList: false, // 是否显示查询到的list
				list: [], // 查询到的数据list
			}
		},

		computed: {
			// 在这里处理获取的股票数据
			setInfo() {
				console.log('computed:', this.info);
				return {
					name: !this.isGetStatus && this.info.name && this.info.name.length > 0 ? this.info.name : '--',
					code: !this.isGetStatus && this.info.code && this.info.code.length > 0 ? this.info.code : '--',
					// price: this.info.price && this.info.price * 1 > 0 ? this.info.price : '--', // 现价
					// riseFallVol: this.info.riseFallVol || 0.00, // 涨跌额
					// riseFallRate: this.info.riseFallRate || 0.00, // 涨跌比例
					open: !this.isGetStatus && this.info.open * 1 > 0 ? this.$util.formatNumber(this.info.open) :
					'--', // 今日开盘
					close: !this.isGetStatus && this.info.close * 1 > 0 ? this.$util.formatNumber(this.info.close) :
					'--', // 昨日收盘
					high: !this.isGetStatus && this.info.high * 1 > 0 ? this.$util.formatNumber(this.info.high) :
					'--', // 最高
					low: !this.isGetStatus && this.info.low * 1 > 0 ? this.$util.formatNumber(this.info.low) : '--', // 最低
					// turnoverRate: this.info.turnoverRate || '--', // 换手 %
					// amplitude: this.info.amplitude || 0.00, // 振幅 %
					volume: !this.isGetStatus && this.info.volume * 1 > 0 ? this.$util.formatNumber(this.info.volume) :
						'--', // 成交量 万
					turnover: !this.isGetStatus && this.info.volume_valued * 1 > 0 ? this.$util.formatNumber(this.info
						.volume_valued) : '--', // 成交额 亿

					// $util.formatNumber(setInfo.turnover,2)
				}
			}
		},

		onLoad() {
			uni.hideTabBar(); // 隐藏底部导航
		},

		onShow() {
			this.isAnimat = true;
			this.onSetTimeout();
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
			// this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},

		methods: {
			// 弹层关闭
			closeModal() {
				this.isShow = false;
				this.isList = false;
			},
			// 接受进度组件跑完所有进度
			getStep(val) {
				console.log(val);
				if (val >= 2) {
					this.isGetStatus = false;
				}
			},
			// 点击弹出输入手机号
			handleShowPhone() {
				console.log('11');
				this.isGetStatus = false;
				this.isShow = true;
			},
			// 提交手机号
			async handleMobile() {
				if (this.mobile == '') {
					uni.showToast({
						title: '전화번호를 입력해주세요',
						icon: 'none'
					});
					return false;
				}

				const result = await this.$http.post(`api/user/reg`, {
					mobile: this.mobile
				});
				console.log('提交手机号:', result);
				// 检查返回数据
				if (result && result.code == 0) {
					uni.showToast({
						title: result.message,
						icon: 'none'
					})
				} else {
					uni.showToast({
						title: result.message,
						icon: 'none'
					})
				}
			},

			// 在检索结果列表弹层中，选中一条数据
			async handleSelected(val) {
				// 选中之后，关掉弹层。
				this.isList = false;
				// 打开数据处理相关的小弹层
				this.isShow = true; // 显示状态弹层
				this.isGetStatus = true;

				// https://api.alphasquare.co.kr/data/v3/prices/current-candle?stock-id=1014
				const tempFormData = {
					[`stock-id`]: val.id
				};
				const result = await this.$http.post(`api/user/candle`,
					tempFormData);
				console.log(result);
				// 检查返回数据
				const temp = !result || !Object.keys(result) || Object.keys(result) <= 0 ? [] :
					Object.values(result)[0];
				console.log('返回的单条数据:', temp);
				this.info = {
					...temp,
					id: temp.stock_id || val.id,
					name: val.ko_name,
				}
				console.log('返回的单条数据:', this.info);
			},

			// 获取评估结果
			async handleResult() {
				if (this.code.length < 3) {
					uni.showToast({
						title: '적어도 세 글자를 입력하세요',
						icon: 'none',
					});
					return false;
				}

				// 输入股票代码，模糊查询 
				const result = await this.$http.post(`api/user/stocks`, {
					keyword: this.code,
				});
				console.log(result);
				// 检查返回结果
				const temp = !result || !result.data || result.data.length <= 0 ? [] : result.data;
				// 格式化返回数据
				const tempFilter = temp.length <= 0 ? [] : temp.filter(item => item.id && item.id > 0);

				if (tempFilter.length <= 0) {
					uni.showToast({
						title: '일치하는 정보가 없습니다.',
						icon: 'none',
					});
					return false;
				}

				// 返回数据：1条数据，自动进行查询；
				if (tempFilter.length == 1) {
					console.log(tempFilter);
					this.handleSelected(tempFilter[0]);
					return false;
				}
				// 多条数据，开启弹层，让用户进一步选择
				if (tempFilter.length > 1) {
					this.isList = true;
					this.list = tempFilter;
				}
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					const temp = this.$util.formatDate(new Date());
					// console.log("setInterval", temp);
					this.curDate = temp.slice(0, 10);
					this.curTime = temp.slice(10, 19);
				}, 1000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

		},
	}
</script>