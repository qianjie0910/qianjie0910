# morgan

## fork mbkstock

![LOGO](https://github.com/github1413/morgan/raw/main/static/logo.png)

# TODO
- 完全替换uview-ui。

# Update Log 2024.06.04
- 添加`kakao`客服。上架改为弹层选择客服。实际使用在客服页面提供选择，再进入嵌套页面。

# Update Log 2024.06.02
- api挂载全局使用。(最初使用方式)
- paths挂载全局，支持变量，或硬编码。

# Update Log 2024.05.15
- 在`index.html`中添加媒体查询样式，使其桌面浏览器情况下，内容居中。(未真机测试)
- uniapp内置`scroll-view`不支持桌面端鼠标移动。

# Update Log 2024.05.14
- 添加AI交易

# Update Log 2024.05.13
- auth:保留并注释严格校验韩国证件号码，以及自动计算性别。
- 默认提供正反面照片上传。

# Update Log 2024.05.12
- Launch页面，竖向加载条功能

# Update Log 2024.05.09
- 首页的页首吸顶
- 语言切换移出header容器
- 首页添加IPO中签提醒


# Update Log 2024.05.05
- 添加股权交易

# Update Log 2024.05.03
- 日内交易，添加可用金额

# Update Log 2024.05.01
- 优化`access`页面，记住密码及用户隐私协议完整逻辑。