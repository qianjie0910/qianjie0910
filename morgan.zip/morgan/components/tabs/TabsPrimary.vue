<template>
	<view style="display: flex;align-items: center;justify-content: space-between;">
		<block v-for="(item,index) in tabs" :key='index'>
			<view @click="handleChange(index)"
				style="padding: 4px 10px; width: 30%;text-align: center;border-radius: 2rpx;font-size: 28rpx;line-height: 1.8;"
				:style="setActiveStyle(acitve ==index)">{{item}}</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'TabsPrimary',
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 自定义颜色
			color: {
				type: String,
				default: '#333333',
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				current: this.acitve,
			};
		},
		methods: {
			handleChange(val) {
				this.current = val;
				this.$emit('action', this.current);
			},
			setActiveStyle(val) {
				return {
					backgroundColor: val ? this.$theme.PRIMARY : '#F1F1F1',
					color: val ? '#FFF' : this.color,
				}
			},
		}
	}
</script>