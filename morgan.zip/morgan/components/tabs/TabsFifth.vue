<template>
	<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;" @touchmove.stop>
		<block v-for="(item,index) in tabs" :key='index'>
			<view style="margin-right: 20rpx;display: inline-block;border-radius: 12rpx;padding:16rpx 20rpx;"
				:style="setStyle(curTab==index)" @click="handleChange(index)">
				<!-- <image src="/static/center_left.png" mode="aspectFit" :style="$theme.setImageSize(28)"
				style="padding-right: 20px;"></image> -->
				{{item}}
			</view>
		</block>
	</scroll-view>
</template>

<script>
	export default {
		name: 'TabsFifth',
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				curTab: this.acitve,
			};
		},
		methods: {
			setStyle(val) {
				return {
					backgroundColor: val ? '#E8EDFF' : '#F5F5F5',
					color: val ? this.$theme.PRIMARY : '#585858',
				}
			},

			handleChange(val) {
				this.curTab = val;
				this.$emit('action', this.curTab);
			},
		}
	}
</script>