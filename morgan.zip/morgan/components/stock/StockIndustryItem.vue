<template>
	<view style="margin: 6px;padding: 6px;border-bottom: 1px solid #ededed;">
		<view style="display: flex;align-items: center; justify-content: space-between;">
			<view style="color:#999999;">{{name}}</view>
			<view style="color:#121212;">{{setData.value0}}{{setData.unit0}}</view>
		</view>
		<view style="display: flex;align-items: center; justify-content: space-between;">
			<view style="color:#999999;">{{$lang.STOCK_INDUSTRY_DATA_TITLES[0]}}</view>
			<view :style="$theme.setStockRiseFall(setData.value1>0)">
				{{setData.value1}}{{setData.unit1}}
			</view>
		</view>
		<view style="display: flex;align-items: center; justify-content: space-between;">
			<view style="color:#999999;">{{$lang.STOCK_INDUSTRY_DATA_TITLES[1]}}</view>
			<view :style="$theme.setStockRiseFall(setData.value2>0)">
				{{setData.value2}}{{setData.unit2}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'StockIndustryItem',
		props: {
			info: {
				type: Object,
				default: {},
			},
			// 根据该值，判断当前需要显示的数据
			flag: {
				type: Number,
				default: 0,
			},
			// 行业名
			name: {
				type: String,
				default: '',
			}
		},
		computed: {
			setData() {
				const temp = [{
					value0: this.info.marketcap_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.marketcap,
					unit1: ` ${this.$lang.UNIT_BILION}`,
					value2: this.info.marketcap_avg,
					unit2: ` ${this.$lang.UNIT_BILION}`,
				}, {
					value0: this.info.net_income_growth_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.net_income_growth,
					unit1: ` %`,
					value2: this.info.net_income_growth_avg,
					unit2: ` %`,
				}, {
					value0: this.info.debt_ratio_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.debt_ratio,
					unit1: ` %`,
					value2: this.info.debt_ratio_avg,
					unit2: ` %`,
				}, {
					value0: this.info.per_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.per,
					unit1: ` 배`,
					value2: this.info.per_avg,
					unit2: ` 배`,
				}, {
					value0: this.info.pbr_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.pbr,
					unit1: ` 배`,
					value2: this.info.pbr_avg,
					unit2: ` 배`,
				}, {
					value0: this.info.roe_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.roe,
					unit1: ` %`,
					value2: this.info.roe_avg,
					unit2: ` %`,
				}];
				return temp[this.flag];
			},
		}
	}
</script>

<style>
</style>