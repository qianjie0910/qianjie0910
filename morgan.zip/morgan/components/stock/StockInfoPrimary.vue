<template>
	<view style="border-bottom: 3px solid #F8F8F8;margin-bottom: 30rpx;">
		<view class="common_block" style="padding-bottom: 10px;border-radius: 8rpx;box-shadow: none;margin:0;border-bottom: 3px solid #F8F8F8;">
			<view style="display: flex;align-items: center;padding: 20rpx;padding-bottom: 0;">
				<view style="flex:0 0 8%;padding-right: 20rpx;">
					<StockLogo :logo="info.logo" :name="info.name"></StockLogo>
				</view>
				<view style="flex:60%">
					<view style="margin-bottom: 2px;font-weight: 700;font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
						{{info.name}}
						<image :src="`/static/${info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
							:style="$theme.setImageSize(24)" style="padding-left: 20rpx;"
							@click="handleUnFollow(info.gid)"></image>
					</view>
					<view style="color:#999999;"> {{info.number_code}} {{info.ct_name}}</view>
				</view>
				<view style="margin-left: auto;">
					<view style="font-size: 40rpx;text-align: right;" :style="$theme.setStockRiseFall(info.rate>0)">
						{{$util.formatNumber(info.current_price)}} {{$lang.CURRENCY_UNIT}}
					</view>
					<view style="display: flex;align-items: center;" :style="$theme.setStockRiseFall(info.rate>0)">
						<view style="font-size: 32rpx;">
							{{$util.formatNumber(info.rate_num)}}
						</view>
						<view style="width: 1px;height: 24rpx;background-color: #999999;margin:0 30rpx;"></view>
						<view style="font-size: 32rpx;">
							{{$util.formatNumber(info.rate)}}%
						</view>
					</view>
				</view>
			</view>

		</view>
		<view class="common_block" style="padding-bottom: 10px;border-radius: 8rpx;box-shadow: none;margin: 0;">
			<block v-for="(item,index) in $lang.STOCK_INFO_TITLES" :key="index">
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 30px;padding:0 10px;">
					<view style="color: #333333;">{{item}}</view>
					<view style="color: #121212;font-size: 28rpx;">
						{{setInfo[index]}}
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import StockLogo from '@/components/stock/StockLogo.vue';
	export default {
		name: 'StockInfoPrimary',
		components: {
			StockLogo
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},

		computed: {
			setInfo() {
				return [
					this.$util.formatNumber(this.info.info.open) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.close) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.low)+ ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.low) + ` ` + this.$lang.CURRENCY_UNIT,
					
					this.$util.formatNumber(this.info.info.volume) ,
					this.$util.formatNumber(this.info.info.volume_valued),
				]
			}
		},

		methods: {
			// 取关
			async handleUnFollow(id) {
				const result = await this.$http.post(`api/user/collect_edit`,{
					gid: id,
				})
				if (result.code == 0) {
					uni.$u.toast(result.message);
					//按键样式判断
					this.info.is_collected = this.info.is_collected == 1 ? 0 : 1
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>
</style>