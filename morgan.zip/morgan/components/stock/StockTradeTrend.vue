<template>
	<view style="display: flex;align-items: center;margin-bottom: 30rpx;">
		<block v-for="(item,index) in $lang.STOCK_TRADE_TREND_INFO_TITLE" :key="index">
			<view style="flex:30%;padding: 4px;margin:4px;text-align: center;line-height: 1.6;border:1px solid #ededed;border-radius: 12rpx;">
				<view style="color:#999999;">{{item}}</view>
				<view :style="$theme.setStockRiseFall(setData[index]>0)">
					{{$util.formatNumber(setData[index])}}
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'StockTradeTrend',
		props: {
			info: {
				type: Object,
				default: {},
			},
			// 根据该值，判断需要渲染的数据
			flag: {
				type: Number,
				default: 0,
			},
		},
		computed: {
			setData() {
				if (this.flag <= 0) {
					return [
						this.info['net_volume'].net_vol_individual,
						this.info['net_volume'].net_vol_institutional,
						this.info['net_volume'].net_vol_foreigner,
					]
				} else {
					return [
						this.info['cum_volume'].cum_vol_individual,
						this.info['cum_volume'].cum_vol_institutional,
						this.info['cum_volume'].cum_vol_foreigner,
					]
				}

			}
		}

	}
</script>

<style>
</style>