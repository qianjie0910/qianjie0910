<template>
	<view>
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="display: flex;align-items: center;margin:10px 20rpx;" @click="link(item.code)"
					:style="{borderBottom:`1px solid ${index<list.length-1?'#ededed':'transparent' }`}">

					<view style="width: 90rpx;text-align: center;">
						<StockLogo :logo="item.logo" :name="item.name"></StockLogo>
					</view>
					<view style="flex:50%;padding-left: 10px;">
						<view style="font-size: 32rpx;color: #121212;"> {{item.name}} </view>
						<view style="font-size: 24rpx;color: #555555;"> {{item.code}} </view>
					</view>

					<view style="font-size:32rpx;color: #333333;flex: 30%;text-align: right;">
						{{$util.formatNumber(item.price)}}
					</view>
					<view style="margin-left: auto;padding-left: 32rpx;">
						<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$theme.setImageSize(20)"></image>
					</view>
					<view :style="$theme.setStockRiseFall(item.rate>0)" style="margin-left: auto;padding-left: 12rpx;">
						{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import StockLogo from '@/components/stock/StockLogo.vue';
	export default {
		name: 'ListFourth',
		components: {
			EmptyData,
			StockLogo,
		},
		props: {
			// 列表数据
			list: {
				type: Array,
				default: []
			},
		},

		methods: {
			// 跳转到股票详情
			link(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			}
		}
	}
</script>