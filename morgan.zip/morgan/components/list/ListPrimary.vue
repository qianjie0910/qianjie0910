<template>
	<view>
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="display: flex;align-items: center;padding:10px;"
					@click="linkStockInfo(item.code)">
					<template v-if="serial">
						<view style="width: 60rpx; text-align: center;">
							<template v-if="index<=2">
								<image :src="`/static/leve_${index+1}.png`" :style="$theme.setImageSize(48)"
									style="padding-right: 6px;"></image>
							</template>
							<template v-else>
								<view style="padding-right: 6px;text-align: center;color:#555555;">
									{{index+1}}
								</view>
							</template>
						</view>
					</template>
					<view style="width: 90rpx;text-align: center;">
						<StockLogo :logo="item.logo" :name="item.name"></StockLogo>
					</view>
					<view style="flex: 0 0 40%;padding-left: 6px;" :style="{color:$theme.TITLE}">
						<view style="font-size: 28rpx;color:#121212">{{item.name}}</view>
						<view style="font-size: 24rpx;color:#555555">{{item.code}}</view>
					</view>
					<view style="margin-left: auto;text-align: right;font-size: 28rpx;">
						<view :style="$theme.setStockRiseFall(item.rate>0)">
							<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(24)"></image>
							{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
						</view>
						<view style="font-weight: 800;font-size: 32rpx;color: #333333;">
							{{$util.formatNumber(item.price)}}{{$lang.CURRENCY_UNIT}}
						</view>

					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import StockLogo from '@/components/stock/StockLogo.vue';
	export default {
		name: 'ListPrimary',
		components: {
			EmptyData,
			StockLogo,
		},
		props: {
			// 列表数据
			list: {
				type: Array,
				default: []
			},
			// 是否需要序号
			serial: {
				type: Boolean,
				default: false,
			}
		},

		methods: {
			// 跳转到股票详情
			linkStockInfo(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			}
		}
	}
</script>