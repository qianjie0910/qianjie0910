<template>
	<view  style="padding: 10px;background-color: #FFFFFF;margin:20rpx;">
		<template v-if="!list || list.length<=0">
			<view class="common_block" style="padding:10px;margin-bottom: 20px;">
				<EmptyData></EmptyData>
			</view>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="margin: 30rpx; word-wrap:break-word;padding: 10px;border-bottom: 1px solid #E5E5E5;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.PRIMARY}" style="font-size: 36rpx;">{{item.goods_info.name}}</view>
						<text style="color:darkred">{{$lang.TRADE_LARGE_LOG_FINISH}}</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.TITLE}">{{$lang.TRADE_LARGE_LOG_PRICE}}</view>
						<text>{{item.order_buy.price}}<text
								style="padding-left:4px">{{$lang.CURRENCY_UNIT}}</text></text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.TITLE}">{{$lang.TRADE_LARGE_LOG_NUM}}</view>
						<text style="color:darkred">{{item.order_buy.num}}</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.TITLE}">{{$lang.TRADE_LARGE_LOG_AMOUNT}}</view>
						<text>{{item.order_buy.amount}}<text
								style="padding-left:4px">{{$lang.CURRENCY_UNIT}}</text></text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.TITLE}">{{$lang.TRADE_LARGE_LOG_LEVER}}</view>
						<text>{{item.order_buy.double}}</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;"
						:style="{color:$theme.TITLE}">
						<view>{{$lang.TRADE_LARGE_LOG_CREATE_TIME}}</view>
						<text>{{item.order_buy.created_at}}</text>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeDiscountLog",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/goods-discount/user-order-log`);
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>