<template>
	<view>
		<view style="display: flex;align-items: center;">
			<view style="flex:6%">
				<template v-if="!item.logo || item.logo==''">
					<view :style="$theme.setImageSize(80)"
						style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;font-size: 18px;">
						{{item.name.slice(0,1)}}
					</view>
				</template>
				<template v-else>
					<image mode="aspectFit" :src="$util.setLogo(item.logo)" :style="$theme.setImageSize(80)"
						style="border-radius: 100%;"></image>
				</template>
			</view>
			<view style="flex:94%;">
				<view style="padding-left: 10px;font-size: 36rpx;font-weight: 700;color:#585858;">
					{{item.name}}
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<text style="font-size: 28rpx;padding-left: 10px;" :style="{color:$theme.TEXT}">{{item.code}}</text>
					<view
						style="color:#FFFFFF;padding:8rpx 16rpx;width: 100rpx;text-align: center;background-color: #03B7F2;font-size: 24rpx;"
						@click="stockInfo(item.id)">
						청약신청
					</view>
				</view>
			</view>
		</view>
		<template v-if="item.price">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LABEL}">공모가</text>
				<text style="font-size: 32rpx;font-weight: 700;" :style="{color:$theme.PRIMARY}">
					{{$util.formatNumber(item.price)}} {{$lang.CURRENCY_UNIT}}</text>
			</view>
		</template>

		<template v-if="item.shengou_date">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
				<view :style="{color:$theme.LABEL}">청약일</view>
				<view :style="{color:$theme.TIP}">{{item.shengou_date}}</view>
			</view>
		</template>
		<template v-if="item.fa_amount">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LABEL}">총 발행량</text>
				<text>
					{{$util.formatNumber(item.fa_amount*1)}} {{$lang.QUANTITY_UNIT}}</text>
			</view>
		</template>
		<template v-if="item.min_num">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LABEL}">{{$lang.TRADE_LARGE_MIN_QTY}}</text>
				<text style="font-size: 28rpx;">
					{{$util.formatNumber(item.min_num)}} {{$lang.QUANTITY_UNIT}}</text>
			</view>
		</template>
		<template v-if="item.max_num">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LABEL}">{{$lang.TRADE_LARGE_MAX_QTY}}</text>
				<text style="font-size: 28rpx;">
					{{$util.formatNumber(item.max_num)}} {{$lang.QUANTITY_UNIT}}</text>
			</view>
		</template>
		<template v-if="item.day">
			<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;">
				<text :style="{color:$theme.LABEL}">{{$lang.TRADE_LARGE_MIN_DAY}}</text>
				<text style="font-size: 28rpx;">
					{{item.day}}{{$lang.UNIT_DAY}}</text>
			</view>
		</template>

	</view>
</template>

<script>
	export default {
		name: 'TradeIPOItem',
		props: {
			// 交易类型页面产品列表中的单个产品
			item: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {};
		},
		methods: {
			stockInfo(val) {
				console.log('stock info:', val);
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>