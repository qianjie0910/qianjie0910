<template>
	<view>
		<view style="text-align: center;margin-bottom: 30px;">
			<image src="/static/trade_day_header.png" mode="aspectFit" :style="$theme.setImageSize(560,380)">
			</image>
		</view>
		<view style="padding:20px;background-color: #FFFFFF;">
			<TitleSecond :title="$lang.TRADE_DAY_TIP_INPUT_AMOUNT" color="#121212"></TitleSecond>
			<view class="common_input_wrapper" style="padding-left: 40rpx;">
				<input v-model="amount" type="number" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
					:placeholder-style="$theme.setPlaceholder()" maxlength="11" style="width: 90%;"></input>
				<view style="color:#999">{{$lang.CURRENCY_UNIT}}</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: flex-end;" :style="{color:$theme.LABEL}">
				<view style="padding-right: 10px;color:#FFFFFF;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}:</view>
				<view>{{userInfo.money<=0?0: $util.formatNumber(userInfo.money)}} [{{$lang.CURRENCY_UNIT}}]</view>
				<view style="padding-left: 10px;" :style="{color:$theme.PRIMARY}" @click="linkDeposit">
					{{$lang.PAGE_TITLE_DEPOSIT}}
				</view>
			</view>

			<view :style="$theme.btnCommon(true)" @click="handleBuy()" style="margin:30rpx 0">
				{{$lang.TRADE_DAY_BUY}}
			</view>

			<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#555555;">
				<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}:</view>
				<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
					<view style="padding-bottom: 6px;">{{item}}</view>
				</block>
			</view>
		</view>

		<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
			:showCancelButton='true' :content="$lang.TRADE_DAY_MODAL_CONTENT" :cancel-text="$lang.BTN_CANCEL"
			:confirm-text="$lang.BTN_CONFIRM" :confirmColor="this.$theme.PRIMARY" cancelColor="#999999">
		</u-modal>
	</view>
</template>

<script>
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		name: 'TradeDayBuy',
		components: {
			TitleSecond
		},
		data() {
			return {
				amount: '',
				showBuyConfirm: false,
				userInfo: {},
			}
		},
		created() {
			this.getUserInfo();
		},
		methods: {
			// 跳转到充值页面
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},

			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast($lang.TRADE_DAY_TIP_INPUT_AMOUNT);
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.amount = '';
					// 1 为驱动父事件，实现切换Tab效果
					this.$emit('action', 1);
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/user/info`);
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			},
		}
	}
</script>