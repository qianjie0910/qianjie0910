<template>
	<view style="padding-bottom: 30px;">
		<template v-if="!list || list.length<=0">
			<view class="common_block" style="padding:10px;margin-bottom: 20px;">
				<EmptyData></EmptyData>
			</view>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view :class="index==list.length-1?'':'line' "
					style="margin: 10rpx; word-wrap:break-word;padding: 10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.TEXT}" style="font-size: 32rpx;">{{item.goods.code}}</view>
						<template v-if="item.success>0 && item.admin_status==1 && item.bujiao>0">
							<view
								style="color:#FFFFFF;padding:4px 10px; border-radius: 20px;width: 160rpx;text-align: center;"
								:style="{backgroundColor:'#FF6700'}" @click="handleDeficiency(item)">
								{{$lang.TRADE_EQUITY_DEF_BTN}}
							</view>
						</template>
					</view>
					<view :style="{color:$theme.PRIMARY}" style="font-size: 36rpx;">{{item.goods.name}}</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;"
						:style="{color:$theme.LABEL}">
						<view>{{$lang.TRADE_EQUITY_PRICE}}</view>
						<view>
							{{$util.formatNumber(item.price)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;"
						:style="{color:$theme.LABEL}">
						<view>{{$lang.TRADE_EQUITY_QTY}}</view>
						<view>{{$util.formatNumber(item.apply_amount)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_EQUITY_TOTAL}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$util.formatNumber(item.amount)}}</view>
					</view>

					<template v-if="item.success>0 && item.admin_status==1">
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;"
							:style="{color:$theme.LABEL}">
							<view>{{$lang.TRADE_EQUITY_SUCCESS_QTY}}</view>
							<view>{{$util.formatNumber(item.success)}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;"
							:style="{color:$theme.LABEL}">
							<view>{{$lang.TRADE_EQUITY_SUCCESS_TOTAL}}</view>
							<view>{{$util.formatNumber(item.total)}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;"
							:style="{color:$theme.LABEL}">
							<view>{{$lang.TRADE_EQUITY_SUB_AMOUNT}}</view>
							<view>{{$util.formatNumber(item.renjiao)}}</view>
						</view>
						<template v-if="item.bujiao>0">
							<view
								style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
								<view :style="{color:$theme.LABEL}">{{$lang.TRADE_EQUITY_DEF_AMOUNT}}</view>
								<view :style="{color:$theme.PRIMARY}">{{$util.formatNumber(item.bujiao)}}
								</view>
							</view>
						</template>
					</template>

					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_LOG_LABELS[2]}}</view>
						<view :style="{color:$theme.TIP}">{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;">
						<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.LOG_TRADE_DESC}}:</view>
					</view>
					<view style="display: flex;align-items: center;">
						<view style="flex:30%;"></view>
						<text :style="{color:$theme.TEXT}"
							style="white-space:pre-wrap;text-align: right;">{{item.desc}}</text>
					</view>
				</view>
			</block>
		</template>

		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_popup" style="min-height:35vh;margin:auto;margin-bottom: 0;">
					<view class="popup_header" style="">
						{{$lang.TRADE_LARGE_ORDER_TITLE}}
						<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
							style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
							@click="handleCancel()"></image>
					</view>
					<view style="">
						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
							<text :style="{color:$theme.TIP}">{{$lang.TRADE_EQUITY_DEF_AMOUNT}}</text>
							<text :style="{color:'#FF6700'}">
								{{$util.formatNumber(curItem.bujiao)}}{{$lang.CURRENCY_UNIT}}</text>
						</view>
						<view class="common_input_wrapper"
							style="margin:20px;margin-top: 10px; background-color:#FFFFFF;border: 1px solid #E8EAF3;padding-left: 20px;">
							<input v-model="amount" :placeholder="$lang.TRADE_EQUITY_DEF_AMOUNT_TIP" type="number"
								style="width: 70%;" :placeholder-style="$theme.setPlaceholder()"></input>
							<view style="padding:0 4px;color: #999;">{{$lang.QUANTITY_UNIT}}</view>
							<view @click="allAmount()"
								style="color: #FFFFFF;padding:2px 6px;border-radius: 4px;margin-left: auto;margin-right: 10px;"
								:style="{backgroundColor:$util.RGBConvertToRGBA('#FF6700',90)}">
								{{$lang.TRADE_EQUITY_DEF_BTN_ALL}}
							</view>
						</view>

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;margin: 10px 40px ;">
							<text :style="{color:$theme.TITLE}">{{$lang.TIP_AMOUNT_AVAIL}}</text>
							<text :style="{color:'#FF6700'}">
								{{availBal}} {{$lang.CURRENCY_UNIT}}</text>
						</view>

						<view class="trade_modal_btn" style="background-color: #FF6700;width: 90%; margin: 30px auto;"
							@click="handleConfirm()">
							{{$lang.BTN_CONFIRM}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeEALog',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				curItem: {}, // 当前点击补缴事件 的数据
				amount: '', // 补缴金额输入值
				isShow: false, // 显示弹层
				availBal: 0, // 可用额
			};
		},
		created() {
			this.getData();
			this.available()
		},
		methods: {
			// 点击全补按钮
			allAmount() {
				this.amount = this.curItem.bujiao;
			},

			// 点击补缴按钮
			handleDeficiency(item) {
				this.isShow = true;
				this.curItem = item;
				// 默认将补缴金额带入到输入框
				this.amount = Number(item.bujiao);
			},
			handleCancel() {
				this.isShow = false;
				this.amount = "";
			},
			handleConfirm() {
				if (this.checkForm()) {
					this.deficiencyPayment();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_COUNT);
					return false;
				}
				return true;
			},

			// 补缴
			async deficiencyPayment() {
				const result = await this.$http.post(`api/goods-guquan/renjiao`,{
					id: this.curItem.id,
					price: this.amount
				});
				
				if (result.code == 0) {
					this.isShow = false;
					this.amount = "";
					this.getData()
				} else {
					uni.$u.toast(result.message);
				}
				
			},

			async getData() {
				const result = await this.$http.get(`api/goods-guquan/user-order-log`);
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
			async available() {
				const result = await userFastInfo();
				if (result.code == 0) {
					this.availBal = this.$util.formatNumber(result.data.money);
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>

<style>
</style>