<template>
	<view style="flex:60%;background-color: #FEFEFE;padding:6rpx 30rpx;" @click="linkSearch()">
		<image mode="aspectFit" :src="`/static/${icon}.png`" :style="$theme.setImageSize(32)">
		</image>
	</view>
	<!-- <image mode="aspectFit" :src="`/static/${icon}.png`" :style="$theme.setImageSize(40)" @click="linkSearch()">
	</image> -->
</template>

<script>
	export default {
		name: 'SearchPrimary',
		props: {
			// 搜索的icon
			icon: {
				type: String,
				default: 'search',
			},
		},
		methods: {
			// 跳转到查询页面
			linkSearch() {
				uni.navigateTo({
					url: this.$paths.SEARCH
				})
			}
		}
	}
</script>