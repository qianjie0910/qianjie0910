<template>
	<view>
		<view class="progroess_wrapper">
			<view :style="setStyle"></view>
			<view :style="imgMove"> </view>
		</view>
		<view style="text-align: center;color: #FFFFFF;font-size: 32rpx;margin-top: 30rpx;">
			{{`${$lang.STATUS_LOADING} `}} {{`${percentage} %`}}
		</view>
	</view>
</template>

<script>
	// 横向进度条，带有蒙层，上部带有进度值
	export default {
		name: 'ProgressSecond',
		data() {
			return {
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},
	
		computed: {
			// 设置进度条递进样式
			setStyle() {
				// 当前方向
				const _direction = 'left';
				const temp = {
					position: 'absolute',
					bottom: 0,
					[`${_direction}`]: 0, // 决定进度条的递进方向
					height: '20rpx',
					width: `${this.percentage}%`,
					...this.$theme.LAUNCH_PROGRESS,
					borderRadius: '20rpx',
				};
				// console.log('进度条递进完整样式:', temp);
				return temp;
			}
		},
		mounted() {
			console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					// console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage++;
					} else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						setTimeout(() => {
							uni.switchTab({
								url: this.$paths.HOME,
							})
						}, 1500);
					}
					// console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	// 进度条容器。一般为背景色或背景图
	.progroess_wrapper {
		position: relative;
		margin: 30rpx 120rpx;
		height: 20rpx;
		border-radius: 20rpx;
		padding: 0 3px;
		background-image: url(/static/launch_loading_border.png);
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: 100% 100%;
	}
</style>