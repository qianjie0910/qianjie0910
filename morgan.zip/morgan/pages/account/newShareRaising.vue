<template>
	<!-- 新股抢筹/配售 -->
	<view :style="$theme.setBGSize('480rpx')" style="min-height: 100vh;">
		<view class="">
			<!-- <image src="/static/beijing.png" mode="widthFix" style="width: 100%;"></image> -->
			<view class="flex " style="width: 100%;padding: 20px;">
				<image src="/static/baise.png" mode="widthFix" style="width: 10px;" @tap="home()"></image>
				<view class="" style="text-align: center;font-size: 20px;color: #FFF;width: 85%;">주식 거래</view>
			</view>
		</view>
		<view class=" justify-around flex" style="margin:0 10px;padding:10rpx;background-color: #FFFFFF;width: 92%;">
			<view class="flex-0.5" 
				style="font-size: 20px;background-color: #042eb4;color: #fff; padding: 5px 30px;border-radius: 5px;">종목
			</view>
			<!-- @click="shenqing()" -->
			<view class="flex-0.5"
				style="font-size: 20px;background-color: #042eb4;padding: 5px 10px;border-radius: 5px;color: #fff;"
				@click="huosheng()">청약기록</view>

		</view>

		<view style="padding: 10px;background-color: #FFFFFF;margin:20rpx;width: 90%;position: absolute;">



			<view style="background-color: #FFF;overflow-y: scroll;">
				<view v-for="(item,index) in funding" :key="index"
					style="border-bottom: 0.037037rem solid #e0e0e0;margin:10px;padding-bottom: 10px;">
					<view class="display" style="margin: 20rpx 0;">
						<view class="flex">
							<view class="corporation flex-1" style="font-size: 20px;">{{item.goods.name}}</view>
							<view style="background-color: #03b7f2;padding: 5px;color: #FFF;border-radius: 5px;"
								@click="show = true">

								확인
							</view>
						</view>
					</view>
					<view>
						<u-popup :show="show" @close="close" @open="open">
							<view style="padding: 20px 0px;">
								<view class="text-center" style="font-size: 20px;">{{item.goods.name}}</view>
								<view class="flex ration" style="width: 85%;padding: 5px 30px;">
									<view class="flex-3">
										공모가</view>
									<view class="flex">{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
									</view>
								</view>
								<view class="flex ration" style="width: 85%;padding: 5px 30px;">
									<view class="flex-3">
										배치 가격</view>
									<view class="flex">
										{{item.peishou_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
								</view>
								<view style="padding: 10px 25px;">
									<input placeholder="들어 오세요..." v-model="amount"
										style="border: #ccc 1px solid;padding: 10px;border-radius: 5px;" />
								</view>
								<view style="padding:20px 30px;" @click="placeOrder(item.id)">
									<view class="text-center"
										style="padding: 15px;background-color: #042eb4;color: #fff; font-size: 16px;">
										확신하는</view>
								</view>


							</view>
						</u-popup>

					</view>

					<view class="display">
						<view class="flex ration" style="width: 100%;padding: 5px;">
							<view class="flex-3">
								공모가</view>
							<view class="flex">{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
						</view>
						<view class="flex ration" style="width: 100%;padding: 5px;">
							<view class="flex-3">
								배치 가격</view>
							<view class="flex">{{item.peishou_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>
						<!-- <view class="flex ration" style="width: 100%;padding: 5px;">
						<view class="flex-3">
							기관 배정 수량</view>
						<view class="flex">{{item.fa_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>	
					</view> -->
						<view class="flex " style="width: 100%;padding: 5px;">
							<view class="flex-3">
								청약일자</view>
							<view class="flex">{{item.shengou_date}}</view>
						</view>

						<!-- <view class="flex " style="width: 100%;padding: 5px;">
						<view class="flex-3">
							발표일</view>
						<view class="flex">{{item.gb_date}}</view>
						
					</view>
					<view class="flex " style="width: 100%;padding: 5px;">
						<view class="flex-3">
							입금만료일</view>
						<view class="flex">{{item.rj_date}}</view>
						
					</view> -->
						<view class="flex " style="width: 100%;padding: 5px;">
							<view class="flex-3">
								상장일</view>
							<view class="flex">{{item.online_date}}</view>

						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="empty">
			<image :src="`/static/empty_${img}.png`" mode="aspectFit" :style="$theme.setImageSize(400)"></image>
			<view :style="{color:color}">내역 없음</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				funding: '',
				show: false,
				amount: "", // 金额
			}
		},
		methods: {
			// 기록 보관
			ration() {
				uni.navigateTo({
					url: '/pages/account/newShares/ration/ration'
				});
			},
			open() {
				// console.log('open');
			},
			close() {
				this.show = false
				// console.log('close');
			},
			// 우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/account/ration/luckyNumber'
				});
			},
			//抢筹
			purchase(id, peishou_price) {
				uni.navigateTo({
					url: '/pages/account/offlinePlacement/offlinePlacement' +
						`?id=${id}&peishou_price=${peishou_price}`
				});
				// console.log(gid, '抛出去');
			},
			home() {
				uni.navigateBack({
					url: '/pages/home'
				});
			},
			shenqing() {
				uni.navigateTo({
					url: '/pages/account/ration/luckyNumber'
				});
			},
			huosheng() {
				uni.navigateTo({
					url: '/pages/account/ration/ration'
				});
			},

			//列表
			async scramble() {
				let list = await this.$http.post('api/goods-scramble/calendar', {})
				this.funding = list.data
				// console.log(this.funding, '99999999');
			},
			async scrambleForFunds(id) {
				let list = await this.$http.get('api/goods-scramble/detail', {
					id: this.id
				})
				this.scrambleFor = list.data
				console.log(list.data, '자금을 서두르다');
			},
			async placeOrder(id) {


				let list = await this.$http.post('api/goods-scramble/doOrder', {
					num: this.quantity,
					id: id,
					num: this.amount,
					price: this.price,
					double: 1
				})
				// console.log(this.scrambleFor.price,'111');
				if (list.code == 0) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.navigateTo({
							url: this.$paths.TRADE_SHENGOUJILV,
						});
					}, 2000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
		created() {
			this.scramble()
		}
	}
</script>

<style lang="scss">
	.corporation {
		font-size: 30rpx;
		font-weight: 600;
		color: #333;

	}

	// .purchase {
	// 	background-color: rgb(72, 156, 229);
	// 	color: #fff;
	// 	border-radius: 40rpx;
	// 	padding: 6rpx 40rpx;
	// 	font-size: 26rpx
	// }
	.college-bg {
		padding: 20rpx;
		height: 100rpx;
		// background-color: #043bbf;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 10rpx;
			height: 20rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}


	.find {
		width: 50%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	.ration {
		width: 42%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	// .science {
	// 	// margin: 30rpx;
	// 	// padding-bottom: 30rpx;
	// 	border-bottom: 0.037037rem solid #e0e0e0;


	// }
</style>