<!-- 登入 注册 -->
<template>
	<view >
		<!-- :style="$theme.setBGCover(`launch_bg`)" -->
		<!-- <view style="position: fixed;right:3vw;top:3vh;z-index: 11115;">
			<Translate></Translate>
		</view> -->

		<view style="display: flex;align-items: center;justify-content: center;padding-top: 10vh;">
			<image src='/static/logo.png'  :style="$theme.setImageSize(340,360)" style="margin-bottom: 50px;">
			</image>
		</view>

		<view style="background-color: #FFFFFF;margin:20rpx;">
			<h3 style="font-size: 40rpx;padding:20px;text-align: center;color:#121212">
				{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
			</h3>

			<view style="padding:0px 30px 10px 30px;">
				<view class="common_input_wrapper" style="">
					<image src="/static/account_name.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
					<input v-model="user" type="number" :placeholder="$lang.ENTER_USER_NAME" maxlength="11"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</view>
			</view>
			<view style="padding:0 30px 10px 30px;">
				<view class="common_input_wrapper" style="">
					<image src="/static/account_password.png" mode="aspectFit" :style="$theme.setImageSize(40)">
					</image>
					<template v-if="isShow">
						<input v-model="password" type="text" :placeholder="$lang.ENTER_PASSWORD"
							:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
					</template>
					<template v-else>
						<input v-model="password" type="password" :placeholder="$lang.ENTER_PASSWORD"
							:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
					</template>

					<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
						:style="$theme.setImageSize(32)" @click="toggleShow">
					</image>
				</view>
			</view>

			<template v-if="!isSignIn">
				<view style="padding:0 30px 10px 30px;">
					<view class="common_input_wrapper" style="">
						<image src="/static/account_password.png" mode="aspectFit" :style="$theme.setImageSize(40)">
						</image>
						<template v-if="isShow">
							<input v-model="verifyPassword" type="text" :placeholder="$lang.VERIFY_PASSWORD"
								:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
						</template>
						<template v-else>
							<input v-model="verifyPassword" type="password" :placeholder="$lang.VERIFY_PASSWORD"
								:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
						</template>

						<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
							:style="$theme.setImageSize(32)" @click="toggleShow">
						</image>
					</view>
				</view>
				<view style="padding:0 30px 0 30px;">
					<view class="common_input_wrapper" style="">
						<image src="/static/account_code.png" mode="aspectFit" :style="$theme.setImageSize(40)">
						</image>
						<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE" maxlength="11"
							:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
					</view>
				</view>
			</template>

			<template v-if="!isSignIn">
				<view @click="handleChange()"
					style="background-color: transparent;border-radius: 0;padding-bottom: 10px;display: flex;align-items: center;justify-content: flex-end;padding-right: 40px; "
					:style="{color:$theme.PRIMARY}">
					{{$lang.SIGN_IN}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(14)"></view>
				</view>
			</template>

			<view @click="handleConfirm()" style="width: 80%;margin: 30rpx auto" :style="$theme.btnCommon(isSignIn)">
				{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
			</view>

			<template v-if="isSignIn">
				<view
					style="padding:20rpx 30px 30rpx 30px;display: flex;align-items: center;justify-content: space-between;">

					<u-checkbox-group>
						<u-checkbox shape="" :activeColor="$theme.PRIMARY" :label="$lang.TIP_REMEMBER_PWD"
							v-model="isRemember" :labelColor="$theme.PRIMARY" labelSize="24rpx" @change="changeRemember"
							:checked="isRemember" :iconColor="$theme.PRIMARY"></u-checkbox>
					</u-checkbox-group>

					<view style="font-size: 28rpx;margin-right: 4px;" :style="{color:$theme.PRIMARY}"
						@click="handleChange()">
						{{isSignIn?$lang.SIGN_UP:$lang.GO_TO_SIGN_IN}}
						<view class="arrow rotate_45" :style="$theme.setImageSize(14)">
						</view>
					</view>
				</view>
			</template>

			<view style="padding:20px 30px 40rpx 30px;display: flex;align-items: center;justify-content: center;">
				<u-checkbox-group>
					<u-checkbox shape="" :activeColor="$theme.PRIMARY" :label="$lang.TIP_AGREE" v-model="isAgree"
						labelColor="#121212" labelSize="24rpx" @change="changeAgree" :checked="isAgree"
						:iconColor="$theme.PRIMARY"></u-checkbox>
				</u-checkbox-group>
				<view style="font-size:24rpx;margin-left: 8px;" :style="{color:$theme.PRIMARY}" @click="linkPact()">
					{{$lang.TIP_PRVITE_PACT}}
				</view>
			</view>

			<view style="position: fixed;bottom: 3vh;left: 0;right: 0;">

			</view>
		</view>
	</view>
</template>

<script>
	import Translate from '@/components/Translate.vue';
	// import CustomDivider from '@/components/CustomDivider.vue';
	export default {
		components: {
			Translate,
			// CustomDivider
		},
		data() {
			return {
				isShow: false, // 密码显隐
				user: "",
				password: '',
				verifyPassword: '',
				code: '',
				isSignIn: true,
				isRemember: false, // 记住密码
				isAgree: false, // 同意隐私协议
			};
		},
		onShow() {
			this.user = uni.getStorageSync('user') || '';
			this.password = uni.getStorageSync('pwd') || '';
			if (this.user.length > 0) {
				this.changeRemember(true);
				this.changeAgree(true);
			}
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 勾选记住密码
			changeRemember(e) {
				this.isRemember = e;
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
			},

			// 用户隐私协议
			linkPact() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_PRVITE_PACT
				})
			},

			handleChange() {
				this.isSignIn = !this.isSignIn;
				// this.user = "";
				// this.password = "";
				// this.verifyPassword = "";
				// this.code = "";
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast(this.$lang.ENTER_USER_NAME);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.ENTER_PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.verifyPassword == '') {
					uni.$u.toast(this.$lang.ENTER_VERIFY_PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.$u.toast(this.$lang.ENTER_INVITATION_CODE);
					return false;
				}
				if (this.isAgree != true) {
					uni.$u.toast(this.$lang.TIP_CHECK_AGREE);
					return false;
				}
				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				});
				if (result.code == 0) {
					const token = result.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
					// 如果勾选记住密码，则将用户名和密码放入缓存中
					if (this.isRemember == true) {
						uni.setStorageSync('user', this.user);
						uni.setStorageSync('pwd', this.password);
					}
					uni.$u.sleep(500).then(() => {
						uni.switchTab({
							url: this.$paths.HOME,
						});
					});
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			},
			async register() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: 123456,
				});
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
					this.signIn();
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			},
		}
	}
</script>

<style lang="scss">
	/deep/.u-checkbox__icon-wrap {
		background-color: transparent !important;
	}
</style>