<template>
	<view :style="$theme.setBGSize('480rpx')">
		<HeaderSecond :title="info.title" color="#FFFFFF"></HeaderSecond>

		<template v-if="isContent">
			<view style="padding: 40rpx;background-color: #FFFFFF;margin:20rpx 20rpx">
				<view v-html="info.content"
					style="font-size:28rpx;white-space: break-spaces;line-height: 1.3;padding:10px;color:#121212">
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				info: {},
			};
		},
		computed: {
			// 有内容则显示
			isContent() {
				return this.info && this.info.content && this.info.content.length > 0;
			}
		},
		onLoad() {
			this.getData();
		},
		methods: {
			// 获取数据
			async getData() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/article/privacy`);
				console.log('result:', result);
				if (result.code == 0) {
					this.info = result.data;
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			}
		}
	}
</script>

<style>
</style>