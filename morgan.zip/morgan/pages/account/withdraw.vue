<template>
	<view class="withdraw_bg">
		<HeaderSecond :title="$lang.PAGE_TITLE_WITHDRAW" color="#FFFFFF"></HeaderSecond>

		<view style="margin:60rpx;">
			<view style="text-align: center;color:#FFFFFF;font-size: 28rpx;line-height: 2;">
				{{$lang.WITHDRAW_AMOUNT}}
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`" @click="handleShowAmount"
					:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
				</image>
			</view>

			<view style="font-size: 48rpx;color:#FFFFFF;font-weight: 700;text-align: center;line-height: 2;">
				{{showAmount?$util.formatNumber(userInfo.totalZichan):hideAmount}}
			</view>
		</view>

		<view style="padding:40rpx;background-color: #FFFFFF;margin:20rpx 30rpx;">
			<TitleSecond :title="$lang.WITHDRAW_WITH_AMOUNT" color="#121212"></TitleSecond>
			<view class="common_input_wrapper" style="padding-left: 30px;margin-bottom: 20px;margin-top: 0;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"
					:placeholder-style="$theme.setPlaceholder()" style="flex: auto;"></input>
			</view>

			<TitleSecond :title="$lang.WITHDRAW_PAY_PWD" color="#121212"></TitleSecond>
			<view class="common_input_wrapper" style="padding-left: 30px;margin-bottom: 20px;margin-top: 0;">
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
					:placeholder-style="$theme.setPlaceholder()" style=""></input>
			</view>

			<view :style="$theme.btnCommon(true)" @click="handleWithdraw()">
				{{$lang.BTN_WITHDRAW}}
			</view>


			<view style="margin:10px; padding:40rpx 0;" :style="{color:$theme.TITLE}">
				<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
					<view style="padding-bottom: 6px;" :style="{color:index==5?$theme.PRIMARY :'#121212'}">
						{{item}}
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			TitleSecond,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// handleAllAmount(val) {
			// 	this.amount = val
			// },
			async handleWithdraw() {
				const result = await this.$http.post(`api/app/withdraw`, {
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						this.$util.linkCustomerService();
					}, 500)
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/user/info`);
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			},
		},
	}
</script>