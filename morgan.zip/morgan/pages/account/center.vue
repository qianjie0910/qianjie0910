<template>
	<view :style="$theme.setBGSize('480rpx')">
		<HeaderPrimary isSearch></HeaderPrimary>

		<Profile :info="userInfo"></Profile>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="home_card_bg home_card_bg_3" style="width: 300px;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-around;margin-top: 20rpx;margin:20rpx;">
			<view :style="$theme.btnCommon(false)" style="width: 30%;margin:0 20rpx;" @click="linkDeposit()">
				{{$lang.PAGE_TITLE_DEPOSIT}}
			</view>
			<view :style="$theme.btnCommon(true)" style="width: 30%;margin:0 20rpx;background-color: #569CFA;"
				@click="linkWithdraw()">
				{{$lang.PAGE_TITLE_WITHDRAW}}
			</view>
		</view>

		<view style="padding:0 10px;">
			<CustomTitle :title="$lang.ACCOUNT_MORE_FEATURES"></CustomTitle>
		</view>

		<view style="background-color: #FFFFFF;margin:0 30rpx 30rpx 30rpx;">
			<!-- <NavList :info="userInfo"></NavList> -->
			<AccountCenterList :info="userInfo"></AccountCenterList>
		</view>

		<view style="margin:0 60rpx">
			<SignOut></SignOut>
		</view>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/Profile.vue';
	// import NavList from '@/components/account/NavList.vue';
	import AccountCenterList from '@/components/account/AccountCenterList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import SignOut from '@/components/account/SignOut.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			// NavList,
			AccountCenterList,
			CustomTitle,
			AccountAssets,
			CardItemPrimary,
			SignOut,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {},
			}
		},
		computed: {
			cardLabels() {
				return [
					this.$lang.ACCOUNT_AMOUNT_AVAILABLE,					
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_AMOUNT_TOTAL,
				];
			},
		},
		onShow() {
			this.gaint_info()
		},
		//下拉刷新
		onPullDownRefresh() {
			this.gaint_info()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			// 客服
			linkService() {
				this.$util.linkCustomerService();
			},

			//用户信息
			async gaint_info() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/user/info`);
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardData = {
						value1: this.userInfo.totalZichan, // 可提
						value2: this.userInfo.aiMoney, // AI
						value3: this.userInfo.money, // 总资产
					};
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			},
		},
	}
</script>