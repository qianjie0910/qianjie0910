<template>
	<view>
		<view style="background-image: linear-gradient(180deg, #F5B71C, transparent);">
			<HeaderSecond :title="$lang.STOCK_ALL"></HeaderSecond>
		</view>
		
		<view style="padding-bottom: 20px;">
			<!-- <TabsPrimary :tabs="$lang.TRADE_DAY_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsPrimary> -->
			<GoodsList ref="goods"></GoodsList>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			HeaderSecond,
			GoodsList,
			TabsPrimary,
		},
		data() {
			return {
				curTab: 0
			}
		},
		onShow() {
			if (this.$refs.goods) {
				this.$refs.goods.onSetTimeout();
			}
		},
		onHide() {
			console.log('onHide', this.$refs.goods);
			this.$refs.goods.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.$refs.goods);
			this.$refs.goods.clearTimer();
		},

		methods: {
			changeTab(val) {
				this.curTab = val;
			}
		}
	}
</script>