<template>
	<view>
		<view style="background-image: linear-gradient(180deg, #F5B71C, transparent);">
			<HeaderSecond :title="$lang.PAGE_TITLE_NOTIFICATION" @action="$u.route({type:'navigateBack'})">
			</HeaderSecond>
		</view>
		<view class="common_block">
			<view
				style="width: 100%;display:flex;flex-direction: column;justify-items: center;align-items: center;padding: 10vh 0;">
				<image src="/static/notifi_null.png" :style="$theme.setImageSize(500,600)"></image>
				<view style="font-size: 32rpx;padding-top:30px;text-align: center;" :style="{color:$theme.TITLE}">
					{{$lang.EMPTY_NOTIFIY}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
	}
</script>