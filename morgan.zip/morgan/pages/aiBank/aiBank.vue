<!-- 펀드 비밀번호 -->
<template>
	<view>

		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text"></view>
			<view class="college-text">AI 트레이딩 계정</view>
			<view class="college-text" @click="log">거래내역</view>
		</view>
		<view
			style="width: 96%;background-color: #eef4ff;border: 1px #4f61f5 solid;margin-left: 2%;margin-right: 2%px;margin-bottom: 10px;margin-top: 5%; border-radius: 10px;">
			<view class="padding-10 flex-1">
				<view class="flex align-center ">
					AI 트레이딩 계정
				</view>
				<view class="margin-top-10 bold font-size-24">
					{{userInformation.aiMoney.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
				</view>
			</view>
			<view style="display: flex;">
				<view class="padding-10 flex-1">
					<view class="flex align-center">
						가용 자금
					</view>

					<view class="margin-top-10 bold font-size-16">
						{{userInformation.money}}
					</view>
				</view>
				<view class="padding-10 flex-1">
					<view class="flex align-center">
						총 평가수익금
					</view>

					<view class="margin-top-10 bold font-size-16">
						{{userInformation.holdYingli.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
				<view class="padding-10 flex-1">
					<view class="flex align-center">
						동결자금
					</view>

					<view class="margin-top-10 bold font-size-16">
						{{userInformation.freezeMoney.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
					</view>
				</view>
			</view>
			<view class="flex" style="margin:0 5% 0 5%;">
				<view class="purchase " @click="transfer()" style="width: 50%;">
					입금
				</view>
				<view class="purchase" @click="rollout()" style="width: 50%;">
					출금
				</view>
			</view>
		</view>
		<view
			style="border-radius: 10px;background: #fff;margin: 10px;padding:10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
			<view class="flex flex-b " style="box-shadow: 0px 5px 5px -5px rgba(0, 0, 0, 0.5);">
				<view class="text-center width100" :class="Inv==0?'with-bottom-line':''" @click="qiehuan(0)">
					종목 보유 현황
				</view>
				<view class="text-center width100" :class="Inv==1?'with-bottom-line':''" @click="qiehuan(1)">
					매매 내역
				</view>
			</view>
			<view class="flex flex-b margin-top-20 gap5">
				<view class="flex-1 text-center hui2 padding-5 radius10" style="background-color: #c2dbf4;">
					<view style="background-color: #fff;" class="padding-5 radius10">
						<view class="font-size-12" style="height: 38px;display: flex;align-items: center;justify-content: center;">
							종목명
						</view>
						<!-- <view class="margin-top-10 font-size-12">
							구분
						</view> -->
					</view>
				</view>
				<view class="flex-1 text-center hui2 padding-5 radius10" style="background-color: #c2dbf4;">
					<view style="background-color: #fff;" class="padding-5 radius10">
						<view class="font-size-12">
							평가수익금
						</view>
						<view class="margin-top-10 font-size-12">
							평가수익률
						</view>
					</view>
				</view>
				<view class="flex-1 text-center hui2 padding-5 radius10" style="background-color: #c2dbf4;">
					<view style="background-color: #fff;" class="padding-5 radius10">
						<view class="font-size-12">
							보유수량
						</view>
						<view class="margin-top-10 font-size-12">
							평가금액
						</view>
					</view>
				</view>
				<view class="flex-1 text-center hui2 padding-5 radius10 " style="background-color: #c2dbf4;">
					<view style="background-color: #fff;" class="padding-5 radius10">
						<view class="font-size-12">
							평단가
						</view>
						<view class="margin-top-10 font-size-12" v-if="Inv == 0">
							현재가
						</view>
						<view class="margin-top-10 font-size-12" v-if="Inv == 1">
							현재가
						</view>
					</view>
				</view>
			</view>
			<view class="margin-top-10 gap5">
				<view class="flex flex-b margin-top-5 " v-for="(item,index) in storehouse" :key="index"  @tap="sell(item)">
					<view class="padding-5" :class="index%2==0?'bgyellow':'bglan'" style="width: 24%">
						<view class="">
							{{item.goods_info.name}}
						</view>
					</view>
					<view class="padding-5 flex flex-b" :class="index%2==0?'bgyellow':'bglan'" style="width: 75%">
						<view :class="item.order_buy.float_yingkui>0?'red':'green'" class="flex-1" v-if="Inv==0">
							<view>
								{{item.order_buy.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 ">
								{{(item.order_buy.yingkui/item.order_buy.user_pay/item.order_buy.double*100).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}%
							</view>
						</view>
						<view :class="item.order_sell.yingkui>0?'red':'green'" class="flex-1" v-if="Inv==1">
							<view>
								{{item.order_sell.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 ">
								{{(item.order_sell.yingkui/item.order_buy.user_pay/item.order_buy.double*100).toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}%
							</view>
						</view>

						<view class="flex-1">
							<view class="text-right">
								{{item.order_buy.num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 text-right" v-if="Inv==0">
								{{(item.goods_info.current_price*1*item.order_buy.num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 text-right" v-if="Inv==1">
								{{(item.order_sell.price*1*item.order_buy.num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>

						<view class="flex-1">
							<view class="text-right">
								{{(item.order_buy.price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 text-right red" v-if="Inv==0">
								{{(item.goods_info.current_price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
							<view class="margin-top-10 text-right red" v-if="Inv==1">
								{{(item.order_sell.price).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</view>
						</view>
					</view>
				</view>

			</view>
		</view>
		<view class="overlay" v-if="item_show" @click="item_show=false"></view>
		<view style="position: fixed;width: 90%;margin-left: 5%;border-radius: 20px;background-color: #4f61f5;top: 20%;z-index: 9999;" v-if="item_show">
			<view class="color-white  padding-10 flex ">
				<view class="text-center justify-center width100 font-size-16">세부내역</view>
				
				<u-icon name="/static/market/close.png" size="24" @click="item_show=false"></u-icon>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">종목명</view>
					<view class="flex-1">{{info.goods_info.name}}</view>
				</view>
				
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매수시간</view>
					<view class="flex-1">{{info.order_buy.created_at}}</view>
				</view>
				
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;" v-if="Inv==1">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">매도시간</view>
					<view class="flex-1">{{info.order_sell.created_at}}</view>
				</view>
				
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">평가수익금</view>
					<view class="flex-1" v-if="Inv==0">{{info.order_buy.float_yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					<view class="flex-1" v-if="Inv==1">{{info.order_sell.float_yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">레버리지</view>
					<view class="flex-1">X{{info.order_buy.double}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총 평가손익</view>
					<view class="flex-1" v-if="Inv==0">{{info.order_buy.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					<view class="flex-1" v-if="Inv==1">{{info.order_sell.yingkui.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">체결가</view>
					<view class="flex-1">{{info.order_buy.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수량</view>
					<view class="flex-1">{{info.order_buy.num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">수수료</view>
					<view class="flex-1">{{info.order_buy.buy_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}} <span v-if="Inv==1">/{{info.order_sell.sell_fee.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</span></view>
				</view>
			</view>
			<view class="flex flex-b padding-10" style="background-color: #fff;">
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">총 매입가</view>
					<view class="flex-1">{{info.order_buy.amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
				</view>
				<view class="flex flex-b flex-1">
					<view class="flex-1 bold">종목코드</view>
					<view class="flex-1">{{info.goods_info.number_code}}</view>
				</view>
			</view>
			<view  class="text-center padding-20" style="background-color: #fff;border-radius: 0 0 20px 20px;">
<!-- 				<view style="width: 100%;background-color: #3779CD;" class="padding-10 radius10 color-white font-size-16" v-if="Inv==0" @tap="productDetails(info.goods_info.number_code)">구입하다</view> -->
				
				<view style="width: 100%;background-color: #e82d28;" class="padding-10 radius10 color-white font-size-16 margin-top-10" v-if="Inv==0" @tap="position(info.id)">매도</view>
			</view>
		</view>
		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
			:showCancelButton='showCancelButton' :content='content' cancel-text="취소" confirm-text="확인">
		</u-modal>
		<view class="empty">
			<view :style="{color:color}">내역 없음</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				balance: 0,
				money: '',
				gp_index: 0,
				Inv: 0,
				show: false,
				item_show:false,
				title: '매도 주문',
				content: '매도 하시겠습니까?',
				showCancelButton: true,
				userInformation: {},
				storehouse: {},
				info:[],
			};
		},
		onShow() {
			this.gaint_info()
			this.hold()
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/home'
				});
			},
			log(){
				uni.navigateTo({
					url:'/pages/aiBank/log'
				})
			},
			transfer(){
				uni.navigateTo({
					url:'/pages/aiBank/transfer'
				})
			},
			rollout(){
				uni.navigateTo({
					url:'/pages/aiBank/rollout'
				})
			},
			qiehuan(index) {
				this.Inv = index
				this.storehouse = {}
				if(index == 0){
					this.hold()
				}else if(index == 1){
					this.flat()
				}
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				this.closingFunction(confirmation)
				this.show = false;
			},
			sell(item){
				this.info=item
				this.item_show=true;
			},
			// 平仓
			position(id) {
				this.item_show=false
				this.show = true;
				this.confirmation = id
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
					ai:1
				})
				this.balance = list.data.money;
				const _fmtTotal = list.data.totalZichan.toString().length < 3 ? list.data.totalZichan : list
					.data.totalZichan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				const _fmtMoney = list.data.money.toString().length < 3 ? list.data.money : list.data
					.money.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				const _fmtAiMoney = list.data.aiMoney.toString().length < 3 ? list.data.aiMoney : list
					.data
					.aiMoney.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				this.userInformation = {
					...list.data,
					totalZichan: _fmtTotal,
					money: _fmtMoney
				}
				this.cardManagement = list.data.bank_card_info
			},
			// 持仓
			async hold() {
				let list = await this.$http.get('api/user/order', {
					// language: this.$i18n.locale
					status: 1,
					ai: 1,
					gp_index: this.gp_index
				})
				this.storehouse = list.data
				uni.hideLoading()
			},
			//平仓
			async flat() {
				let list = await this.$http.post('api/user/order', {
					// language: this.$i18n.locale
					status: 2,
					ai: 1,
					gp_index: this.gp_index
				})
				this.storehouse = list.data
				uni.hideLoading()
			},
			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: "포지션을 마감 중입니다. 잠시 기다려 주세요....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/sell', {
					id: confirmation,
					// price: item.price
				})
				// console.log(item.id, '平仓功能');
				if (list.data.code == 0) {
					this.hold()
					uni.$u.toast(list.data.message);
					// this.$router.go(0)
					uni.hideLoading();
			
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
				}
			
			}

		},
		watch: {
			money() {
				if (this.money > this.balance) {
					this.money = this.balance
				}
			}
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		// background-image: url("../../../../static/my/zijimima.png");
		background-color: #0349cc;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {
			text-align: center;
			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 20rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		background-color: #4f61f5;
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}
	.with-bottom-line{
		color: #1d7ed2;
	}
	.with-bottom-line::after {  
	    content: ""; /* 必须设置，表示插入的内容为空 */  
		display: block; /* 使得::after生成的元素成为块级元素 */  
		border-bottom: 2px solid #1d7ed2; /* 添加底部横线 */  
		width: 60%; /* 使横线宽度与父元素相同 */  
		margin-top: 10px; /* 可选：添加一些顶部外边距 */  
		text-align: center;
		margin-left: 20%;
	}  
</style>