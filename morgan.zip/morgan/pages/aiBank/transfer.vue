<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="widthFix" @tap="home()" style="width:15px;"></image>
			<view class="college-text">원클릭 이동 서비스</view>
		</view>
		<view style="margin-top: -100px;" class="text-center">
			
			<view class="title" style="font-size: 16px;color: #fff;">
				<span>전환 가능 금액</span>
			</view>
			<view class="money text-center color-white font-size-22 bold margin-top-10">
					<span>{{userInformation.money}}</span>
			</view>

		</view>
		<view style="background-color: #F6FFFA;margin: 20px 10px;" class="flex flex-b padding-20 radius10">
			<view>
				AI 트레이딩 지갑 계좌
			</view>
			<!-- <view>
				전환 금액
			</view> -->
		</view>
		<view style="margin: 20px;">
			<view style="margin: 10px 0;" class="bold">전환 금액</view>
			<u--input placeholder="입력 금액"  v-model="money" style="height: 30px;"></u--input>
		</view>
		<veiw class="flex flex-wrap text-center gap10" style="margin: 20px;color: #14CF76;">
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(10)">
				10%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(20)">
				20%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(30)">
				30%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(40)">
				40%
			</view>
		</veiw>
		<veiw class="flex flex-wrap text-center gap10" style="margin: 20px;color: #14CF76;">
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(50)">
				50%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(60)">
				60%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(70)">
				70%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(80)">
				80%
			</view>
		</veiw>
	
		<view class="purchase" @click="transfer">
			확인
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				money: '',
				userInformation: {}
			}
		},
		onShow() {
			this.gaint_info()
		},
		methods: {
			xx(number){
				
				this.money=parseInt(this.balance*number*0.01)
				
			},
			home() {
				uni.navigateBack()
			}, //用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.balance = list.data.money;
				console.log(1111,this.balance);
				const _fmtTotal = list.data.totalZichan;
				const _fmtMoney =  list.data.money ;
				const _fmtAiMoney =  list.data.aiMoney ;
				this.userInformation = {
					...list.data,
					totalZichan: _fmtTotal,
					money: _fmtMoney
				}
				this.cardManagement = list.data.bank_card_info
			},
			async transfer() {
				if (this.money > 0) {
					let list = await this.$http.post('api/user/transfer', {
						'money': this.money,
						'type': 1
					});
					uni.showToast({
						title: list.data.message,
						// icon: 'none'
					})
					let _this = this;
					setTimeout(function() {
						_this.gaint_info();
						_this.money = '';
					}, 1000)

				}

			}
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 150px;
		// background-image: url("../../../../static/my/zijimima.png");
		background: linear-gradient(to right, #14CF76, #59DF9F);
		background-repeat: no-repeat;
		background-size: 100% 100%;
		display: flex;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {
			text-align: center;
			margin: 0 auto;
			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 20rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		background-color: #14CF76;
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}

	.with-bottom-line {
		color: #1d7ed2;
	}

	.with-bottom-line::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 2px solid #1d7ed2;
		/* 添加底部横线 */
		width: 60%;
		/* 使横线宽度与父元素相同 */
		margin-top: 10px;
		/* 可选：添加一些顶部外边距 */
		text-align: center;
		margin-left: 20%;
	}
</style>